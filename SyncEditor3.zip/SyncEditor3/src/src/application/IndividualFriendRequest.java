package src.application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class IndividualFriendRequest extends GridPane {

	// should be given the user object and the status only
	public IndividualFriendRequest(boolean isFriend, Image img, String name, boolean status) {

		// assuming the two users are already friends we set the initial value
		ImageView decidedImage = new ImageView(new Image("AlreadyFriends.png"));
		Labeled decidedButton = new Label("Already Friends.", decidedImage);
		decidedButton.setFont(Font.font("Times New Roman", 18));

		Label left = getprofileNode(img, status, name);// gets the profile picture with the name

		// when the users are not friends, we give the option to send a friend request
		if (!isFriend) {
			decidedImage = new ImageView(new Image("AddFriend.png"));
			decidedButton = new Button("Send Friend Request", decidedImage);
			decidedButton.setPrefSize(210, 27);
			decidedButton.getStyleClass().add("friend-request");

			////////////////////////////////////////////////////////////
			// put the action of sending a request to that person here//
			////////////////////////////////////////////////////////////
			((Button) decidedButton).setOnAction(e -> {
				System.out.println("sent request to " + name);
			});

		} // end button and picture changes

		// setting properties
		decidedButton.setContentDisplay(ContentDisplay.LEFT);
		decidedButton.setGraphicTextGap(10);
		decidedImage.setFitWidth(25);
		decidedImage.setFitHeight(25);

		// adding to the grid pane
		add(left, 0, 0);
		add(decidedButton, 1, 0);
		setHgap(50);
		setAlignment(Pos.CENTER_LEFT);

		// adding column constraint to align the items
		ColumnConstraints column2 = new ColumnConstraints(410);
		getColumnConstraints().add(column2);

	}

	// gets the picture, status, and name in the correct positioning
	public Label getprofileNode(Image img, boolean status, String name) {

		// Create a circular profile picture
		Circle profileCircle = new Circle(25);
		profileCircle.setFill(new ImagePattern(img));

		// Create a circular status indicator
		Circle statusCircle = new Circle(7);

		// Change color based on online status
		if (status)
			statusCircle.setFill(Color.GREEN);
		else
			statusCircle.setFill(Color.RED);

		// Set border color and width
		profileCircle.setStroke(Color.BLACK);
		profileCircle.setStrokeWidth(3);
		statusCircle.setStroke(Color.BLACK);
		statusCircle.setStrokeWidth(3);

		// a label to contain the name
		Label namelbl = new Label(name);
		namelbl.setFont(Font.font("Times New Roman", FontWeight.BOLD, 22));
		namelbl.setPadding(new Insets(0, 0, 10, 15));

		// Create a Horizontal pane box to hold the circles and name
		HBox completeProfilePic = new HBox(-20);
		completeProfilePic.getChildren().addAll(profileCircle, statusCircle);
		completeProfilePic.setAlignment(Pos.BOTTOM_CENTER);

		namelbl.setGraphic(completeProfilePic);
		namelbl.setContentDisplay(ContentDisplay.LEFT);
		namelbl.setGraphicTextGap(15);

		return namelbl;

	}

}
