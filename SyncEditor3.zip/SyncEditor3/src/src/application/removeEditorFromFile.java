package src.application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class removeEditorFromFile {
	Stage s = new Stage();

	public Stage getremoveEditor(String fileName,String fileEditor) {
		Image image = new Image("ICON.png");

		// Create Image View
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(60);
		imageView.setFitHeight(50);
		
		Image image2 = new Image("UnShareFile.png");

        // Create an ImageView for the photo
        ImageView photoImageView = new ImageView(image2);
        photoImageView.setFitWidth(100);
        photoImageView.setFitHeight(100);
		Label photoLabel = new Label("Are You Sure You want to Permanently Remove  "+fileName +"  Editing this File");
		photoLabel.setStyle("-fx-font-size: 14;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
        // Create an HBox for photo and label
        HBox photoHBox = new HBox(20);
        photoHBox.getChildren().addAll(photoImageView, photoLabel);
        photoHBox.setAlignment(Pos.CENTER);
		
        Label photoLabel2 = new Label(fileEditor);
		Color blue=Color.BLACK;
		photoLabel2.setAlignment(Pos.BASELINE_RIGHT);

		photoLabel2.setAlignment(Pos.CENTER);
		photoLabel2.setStyle("-fx-font-size: 16;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
		Image image22 = new Image("icons8-document-100.png");

        // Create an ImageView for the photo
        ImageView photoImageView2 = new ImageView(image22);
        photoImageView2.setFitWidth(60);
        photoImageView2.setFitHeight(60);
		
		HBox photoHBox2 = new HBox(20);
        photoHBox2.getChildren().addAll(photoImageView2,photoLabel2);
        photoHBox2.setAlignment(Pos.CENTER);
        Button button1 = new Button("Cancel");
        Button button2 = new Button("Remove");
        button1.setTextFill(blue);
        button1.setStyle("-fx-background-color: white;" +
                         "-fx-font-size: 20;" +
                         "-fx-border-width: 1;" +
                         "-fx-font-weight: Bold;" +
                         "-fx-pref-width: 100;" +
                         "-fx-alignment: CENTER;");
        button1.setOnAction(e->{
        	s.close();
        });

        button2.setTextFill(blue);
        button2.setStyle("-fx-background-color: white;" +
                         "-fx-font-size: 20;" +
                         "-fx-border-width: 1;" +
                         "-fx-font-weight: Bold;" +
                         "-fx-pref-width: 120;" +
                         "-fx-alignment: CENTER;");


        // Create a VBox for label and buttons
        HBox vbox = new HBox(30);
        vbox.getChildren().addAll( button1, button2);
        vbox.setAlignment(Pos.CENTER_RIGHT);
		
		StackPane root = new StackPane();

		VBox vboxF = new VBox(10);
		vboxF.setAlignment(Pos.CENTER);
		vboxF.setPadding(new Insets(15, 15, 15, 15));
		vboxF.getChildren().addAll(photoHBox, photoHBox2, vbox);
		root.getChildren().add(vboxF);
		// Create the scene
		Scene scene = new Scene(root,700,300);
        root.setStyle("-fx-background-color:#c9e9f6;"); // Set t
		//vbox.setStyle("-fx-background-color: #ADD8E6;");
		// Set the stage title and scene
		s.setTitle("Remove Editor From File");
		s.getIcons().add(new Image("ICON.png")); // Set application icon

		s.setScene(scene);
		s.getIcons().add(image);

		// Show the stage
		s.show();
		return s;
	}
}
