package src.application;

import java.util.Comparator;

public class Files implements Comparable<Files> {
	int fileId;

	String fileName;
	User editors;

	@Override
	public int compareTo(Files other) {
		return this.fileName.compareTo(other.fileName);
	}

	public Files(String fileName) {
		this.fileName = fileName;
	}

	public Files(String fileName, User editors) {
		this.fileName = fileName;
		this.editors = editors;
	}

	public Files(int fileId, String fileName) {
		this.fileId = fileId;
		this.fileName = fileName;
	}

	public Files(int fileId, User editors) {
		// this.fileName = fileName;
		this.fileId = fileId;
		this.editors = editors;
	}

	public Files(int fileId, String fileName, User editors) {
		super();

		this.fileName = fileName;
		this.fileId = fileId;
		this.editors = editors;
	}

	public Files() {
		// TODO Auto-generated constructor stub
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public User getEditors() {
		return editors;
	}

	public void setEditors(User editors) {
		this.editors = editors;
	}
	
	
	

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	@Override
	public String toString() {
		return "myFiles [fileName=" + fileName + ", editors=" + editors + "]";
	}

}
