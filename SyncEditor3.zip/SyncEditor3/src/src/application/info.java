package src.application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.Button;

public class info {

	private String a;
	private String f;
	private String p;

	public info(String a, String f, String p) {
		super();
		this.a = a;
		this.f = f;
		this.p = p;

	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getF() {
		return f;
	}

	public void setF(String f) {
		this.f = f;
	}

	public String getP() {
		return p;
	}

	public void setP(String p) {
		this.p = p;
	}

	// Additional methods for JavaFX PropertyValueFactory
	public StringProperty aProperty() {
		return new SimpleStringProperty(a);
	}

	public StringProperty fProperty() {
		return new SimpleStringProperty(f);
	}

	public StringProperty pProperty() {
		return new SimpleStringProperty(p);
	}

	// ________________________________________
	private int id;
	private String filename;
	private boolean readOnly;

	public info(int id, String filename, boolean readOnly) {
		this.id = id;
		this.filename = filename;
		this.readOnly = readOnly;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

}
