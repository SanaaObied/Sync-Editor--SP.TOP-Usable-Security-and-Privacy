package src.application;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class LeaveWithoutSaving extends VBox {
	private Button save, leave;
	private sql sql = new sql();
	private TextEditorPane TextEditorPane = new TextEditorPane();

	public LeaveWithoutSaving() {

		Label warning1 = new Label("There are some unsaved changes in this file. Are you sure");
		Label warning2 = new Label("you want to leave without saving?");

		warning1.setFont(Font.font("Times New Roman", 22));
		warning2.setFont(Font.font("Times New Roman", 22));

		VBox text = new VBox(10);
		text.getChildren().addAll(warning1, warning2);
		text.setPadding(new Insets(50, 15, 0, 25));
		text.setAlignment(Pos.CENTER_LEFT);

		save = new Button("Save");
		leave = new Button("Leave");

		save.getStyleClass().add("plain-button");
		leave.getStyleClass().add("plain-button");

		HBox buttons = new HBox(30);
		buttons.getChildren().addAll(leave, save);
		buttons.setPadding(new Insets(40, 0, 50, 0));
		buttons.setAlignment(Pos.CENTER);

		setSpacing(10);
		getChildren().addAll(text, buttons);
		setStyle("-fx-background-color:#EEFAFF;");
		setAlignment(Pos.CENTER);
		setPadding(new Insets(50, 20, 10, 20));
		// Actions
		leave.setOnAction(e -> {
			Platform.exit(); // Close the application
			// System.exit(0); // Close the application
		});
		save.setOnAction(e -> {
			// String htmlText = ""; // Get the HTML text from the appropriate source
			String escapedText = escapeSpecialCharacters(TextEditorPane.getAccessibleText()); // Escape special
																								// characters in the
																								// HTML text

			// Assuming you have a database connection named "connection" established
			try {
				String query = "INSERT INTO Files (`texts`) VALUES (?)";
				PreparedStatement statement = sql.getConnection().prepareStatement(query);
				statement.setString(1, escapedText);
				statement.executeUpdate();
				System.out.println("Text Was Saved ");
				System.exit(0);
				// Optionally, display a success message or perform other actions
			} catch (SQLException ex) {
				ex.printStackTrace();
				// Handle any potential exceptions that may occur during the database operation
			}

		});

	}

	public Button getSave() {
		return save;
	}

	public Button getLeave() {
		return leave;
	}

	private String escapeSpecialCharacters(String text) {
		return text;
	}

}