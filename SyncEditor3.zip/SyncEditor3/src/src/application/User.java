package src.application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.TreeSet;

import javafx.scene.image.Image;

public class User extends Account implements Comparable<User> {

	private ArrayList<String> request = new ArrayList<>();
	private ArrayList<String> inviteFile = new ArrayList<>();
	private ArrayList<Files> list = new ArrayList<>();
	private ArrayList<User> Friendslist = new ArrayList<>();

	public User() {

		// TODO Auto-generated constructor stub
	}

	public User(int acoountID) {
		super(acoountID);
		// TODO Auto-generated constructor stub
	}

	public User(String userName, Date dOB, String password, String gimal) {
		super(userName, dOB, password, gimal);
		// TODO Auto-generated constructor stub
	}

	public User(String userName, Date dOB, String password, String gimal, TreeSet avlFile, TreeSet avlUser,
			ArrayList<String> request, ArrayList<String> inviteFile, ArrayList<Files> list) {
		super(userName, dOB, password, gimal, avlFile, avlUser);
		this.request = request;
		this.inviteFile = inviteFile;
		this.list = list;
	}

	public User(int acoountID, String userName, Date dOB, String password, Image image, String gimal, TreeSet avlFile,
			TreeSet avlUser, ArrayList<String> request, ArrayList<String> inviteFile, ArrayList<Files> list) {
		super(acoountID, userName, dOB, password, image, gimal, avlFile, avlUser);
		this.request = request;
		this.inviteFile = inviteFile;
		this.list = list;
	}

	public User(int acoountID, String userName, Date dOB, String password, Image image, String gimal) {
		super(acoountID, userName, dOB, password, image, gimal);
		// TODO Auto-generated constructor stub
	}

	public ArrayList<String> getRequest() {
		return request;
	}

	public void setRequest(ArrayList<String> request) {
		this.request = request;
	}

	public ArrayList<String> getInviteFile() {
		return inviteFile;
	}

	public void setInviteFile(ArrayList<String> inviteFile) {
		this.inviteFile = inviteFile;
	}

	public ArrayList<Files> getList() {
		return list;
	}

	public void setList(ArrayList<Files> list) {
		this.list = list;
	}

	// Rest of the code...

	@Override
	public int compareTo(User otherUser) {
		String thisUserId = this.getUserName();
		String otherUserId = otherUser.getUserName();

		if (thisUserId == null) {
			if (otherUserId == null) {
				return 0; // both are null, consider them equal
			} else {
				return -1; // thisUserId is null, otherUserId is not, consider this less than other
			}
		} else {
			// thisUserId is not null
			return thisUserId.compareTo(otherUserId);
		}
	}

	// To Delete Friend
	public int getIdByName(String name) {
		int friendId = -1; // Default value if the friend's ID is not found

		try (Connection connection = DriverManager.getConnection(
				"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
				"1020304050Ss");
				PreparedStatement statement = connection
						.prepareStatement("SELECT accountsID FROM Accounts WHERE username = ?")) {
			statement.setString(1, name);
			ResultSet resultSet = statement.executeQuery();

			if (resultSet.next()) {
				friendId = resultSet.getInt("accountsID");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return friendId;
	}

	String getUserNameById(int accountId, Connection connection) throws SQLException {
		String username = null;
		try (PreparedStatement statement = connection
				.prepareStatement("SELECT username FROM Accounts WHERE accountsID = ?")) {
			statement.setInt(1, accountId);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				username = resultSet.getString("username");
			}
		}
		return username;
	}

	public boolean isOnline() {
		// TODO Auto-generated method stub
		return false;
	}

	public ArrayList<User> getFriendslist() {
		return Friendslist;
	}

	public void setFriendslist(ArrayList<User> friendslist) {
		Friendslist = friendslist;
	}

}
