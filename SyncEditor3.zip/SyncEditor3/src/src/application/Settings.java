package src.application;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javafx.css.converter.StringConverter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.LocalDateStringConverter;

public class Settings {

	boolean isName = false; // to chick if the account name is exist
	boolean isEmail = false; // to chick if the email is exist

	String userName = "";
//	Date DOB = null;
//	Date ddd = null;
	String userpass = "";
	String usereimal = "";
	String userPhone = "";

	public VBox MYSettings(int accountID) {

		// the account informations
		try {
			Main.conne.connectDB();

			// Create a statement object to execute the query
			Statement statement = Main.conne.connect().createStatement();

			// Execute the query and get the result set
			ResultSet result = statement.executeQuery("select * from Accounts where accountsID = " + accountID + ";");

			if (result.next()) {
				userName = result.getString("userName");
				userpass = result.getString("pass");
				usereimal = result.getString("gmail");
//				DOB = result.getDate("DateOfBirth");
				userPhone = result.getString("phone");
				System.out.println(userName + " " + userpass + " " + usereimal + " " + userPhone);
			}

			result.close();
			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// Handle other SQLExceptions, if necessary
			System.err.println("SQL error occurred: " + e.getMessage());
		}

		VBox screen = new VBox(10);

		Pane topPane = new Pane();

		Pane pane = new Pane();
		ScrollPane scrollPane = new ScrollPane();

		scrollPane.setLayoutX(5);
		// scrollPane.setLayoutY(170);
		scrollPane.setContent(pane);
		scrollPane.setPrefSize(1110, 620);
		scrollPane.setStyle("-fx-background-color:white;");

		HBox title = new HBox(10);
		title.getStyleClass().add("hboxes");
		title.setLayoutX(30);
		title.setLayoutY(30);

		ImageView settingsIcon = new ImageView(new Image("Setting.png"));
		settingsIcon.setFitWidth(40);
		settingsIcon.setFitHeight(40);
		topPane.getChildren().add(settingsIcon);

		Label mySettings = new Label("Settins");
		mySettings.getStyleClass().add("tit");
		mySettings.setLayoutX(222);
		topPane.getChildren().add(mySettings);

		title.getChildren().addAll(settingsIcon, mySettings);
		topPane.getChildren().add(title);

		Button save = new Button("Save Changes");
		save.getStyleClass().add("butt");
		save.setLayoutX(1050);
		save.setLayoutY(40);
		save.setFont(new Font(20));

		topPane.getChildren().add(save);

		Line line = new Line(20, 100, 1240, 100);
		topPane.getChildren().add(line);
//_________________________________________________________________________________

		// display user icon
		ImageView userImage = new ImageView();
		userImage.setFitWidth(180);
		userImage.setFitHeight(180);

		// Create a Circle object to use as a clipping shape
		Circle clip = new Circle(90, 90, 90);

		// Set the clipping shape to the image view
		userImage.setClip(clip);
		userImage.setLayoutX(90);
		userImage.setLayoutY(50);
		pane.getChildren().add(userImage);

		Circle editimage = new Circle(90, 0, 90);

		Button editUserImage = new Button("Edit");
		editUserImage.getStyleClass().add("e");
		// Set the clip for the button
		editUserImage.setClip(editimage);
		editUserImage.setLayoutX(90);
		editUserImage.setLayoutY(140);
		editUserImage.setPrefWidth(180);
		editUserImage.setPrefHeight(180); // Fixed the typo here (changed prefHeight to setPrefHeight)
		pane.getChildren().add(editUserImage);

		Image image1 = getImageFromDatabase(accountID);

		if (image1 != null) {
			userImage.setImage(image1);
			// Add imageView to your JavaFX scene or layout
		} else {
			System.out.println("Failed to retrieve the image from the database.");
		}

		editUserImage.setOnAction(event -> {
			// Create a file chooser
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Select Image File");
			// Set filters to only allow image files
			fileChooser.getExtensionFilters().addAll(
					new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif", "*.bmp", "*.jpeg"));

			// Show open file dialog
			File selectedFile = fileChooser.showOpenDialog(new Stage());
			if (selectedFile != null) {
				// Load the selected image file and display it in the ImageView
				Image image = new Image(selectedFile.toURI().toString());
				userImage.setImage(image);
				Main.theMain.updateImage(image);
				uploadImage(selectedFile, accountID);
			}
		});

		Circle active = new Circle(15, Color.GREEN);
		active.setLayoutX(240);
		active.setLayoutY(210);
		pane.getChildren().add(active);

//__________________________________________________________________________________
//__________________________________________________________________________________		

//		// user name
		Text user = new Text("User Name:");
		pane.getChildren().add(user);
		user.setLayoutX(100);
		user.setLayoutY(300);
		user.setFont(new Font(22));

		TextField username = new TextField(userName);
		username.setLayoutX(100);
		username.setLayoutY(310);
		username.setPrefWidth(350);
		username.setPrefHeight(40);
		username.setFont(new Font(20));
		pane.getChildren().add(username);
		username.setEditable(false);

		Image sea = new Image("edit.png");

		ImageView nameIcon = new ImageView(sea);
		nameIcon.setFitWidth(34);
		nameIcon.setFitHeight(34);

		Button namebutton = new Button();
		namebutton.getStyleClass().add("sett");
		namebutton.setLayoutX(450);
		namebutton.setLayoutY(310);
		namebutton.setGraphic(nameIcon);
		pane.getChildren().add(namebutton);

		// Ability to change name
		namebutton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				username.setEditable(true);
			}
		});

////		// date of birth
//		Text date = new Text("Date Of Birth:");
//		pane.getChildren().add(date);
//		date.setLayoutX(100);
//		date.setLayoutY(400);
//		date.setFont(new Font(22));

		// Convert java.sql.Date to LocalDate
//		LocalDate localDate = ((java.sql.Date) DOB).toLocalDate();

//		// Create a DatePicker control
//		DatePicker datePicker = new DatePicker();
//
//		// Create a custom date format
//		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//
//		// Create a StringConverter to convert between LocalDate and String using the
//		// date format
//		LocalDateStringConverter stringConverter = new LocalDateStringConverter(dateFormatter, null);
//		// Set the StringConverter on the DatePicker
//		datePicker.setConverter(stringConverter);
//		datePicker.setLayoutX(100);
//		datePicker.setLayoutY(410);
//		datePicker.setPrefWidth(375);
//		datePicker.setPrefHeight(48);
//		pane.getChildren().add(datePicker);
//		datePicker.setEditable(false);
//		datePicker.setValue(localDate);
//
//		datePicker.setOnAction(event -> {
//			LocalDate selectedDate = datePicker.getValue();
//			ddd = Main.signup.convertToDate(selectedDate);
//			System.out.println(ddd);
//
//		});

		// email:
		Text email = new Text("Email:");
		pane.getChildren().add(email);
		email.setLayoutX(100);
		email.setLayoutY(400);
		email.setFont(new Font(22));

		TextField email_ = new TextField(usereimal);
		email_.setLayoutX(100);
		email_.setLayoutY(410);
		email_.setPrefWidth(350);
		email_.setPrefHeight(40);
		email_.setFont(new Font(20));
		pane.getChildren().add(email_);
		email_.setEditable(false);

		ImageView emailIcon = new ImageView(new Image("edit.png"));
		emailIcon.setFitWidth(34);
		emailIcon.setFitHeight(34);

		Button editEmailbutton = new Button();
		editEmailbutton.getStyleClass().add("sett");
		editEmailbutton.setLayoutX(450);
		editEmailbutton.setLayoutY(410);
		editEmailbutton.setGraphic(emailIcon);
		pane.getChildren().add(editEmailbutton);

		// Ability to change email
		editEmailbutton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				email_.setEditable(true);
			}
		});

		// phone number:
		Text phone = new Text("Phone:");
		pane.getChildren().add(phone);
		phone.setLayoutX(100);
		phone.setLayoutY(500);
		phone.setFont(new Font(22));

		TextField phone_ = new TextField(userPhone);
		phone_.setLayoutX(100);
		phone_.setLayoutY(510);
		phone_.setPrefWidth(350);
		phone_.setPrefHeight(40);
		phone_.setFont(new Font(20));
		pane.getChildren().add(phone_);
		phone_.setEditable(false);

		ImageView phoneIcon = new ImageView(new Image("edit.png"));
		phoneIcon.setFitWidth(34);
		phoneIcon.setFitHeight(34);

		Button editphonebutton = new Button();
		editphonebutton.getStyleClass().add("sett");
		editphonebutton.setLayoutX(450);
		editphonebutton.setLayoutY(510);
		editphonebutton.setGraphic(phoneIcon);
		pane.getChildren().add(editphonebutton);

		// Ability to change email
		editphonebutton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				phone_.setEditable(true);
			}
		});

		// password
		Text pass = new Text("New Password:");
		pane.getChildren().add(pass);
		pass.setLayoutX(100);
		pass.setLayoutY(600);
		pass.setFont(new Font(22));

		PasswordField password = new PasswordField();
		password.setLayoutX(100);
		password.setLayoutY(610);
		password.setPrefWidth(350);
		password.setPrefHeight(40);
		password.setFont(new Font(20));
		pane.getChildren().add(password);
		password.setEditable(false);

		// set user's password
		password.setText(userpass);

		ImageView passIcon = new ImageView(new Image("edit.png"));
		passIcon.setFitWidth(34);
		passIcon.setFitHeight(34);

		Button passbutton = new Button();
		passbutton.getStyleClass().add("sett");
		passbutton.setLayoutX(450);
		passbutton.setLayoutY(610);
		passbutton.setGraphic(passIcon);
		pane.getChildren().add(passbutton);

		// Ability to change password
		passbutton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				password.setEditable(true);
			}
		});

		// confirm new password
		Text pass2 = new Text("Confirm New PAssword:");
		pane.getChildren().add(pass2);
		pass2.setLayoutX(100);
		pass2.setLayoutY(700);
		pass2.setFont(new Font(22));

		PasswordField password2 = new PasswordField();
		password2.setLayoutX(100);
		password2.setLayoutY(710);
		password2.setPrefWidth(350);
		password2.setPrefHeight(40);
		password2.setFont(new Font(20));
		pane.getChildren().add(password2);
		password2.setEditable(false);

		password2.setText(userpass);

		ImageView pass2Icon = new ImageView(new Image("edit.png"));
		pass2Icon.setFitWidth(34);
		pass2Icon.setFitHeight(34);

		Button pass2button = new Button();
		pass2button.getStyleClass().add("sett");
		pass2button.setLayoutX(450);
		pass2button.setLayoutY(710);
		pass2button.setGraphic(pass2Icon);
		pane.getChildren().add(pass2button);

		pass2button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				password2.setEditable(true);
			}
		});

		// show my password
		Text showPass = new Text("Show My Password");
		showPass.getStyleClass().add("show");
		showPass.setStyle("-fx-underline: true;");
		// showPass.setFill(Color.CRIMSON);
		pane.getChildren().add(showPass);
		showPass.setLayoutX(100);
		showPass.setLayoutY(770);

		showPass.setOnMouseClicked(e -> {
			showMyPass(password2);
		});

		// delete account
		ImageView del2Icon = new ImageView(new Image("DeleteFriend.png"));
		del2Icon.setFitWidth(40);
		del2Icon.setFitHeight(40);

		Button deleteAccount = new Button("Delete This Account!");
		deleteAccount.getStyleClass().add("del");
		deleteAccount.setLayoutX(100);
		deleteAccount.setLayoutY(850);
		deleteAccount.setGraphic(del2Icon);
		pane.getChildren().add(deleteAccount);

		deleteAccount.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				deleteMyAccount(accountID, email_.getText());
			}
		});

		Text matchPass = new Text(" ");
		matchPass.setFill(Color.RED);
		matchPass.setLayoutX(100);
		matchPass.setLayoutY(800);
		pane.getChildren().add(matchPass);

		// Add an EventHandler to the textProperty
		password.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (password.getText().trim().isEmpty()) {
				password.getStyleClass().clear();
				password.getStyleClass().add("textField");
			} else if (!Main.chickpass.isStrongPassword(newValue)) {
				System.out.println("Current Password: " + newValue);
				password.getStyleClass().clear();
				password.getStyleClass().add("errorTextF2");
				matchPass.setText("Weak Password");
			} else {
				password.getStyleClass().clear();
				password.getStyleClass().add("greenTextF");
				matchPass.setText("Strong Password");
				matchPass.setFill(Color.GREEN);

			}
		});

		// Add an EventHandler to the textProperty
		password2.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (password2.getText().trim().isEmpty()) {
				matchPass.setText(" ");
				password2.getStyleClass().clear();
				password2.getStyleClass().add("textField");
			} else if (!password.getText().equals(password2.getText())) {
				System.out.println("Current Password: " + newValue);
				password2.getStyleClass().clear();
				password2.getStyleClass().add("errorTextF2");
				matchPass.setText("Password not matching");
				matchPass.setFill(Color.RED);

			} else {
				matchPass.setText(" ");
				password2.getStyleClass().clear();
				password2.getStyleClass().add("greenTextF");

			}
		});

		save.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

				// check the use name:
				try {
					Main.conne.connectDB();

					// Create a statement object to execute the query
					Statement statement = Main.conne.connect().createStatement();

					// Execute the query and get the result set
					ResultSet result = statement
							.executeQuery("select userName from Accounts where accountsID != " + accountID + ";");

					while (result.next()) {
						if (result.getString("userName").equals(username.getText())) {
							Main.signup.existedAccountName();
							System.out.println("error the account is exist");
							isName = true;
							break;
						} else
							isName = false;
					}

					result.close();
					statement.close();
					Main.conne.connect().close();

				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// Handle other SQLExceptions, if necessary
					System.err.println("SQL error occurred: " + e.getMessage());
				}

				// chick if the email is exist or not:
				try {
					Main.conne.connectDB();

					// Create a statement object to execute the query
					Statement statement = Main.conne.connect().createStatement();

					// Execute the query and get the result set
					ResultSet result = statement
							.executeQuery("select gmail from Accounts where accountsID != " + accountID + ";");

					while (result.next()) {
						if (result.getString("gmail").equals(usereimal)) {
							Main.signup.existedAccountEmail();
							System.out.println("error the email is exist");
							isEmail = true;
							break;
						} else
							isEmail = false;
					}

					result.close();
					statement.close();
					Main.conne.connect().close();

				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// Handle other SQLExceptions, if necessary
					System.err.println("SQL error occurred: " + e.getMessage());
				}

				if (!isName || !isEmail || !userPhone.equals(phone_.getText())
//						|| !DOB.equals(java.sql.Date.valueOf(datePicker.getValue()))
						|| !userpass.equals(password.getText())) {

					if (password2.getText().equals(password.getText())) {

//						if (ddd != null) {
						Main.isSaved = true;
						VerificationSetting ver = new VerificationSetting(email_.getText(), phone_.getText(),
								username.getText(), password.getText(), accountID + "");
					}
				}

//				}
			}
		});

		screen.getChildren().addAll(topPane, scrollPane);

		return screen;
	}

	public void deleteMyAccount(int accountID, String gmail) {
		Stage stage = new Stage();
		stage.setTitle("Delete Account");

		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		ImageView AIcon = new ImageView(new Image("DeleteAccountWarning.png"));
		AIcon.setLayoutX(250);
		AIcon.setLayoutY(20);
		pane.getChildren().add(AIcon);

		Text title = new Text("DELETE ACCOUNT!!!");
		title.setFont(new Font(25));
		title.setLayoutX(200);
		title.setLayoutY(140);
		title.setStyle("-fx-font-weight: bold;");
		pane.getChildren().add(title);

		Text text = new Text(
				"By deleting your account, All Files, Friends, and shared projects will be deleted PERMANENTLY. "
						+ "\n\n\nThis CANNOT be undone.");
		text.setWrappingWidth(540);
		text.setLayoutX(30);
		text.setLayoutY(210);
		pane.getChildren().add(text);
		text.setFill(Color.RED);
		text.getStyleClass().add("Dtext");

		Text str = new Text("Type DELETE (in ALL CAPS) to delete your account and all of your data permanently.");
		str.setWrappingWidth(540);
		str.setLayoutX(30);
		str.setLayoutY(370);
		pane.getChildren().add(str);
		str.setStyle("-fx-font-weight: bold;");
		str.setFont(new Font(20));

		TextField enter = new TextField();
		enter.setPromptText("DELETE");
		enter.setPrefHeight(25);
		pane.getChildren().add(enter);
		enter.setLayoutX(30);
		enter.setLayoutY(430);
		enter.setFont(new Font(18));

		Button Cancel = new Button("Cancel");
		pane.getChildren().add(Cancel);
		Cancel.setFont(new Font(20));
		Cancel.getStyleClass().add("cancel");
		Cancel.setLayoutX(270);
		Cancel.setLayoutY(510);

		// cancel the deletion my account
		Cancel.setOnAction(e -> {
			stage.close();
		});

		Button delete = new Button("Delete My Account");
		pane.getChildren().add(delete);
		delete.setFont(new Font(20));
		delete.getStyleClass().add("delete");
		delete.setLayoutX(380);
		delete.setLayoutY(510);

		delete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				// verify if the text in the text-field == DELETE
				if (enter.getText().equals("DELETE")) {

					VerificationDeleteAccount ver = new VerificationDeleteAccount(accountID + "", stage, gmail);

				} else {
					wrongeDELETE();
				}
			}
		});

		Scene scene = new Scene(pane, 600, 600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public void wrongeDELETE() {
		Stage stage = new Stage();
		stage.setTitle("Deletion Incomplete.");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("Icon.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("error.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(65);
		AIcon.setFitHeight(65);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(20);
		pane.getChildren().add(AIcon);

		Text roles = new Text("Error Deleting Account: text written not\n\n equal to 'DELETE'.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 18));
		roles.setLayoutX(100);
		roles.setLayoutY(50);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		// ok.getStyleClass().add("butt");
		ok.setLayoutX(300);
		ok.setLayoutY(120);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 180);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	private void uploadImage(File imageFile, int id) {
		try {
			Main.conne.connectDB();

			// Read the image file into a byte array
			byte[] imageData = readImageFile(imageFile);

			// SQL query with a prepared statement to update the image
			String sql = "UPDATE Accounts SET image = ? WHERE accountsID = " + id + ";";

			try (PreparedStatement preparedStatement = Main.conne.connect().prepareStatement(sql)) {
				// Set the image data as a parameter
				preparedStatement.setBytes(1, imageData);

				// Execute the update
				int rowsUpdated = preparedStatement.executeUpdate();

				if (rowsUpdated > 0) {
					System.out.println("Image updated successfully!");
				} else {
					System.out.println("Failed to update image.");
				}
			}

			Main.conne.connect().close();
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}

	private byte[] readImageFile(File imageFile) throws IOException {
		try (FileInputStream fis = new FileInputStream(imageFile)) {
			byte[] imageData = new byte[(int) imageFile.length()];
			fis.read(imageData);
			return imageData;
		}
	}

	public Image getImageFromDatabase(int id) {
		try {
			Main.conne.connectDB();

			// SQL query to select the image data
			String sql = "SELECT image FROM Accounts WHERE accountsID = " + id + ";";

			try (Statement statement = Main.conne.connect().createStatement()) {
				// Execute the query
				ResultSet resultSet = statement.executeQuery(sql);

				if (resultSet.next()) {
					// Get the image data from the result set
					byte[] imageData = resultSet.getBytes("image");

					ByteArrayInputStream bis = null;
					// Convert the image data to a JavaFX Image
					if (imageData != null) {
						bis = new ByteArrayInputStream(imageData);

						return new Image(bis);
					}
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {

				if (Main.conne.connect() != null && !Main.conne.connect().isClosed()) {
					Main.conne.connect().close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	private void showMyPass(PasswordField p) {
		Stage stage = new Stage();

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("Icon.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();
		pane.setStyle("-fx-background-color:white;");

		Image backImg = new Image("show.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text("Your Password is:\n\n'" + p.getText() + "'");
		roles.setWrappingWidth(220);
		roles.setFont(new Font("Arial", 20));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(55, 20);
		// ok.getStyleClass().add("butt");
		ok.setLayoutX(220);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 350, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

}
