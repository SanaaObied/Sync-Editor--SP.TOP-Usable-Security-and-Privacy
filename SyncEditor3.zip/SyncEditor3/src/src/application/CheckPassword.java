package src.application;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckPassword {
	public static boolean isStrongPassword(String password) {
		// Check minimum length
		if (password.length() < 8) {
			return false;
		}

		// Check for at least one uppercase letter
		if (!password.matches(".*[A-Z].*")) {
			return false;
		}

		// Check for at least one lowercase letter
		if (!password.matches(".*[a-z].*")) {
			return false;
		}

		// Check for at least one digit
		if (!password.matches(".*\\d.*")) {
			return false;
		}

		// Check for at least one special character
		Pattern specialCharPattern = Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{};':\",.<>/?]");
		Matcher specialCharMatcher = specialCharPattern.matcher(password);
		if (!specialCharMatcher.find()) {
			return false;
		}

//		// Check for repeated characters (optional)
//		if (hasRepeatedCharacters(password)) {
//			return false;
//		}

		// Check for common words or patterns
		List<String> commonWords = Arrays.asList("12345", "password", "qwerty", "admin", "letmein");
		for (String commonWord : commonWords) {
			if (password.toLowerCase().contains(commonWord.toLowerCase())) {
				return false;
			}
		}

		// All checks passed, the password is strong
		return true;
	}

//	private static boolean hasRepeatedCharacters(String password) {
//		for (int i = 0; i < password.length() - 1; i++) {
//			if (password.charAt(i) == password.charAt(i + 1)) {
//				return true;
//			}
//		}
//		return false;
//	}

}
