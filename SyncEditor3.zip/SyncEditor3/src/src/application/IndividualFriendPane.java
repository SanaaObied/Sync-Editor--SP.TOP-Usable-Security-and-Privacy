package src.application;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class IndividualFriendPane extends VBox {

	private Button sharedFiles, deleteFriend;
//	private User user;// here we will store the user object given from the constructor
	private User user = new User();
	private RemoveFriend removeFriends = new RemoveFriend();
	private SharedFilesInFriendPage SharedFilesInFriendPage = new SharedFilesInFriendPage();
	private String name;
	private IndividualFriendPane IndividualFriendPane;
	private Friends Friends;

	// the constructor should take a user object
	public IndividualFriendPane(Image profilePic, String name, boolean status) {

		// initialization
		this.Friends = Main.friends;
		ImageView sharedFilesImg = new ImageView(new Image("sharedFiles.png"));
		ImageView unfriend = new ImageView(new Image("unfriend.png"));
		sharedFiles = new Button("", sharedFilesImg);
		deleteFriend = new Button("", unfriend);

		// setting properties
		sharedFilesImg.setFitWidth(25);
		sharedFilesImg.setFitHeight(25);
		unfriend.setFitWidth(25);
		unfriend.setFitHeight(25);
		sharedFiles.setPrefSize(25, 25);
		deleteFriend.setPrefSize(25, 25);
		deleteFriend.setStyle("-fx-background-color:white;");
		sharedFiles.setStyle("-fx-background-color:white;");

		// label to how the user name
		Label namelbl = new Label(name);
		namelbl.setFont(Font.font("Times New Roman", 20));

		// to separate the buttons
		Line verticalLine = new Line(17.5, 0, 17.5, 25);
		verticalLine.setStrokeWidth(1.5);

		// to hold the name and buttons
		HBox buttons = new HBox(2);
		buttons.getChildren().addAll(namelbl, sharedFiles, verticalLine, deleteFriend);
		buttons.setAlignment(Pos.CENTER);

		getChildren().addAll(getprofileNode(profilePic, status), buttons);
		setSpacing(10);

		// over here you instead actually delete or show the files shared with them
		sharedFiles.setOnAction(e -> {

			SharedFilesInFriendPage.getStart(name, name);
			System.out.println("you viewed the shared files for " + name);

		});

		deleteFriend.setOnAction(e -> {
			System.out.println("you deleted the friend " + name);
			removeFriends.removeFriends(name);
			IndividualFriendPane = new IndividualFriendPane(profilePic, name, status);
			System.out.println("AHH");
			deleteFriend();
			IndividualFriendPane.getDeleteFriend();
			int friendId = user.getIdByName(name); // Assuming you have a method to get the friend's ID from the
													// Accounts table
			// Find the friend's ID in the beFriends table based on the entered name
			try (Connection connection = DriverManager.getConnection(
					"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
					"pinkflowers");
					PreparedStatement statement = connection.prepareStatement(
							"SELECT * FROM beFriends WHERE (firsts = ? OR seconds = ?) AND (firsts IN (SELECT accountsID FROM Accounts WHERE username = ?) OR seconds IN (SELECT accountsID FROM Accounts WHERE username = ?))")) {
				statement.setInt(1, friendId);
				statement.setInt(2, friendId);
				statement.setString(3, name);
				statement.setString(4, name);
				ResultSet resultSet = statement.executeQuery();

				while (resultSet.next()) {
					int firsts = resultSet.getInt("firsts");
					int seconds = resultSet.getInt("seconds");
					// Retrieve all data from the Accounts table for the friend's IDs
					PreparedStatement accountStatement = connection
							.prepareStatement("SELECT * FROM Accounts WHERE accountsID = ? OR accountsID = ?");
					accountStatement.setInt(1, firsts);
					accountStatement.setInt(2, seconds);
					ResultSet accountResultSet = accountStatement.executeQuery();

					while (accountResultSet.next()) {
						// Retrieve the account data for the friend
						int accountId = accountResultSet.getInt("accountsID");
						String accountUsername = accountResultSet.getString("username");
						Date DateOfBierth = accountResultSet.getDate("DateOfBirth");
						String accountEmail = accountResultSet.getString("gmail");
						Blob blob = accountResultSet.getBlob("image");
						// Convert the Blob object to an Image object
						InputStream inputStream = blob.getBinaryStream();
						Image image = new Image(inputStream);
						String password = accountResultSet.getString("pass");

						System.out.println("Friend ID: " + accountId);
						System.out.println("Friend Username: " + accountUsername);
						// Print or process other relevant account data
						// Remove the friend from the AVL tree or any other data structure you're using
						Account Account = new Account();

						user = new User(accountId, accountUsername, DateOfBierth, accountEmail, image, password);
						// Account.getAvlUser().remove(user);
						user.getFriendslist().remove(user);
					}

					// Delete the friend relationship from the beFriends table
					try (PreparedStatement deleteStatement = connection.prepareStatement(
							"DELETE FROM beFriends WHERE (firsts = ? AND seconds = ?) OR (firsts = ? AND seconds = ?)")) {
						deleteStatement.setInt(1, firsts);
						deleteStatement.setInt(2, seconds);
						deleteStatement.setInt(3, seconds);
						deleteStatement.setInt(4, firsts);
						deleteStatement.executeUpdate();
						System.out.println("Friend relationship deleted from the database");

					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			Friends friends = new Friends();
			this.Friends.deleteFriend(user);
		});

	}

	// gets the picture and status in correct positioning
	public HBox getprofileNode(Image img, boolean status) {

		// Create a circular profile picture
		Circle profileCircle = new Circle(50);
		if (img != null)
			profileCircle.setFill(new ImagePattern(img));
		else {
			profileCircle.setFill(new ImagePattern(new Image("user.png")));

		}

		// Create a circular status indicator
		Circle statusCircle = new Circle(10);

		// Change color based on online status
		if (status)
			statusCircle.setFill(Color.GREEN);
		else
			statusCircle.setFill(Color.RED);

		// Set border color and width
		profileCircle.setStroke(Color.BLACK);
		profileCircle.setStrokeWidth(3);
		statusCircle.setStroke(Color.BLACK);
		statusCircle.setStrokeWidth(3);

		// Create a Horizontal pane box to hold the circles
		HBox completeProfilePic = new HBox(-20);
		completeProfilePic.getChildren().addAll(profileCircle, statusCircle);
		completeProfilePic.setAlignment(Pos.BOTTOM_CENTER);

		return completeProfilePic;

	}

	public Button getSharedFiles() {
		return sharedFiles;
	}

	public void setSharedFiles(Button sharedFiles) {
		this.sharedFiles = sharedFiles;
	}

	public Button getDeleteFriend() {
		return deleteFriend;
	}

	public void setDeleteFriend(Button deleteFriend) {
		this.deleteFriend = deleteFriend;
	}

	public Stage getShareFileWithFriend() {
		Stage s = new Stage();

		Image image = new Image("ICON.png");

		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(270);
		imageView.setFitHeight(190);

		TextField textField = new TextField();
		textField.setPromptText("Search My Friends");
		textField.setStyle("-fx-prompt-text-fill: black;");
		textField.setPrefWidth(300);
		textField.setPrefHeight(40);
		textField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));

		Image image5 = new Image("Search.png");
		ImageView imageView5 = new ImageView(image5);
		imageView5.setFitWidth(40);
		imageView5.setFitHeight(40);

		HBox hBox1 = new HBox();
		hBox1.setAlignment(Pos.CENTER_LEFT);
		hBox1.getChildren().addAll(textField, imageView5);

		// Create an HBox with ImageView, Label, and CheckBox

		ImageView imageView2 = new ImageView(new Image("User1.png"));
		imageView2.setFitWidth(100);
		imageView2.setFitHeight(100);
		HBox contentHBox = createHBox("User1.png", "Sanaa", false);

		HBox contentHBox2 = createHBox("User1.png", "Hanadi", true);
		Separator dashedLine3 = new Separator();
		dashedLine3.getStyleClass().add("dashed-line");
		VBox v2 = new VBox(contentHBox, dashedLine3, contentHBox2);
		v2.setAlignment(Pos.BASELINE_LEFT);
		v2.setSpacing(5); // Adjust spacing as needed
		v2.setPadding(new Insets(10)); // Adjust padding as needed
		v2.setPadding(new Insets(10, 10, 10, 10)); // Adjust padding as needed

		// Create a ScrollPane and set the content to the TableView
		ScrollPane scrollPane = new ScrollPane(v2);

		// Create a ScrollPane and set the content to the VBox
		// scrollPane.setPadding(new Insets(10)); // Adjust padding as needed
		scrollPane.setPrefSize(10, 300);

		Button button1 = new Button("Add");

		// button1.setTextFill(blue);
		button1.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");

		// button2.setTextFill(blue);
		button1.setAlignment(Pos.CENTER);

		VBox v = new VBox(hBox1, scrollPane, button1);
		v.setAlignment(Pos.BASELINE_LEFT);
		v.setSpacing(20); // Adjust spacing as needed

		v.setPadding(new Insets(30, 30, 30, 30)); // Adjust padding as needed
		v.setAlignment(Pos.CENTER);

		s.setTitle("Share with A Friend");
		s.getIcons().add(new Image("ICON.png")); // Set application icon
		Scene scene = new Scene(v, 500, 500);
		v.setStyle("-fx-background-color:#c9e9f6;");

		s.setScene(scene);

		s.show();
		return s;
	}

	private HBox createHBox(String image1Path, String labelText, boolean checkBoxSelected) {
		Image image1 = new Image(image1Path);
		ImageView imageView1 = new ImageView(image1);
		imageView1.setFitWidth(100); // Adjust width as needed
		imageView1.setFitHeight(100); // Adjust height as needed

		Label label = new Label(labelText);
		label.setStyle("-fx-font-size: 25;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");

		CheckBox checkBox = new CheckBox();
		checkBox.setSelected(checkBoxSelected);

		HBox contentHBox = new HBox(90);
		contentHBox.setAlignment(Pos.CENTER);
		contentHBox.getChildren().addAll(imageView1, label, checkBox);

		return contentHBox;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private void deleteFriend() {

		// Remove the friend pane from the Friends view
		Parent parent = this.getParent();
		if (parent instanceof GridPane) {
			GridPane friendsView = (GridPane) parent;
			friendsView.getChildren().remove(this);
		}
	}
}