package src.application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class sql {

	public Connection getConnection() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection connection = DriverManager.getConnection(
				"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
				"1020304050Ss");
		System.out.println("Done");
		return connection;
	}
}
//        String host, port, databaseName, userName, password; 
//        host = "mysql-11ff8582-syncediter.a.aivencloud.com";
//        port = "13589";
//        databaseName = "defaultdb";
//        userName = "avnadmin";
//        password = "AVNS_yzODTu5KzXTSMM5zBS-";
//        for (int i = 0; i < args.length - 1; i++) {
//            switch (args[i].toLowerCase(Locale.ROOT)) {
//                case "-host":
//                    host = args[++i];
//                    break;
//                case "-username":
//                    userName = args[++i];
//                    break;
//                case "-password":
//                    password = args[++i];
//                    break;
//                case "-database":
//                    databaseName = args[++i];
//                    break;
//                case "-port":
//                    port = args[++i];
//                    break;
//            }
//        }
//        // JDBC allows to have nullable username and password
//        if (host == null || port == null || databaseName == null) {
//            System.out.println("Host, port, database information is required");
//            return;
//        }
//        Class.forName("com.mysql.cj.jdbc.Driver");
//        try (final Connection connection = DriverManager.getConnection(
//                "jdbc:mysql://" + host + ":" + port + "/" + databaseName + "?sslmode=require", userName, password);
//             final Statement statement = connection.createStatement();) {
//
//            statement.execute("CREATE DATABASE IF NOT EXISTS synceditors");
//            statement.execute("USE synceditors");
//
//            statement.execute("CREATE TABLE IF NOT EXISTS Accounts (" + "accountsID INT AUTO_INCREMENT UNIQUE,"
//                    + "userName VARCHAR(255) UNIQUE," + "DateOfBirth DATE," + "gmail VARCHAR(200) UNIQUE,"
//                    + "image VARBINARY(500)," + "pass VARCHAR(255)," + "PRIMARY KEY (accountsID)" + ")");
//
//            statement.execute("INSERT INTO Accounts (userName, DateOfBirth, gmail, image, pass) " +
//                    "VALUES ('EnassHamayel', '2000-02-23', 'enasHamayell1@gmail.com', 'User.png', '1234!!')");
//            connection.close();
//
//            statement.execute("CREATE TABLE IF NOT EXISTS Files (" + "fileID INT AUTO_INCREMENT,"
//                    + "fileName VARCHAR(250)," + "accountsID INT," + "texts BLOB," + "PRIMARY KEY (fileID),"
//                    + "FOREIGN KEY (accountsID) REFERENCES Accounts(accountsID)" + ")");
//            connection.close();
//
//            statement.execute("CREATE TABLE IF NOT EXISTS Editors (" + "editorsID INT AUTO_INCREMENT,"
//                    + "privilege BOOLEAN," + "fileID INT," + "editor INT," + "PRIMARY KEY (editorsID),"
//                    + "FOREIGN KEY (fileID) REFERENCES Files(fileID),"
//                    + "FOREIGN KEY (editor) REFERENCES Accounts(accountsID)" + ")");
//            connection.close();
//
//            statement.execute("CREATE TABLE IF NOT EXISTS FriendsRequest (" + "requestsID INT AUTO_INCREMENT,"
//                    + "sender INT," + "receiver INT," + "PRIMARY KEY (requestsID),"
//                    + "FOREIGN KEY (sender) REFERENCES Accounts(accountsID),"
//                    + "FOREIGN KEY (receiver) REFERENCES Accounts(accountsID)" + ")");
//            connection.close();
//
//            statement.execute("CREATE TABLE IF NOT EXISTS beFriends (" + "firsts INT," + "seconds INT,"
//                    + "PRIMARY KEY (firsts, seconds)," + "FOREIGN KEY (firsts) REFERENCES Accounts(accountsID),"
//                    + "FOREIGN KEY (seconds) REFERENCES Accounts(accountsID)" + ")");
//            connection.close();
//
//            statement.execute("CREATE TABLE IF NOT EXISTS shareFile (" + "sender INT," + "receiver INT," + "fileID INT,"
//                    + "PRIMARY KEY (sender, receiver, fileID),"
//                    + "FOREIGN KEY (sender) REFERENCES Accounts(accountsID),"
//                    + "FOREIGN KEY (receiver) REFERENCES Accounts(accountsID),"
//                    + "FOREIGN KEY (fileID) REFERENCES Files(fileID)" + ")");
//            connection.close();
//
//            System.out.println("Tables created successfully");
//        } catch (SQLException e) {
//            System.out.println("Connection failure.");
//            e.printStackTrace();
//        }
//    }
//
//    public Connection getConnection() throws SQLException {
//        String host = "mysql-11ff8582-syncediter.a.aivencloud.com";
//        String port = "13589";
//        String databaseName = "defaultdb";
//        String userName = "avnadmin";
//        String password = "AVNS_yzODTu5KzXTSMM5zBS-";
//
//        String connectionString = "jdbc:mysql://" + host + ":" + port + "/" + databaseName + "?sslmode=require";
//        return DriverManager.getConnection(connectionString, userName, password);
//    }
