package src.application;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class VerificationSignUp extends BorderPane {

	public static final String ACCOUNT_SID = "AC1e32cbe43e28cfceff9cd28ff2030f35";
	public static final String AUTH_TOKEN = "bb4baa1fad64856ef9e2b5e114c85780";

	private Label resend, back;
	private TextField code;
	private Button continueButton;
	private String gmail, phone, userName, pass;
	private int theCode;

	public VerificationSignUp(String userName, String gmail, String pass, String phone) {

		this.gmail = gmail;
		this.phone = phone;
		this.pass = pass;
		this.userName = userName;

		resend = new Label("Resend.");
		code = new TextField();
		continueButton = new Button("Continue");
		back = new Label();
		ImageView verifyImg = new ImageView(new Image("Verification.png"));
		ImageView lockImg = new ImageView(new Image("Lock.png"));
		ImageView arrow = new ImageView(new Image("arrow.png"));
		Label question = new Label("Didn't receive a code? ");
		Label header = new Label("Verification");
		Label context;
		context = new Label("Please enter the 6 digit verification code sent to your email:");

		Stage stage = new Stage();

		resend.setOnMouseClicked(e -> {
			sendEmail();
			code.clear();
		});

		continueButton.setOnAction(e -> {
			if (theCode == Integer.parseInt(code.getText())) {

				stage.close();
				enterAccount();
				Main.signup.done();

			}

			else {
				stage.close();
				Main.signup.signUp();
				Main.warning.WarningMessage("", "Verification Failed because the code is incorrect. Try Again!!");

			}

		});

		back.setOnMouseClicked(e -> {
			stage.close();
			Main.signup.signUp();

		});

		// setting properties
		arrow.setFitWidth(40);
		arrow.setFitHeight(40);
		lockImg.setFitWidth(30);
		lockImg.setFitHeight(30);
		verifyImg.setFitWidth(55);
		verifyImg.setFitHeight(55);
		continueButton.setPrefSize(200, 20);
		continueButton.getStyleClass().add("login");
		resend.getStyleClass().add("forget");
		code.setPrefSize(210, 35);
		back.setContentDisplay(ContentDisplay.LEFT);
		back.setGraphic(arrow);
		context.setFont(Font.font("Microsoft Himalaya", 30));
		header.getStyleClass().add("login-Header");
		header.setGraphic(verifyImg);
		header.setContentDisplay(ContentDisplay.LEFT);
		header.setGraphicTextGap(20);

		// The line to re-send the code
		HBox resendCode = new HBox();
		resendCode.getChildren().addAll(question, resend, new Label("                    "));
		resendCode.setAlignment(Pos.CENTER);

		// center inputs
		GridPane inputs = new GridPane();
		inputs.add(code, 0, 0);
		inputs.add(lockImg, 1, 0);
		inputs.add(resendCode, 0, 1);
		inputs.setAlignment(Pos.CENTER);
		inputs.setHgap(10);
		inputs.setVgap(5);
		inputs.setPadding(new Insets(0, 0, 40, 0));

		VBox middle = new VBox(30);
		middle.getChildren().addAll(header, context, inputs, continueButton);
		middle.setAlignment(Pos.TOP_CENTER);

		setTop(back);
		setAlignment(back, Pos.CENTER_LEFT);
		setPadding(new Insets(15, 15, 20, 15));
		setStyle("-fx-background-color:white;");
		setCenter(middle);
		openInStage(stage);

	}

	private void enterAccount() {

		try {
			Main.conne.connectDB();

			Main.conne.ExecuteStatement("INSERT INTO Accounts (userName, gmail, image, pass, phone) VALUES ('"
					+ userName + "', '" + gmail + "', NULL, '" + pass + "', '" + phone + "'); ");

			// Create a statement object to execute the query
			Statement statement = Main.conne.connect().createStatement();

			statement.execute("INSERT INTO Accounts (userName, gmail, image, pass) VALUES ('" + userName + "',  '"
					+ gmail + "', NULL, '" + pass + "', '" + phone + "'); ");

			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// Handle other SQLExceptions, if necessary
			System.err.println("SQL error occurred: " + e.getMessage());
		}

	}

	private void openInStage(Stage stage) {

		sendEmail();
		Scene scene = new Scene(this, 600, 410);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.show();

	}

	private void sendSMS() {

		RandomNumberGenerator();
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		Message message = Message.creator(new com.twilio.type.PhoneNumber("+97" + phone),
				new com.twilio.type.PhoneNumber("+14436740477"), "" + theCode).create();

	}

	private void sendEmail() {

		RandomNumberGenerator();
		App app = new App(gmail, theCode);

	}

	private void RandomNumberGenerator() {

		Random random = new Random();
		theCode = 100000 + random.nextInt(900000);

	}

	public Label getResend() {
		return resend;
	}

	public TextField getCode() {
		return code;
	}

	public Button getContinueButton() {
		return continueButton;
	}

	public Label getBack() {
		return back;
	}

}
