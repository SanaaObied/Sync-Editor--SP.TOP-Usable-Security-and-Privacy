package src.application;

import java.io.FileNotFoundException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class App {
	// private static final String USERNAME = "sanaobied2@gmail.com";
	// private static final String PASSWORD = "rbcv iinb eriq bsdv";
	private static final String USERNAME = "syncediter@gmail.com";

	private static final String PASSWORD = "rtnp sijp uwxn hsna";

	public App(String email) {
		String message = "Hello! You Are invited to edit at your friends workspace.";
		String subject = "Sync Editor: Workspace Invite.";
		String to = email;
		String from = "syncediter@gmail.com";

		sendAttach(message, subject, to, from);
	}

	public App(String email, int code) {

		getMasseges(email, code);

	}

	public void getMasseges(String email, int code) {
		System.out.println("Preparing to send message...");
		String message = "Hello! Your verification code is " + code
				+ " Enter this code in our Sync Editor app to continue to your account.";
		String subject = "Sync Editor Account Verification";
		String to = email;
		// String to = "hanadibyrd2003@gmail.com";
		// String to = "woroodassi345@gmail.com
		// String to = "enasthabet05@gmail.com";
		String from = "syncediter@gmail.com";

		sendAttach(message, subject, to, from);
	}

	public void sendAttach(String message, String subject, String to, String from) {
		Properties properties = new Properties();
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.ssl.protocols", "TLSv1.2");
//		properties.put("mail.smtp.ssl.ciphersuites", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
		properties.put("mail.smtp.ssl.trust", "*");

		try {
			Session session = Session.getInstance(properties, new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(USERNAME, PASSWORD);
				}
			});

			session.setDebug(true);

			MimeMessage mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(from));
			mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			mimeMessage.setSubject(subject);

			MimeBodyPart textPart = new MimeBodyPart();
			textPart.setText(message);

			MimeBodyPart filePart = new MimeBodyPart();
			try {
				filePart.attachFile("ICON.png");
			} catch (FileNotFoundException e) {
				System.out.println("File not found: pic.png");
				e.printStackTrace();
				// You can choose to continue without attaching the file or handle it in another
				// way
				return;
			}

			MimeMultipart multipart = new MimeMultipart();
			multipart.addBodyPart(textPart);
			// multipart.addBodyPart(filePart);

			mimeMessage.setContent(multipart);

			Transport.send(mimeMessage);

			System.out.println("Sent successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}