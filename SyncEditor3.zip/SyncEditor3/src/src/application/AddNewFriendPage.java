package src.application;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class AddNewFriendPage extends BorderPane {
	private Button searchButton;
	private TextField search;
	private VBox searchResult;
	private ArrayList<User> addFriends = new ArrayList<>();

	public AddNewFriendPage() {

		ImageView searchImg = new ImageView(new Image("Search.png"));
		search = new TextField();
		searchButton = new Button("", searchImg);

		searchImg.setFitWidth(25);
		searchImg.setFitHeight(25);

		searchButton.setStyle("-fx-background-color:white; -fx-border-color:black;");
		searchButton.setPrefSize(45, 45);

		search.setStyle("-fx-border-color:black;");
		search.setFont(Font.font("Times New Roman", FontWeight.BOLD, 17));
		search.setPromptText("Search ");
		searchButton.setOnAction(e -> {
			try {
				searchFriends(search.getText());
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		search.setPrefSize(255, 45);

		// to hold the search gear
		HBox searching = new HBox(3);
		searching.getChildren().addAll(new Text("    "), search, searchButton);
		searching.setAlignment(Pos.CENTER_LEFT);

		// this vertical box has the result of the searching
		// this should be a loop to fill up with real users from the searching
		////////////////////////////////////////////////////////////////////////////
		searchResult = new VBox(10);
		searchResult.setStyle("-fx-background-color: white;-fx-border-color:black;");
		searchResult.setPadding(new Insets(10, 10, 0, 0));

		searchResult.getChildren().add(new IndividualFriendRequest(false, new Image("ICON.png"), "Enas Hamayel", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("User.png"), "mohammad Asfour", false));
		searchResult.getChildren().add(new IndividualFriendRequest(false, new Image("Lock.png"), "Yaba ismad", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("SignOut.png"), "Oliver Silvia", false));
		searchResult.getChildren().add(new IndividualFriendRequest(true, new Image("File.png"), "Worood Assi", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("ICON.png"), "Hanadi Asfour", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("User.png"), "mohammad Asfour", false));
		searchResult.getChildren().add(new IndividualFriendRequest(false, new Image("Lock.png"), "Yaba ismad", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("SignOut.png"), "Oliver Silvia", false));
		searchResult.getChildren().add(new IndividualFriendRequest(true, new Image("File.png"), "Worood Assi", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("ICON.png"), "Hanadi Asfour", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("User.png"), "mohammad Asfour", false));
		searchResult.getChildren().add(new IndividualFriendRequest(false, new Image("Lock.png"), "Yaba ismad", true));
		searchResult.getChildren()
				.add(new IndividualFriendRequest(false, new Image("SignOut.png"), "Oliver Silvia", false));
		searchResult.getChildren().add(new IndividualFriendRequest(true, new Image("File.png"), "Worood Assi", true));
		////////////////////////////////////////////////////////////////////////////

		// Create the ScrollPane for the search results
		ScrollPane results = new ScrollPane();
		results.setPrefWidth(250);
		results.setPrefHeight(400);
		results.setHbarPolicy(ScrollBarPolicy.NEVER);
		results.setContent(searchResult);
		results.setStyle("-fx-background-color: white;-fx-border-color:black;-fx-border-width:2;");

		// Create and configure the search controls
		TextField search = new TextField();
		Button searchButton = new Button("Search");

		// Set the layout and content of the main container
		setTop(searching);
		setCenter(results);
		setLeft(new Text("           "));
		setRight(new Text("            "));
		VBox decoy = new VBox(20);
		decoy.getChildren().addAll(new Text("       "), new Text("       "));
		setBottom(decoy);

		setMargin(searching, new Insets(10, 0, 20, 20));
		setStyle("-fx-background-color: rgb(238,250,255);");
		setPadding(new Insets(10, 0, 0, 0));

		// Call getAllRequesrt to populate the allAccounts list with user data
		try {
			getAllRequesrt();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void searchFriends(String searchText) throws SQLException {
		// Clear the searchResult VBox before adding new search results
		this.searchResult.getChildren().clear();

		// Filter the users based on the search text
		ArrayList<User> filteredUsers = filterUsers(addFriends, searchText);

		// Add the filtered users to the searchResult VBox
		for (User user : filteredUsers) {
			Image userImage = user.getImage();
			String userUsername = user.getUserName();
			boolean online = user.isOnline();

			IndividualFriendRequest friendRequest = new IndividualFriendRequest(online, userImage, userUsername, true);
			this.searchResult.getChildren().add(friendRequest);

		}
	}

	public void addFriend(Image image, String name, boolean online, int column, int row) {
		IndividualFriendPane friendPane = new IndividualFriendPane(image, name, online);
		GridPane.setConstraints(friendPane, column, row);
		searchResult.getChildren().add(friendPane);
	}

	private ArrayList<User> filterUsers(ArrayList<User> users, String searchText) {
		ArrayList<User> filteredUsers = new ArrayList<>();

		for (User user : users) {
			if (user.getUserName().toLowerCase().contains(searchText.toLowerCase())) {
				filteredUsers.add(user);
			}
		}

		return filteredUsers;
	}

	private ArrayList<User> getAllRequesrt() throws SQLException {
		// Prepare and execute the query to retrieve the receiver IDs from

		String query = "SELECT reciver FROM FriendsRequst";
		Connection connection = DriverManager.getConnection(
				"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
				"pinkflowers");
		PreparedStatement statement = connection.prepareStatement(query);
		ResultSet resultSet = statement.executeQuery();

		// Process the query results
		while (resultSet.next()) {
			int receiverID = resultSet.getInt("reciver");

			// Retrieve receiver information from the Accounts table
			String accountQuery = "SELECT * FROM Accounts WHERE accountsID = ?";
			PreparedStatement accountStatement = connection.prepareStatement(accountQuery);
			accountStatement.setInt(1, receiverID);
			ResultSet accountResultSet = accountStatement.executeQuery();

			if (accountResultSet.next()) {
				// Retrieve other user information from the Accounts table
				int accountsID = accountResultSet.getInt("accountsID");
				String username = accountResultSet.getString("username");
				Date DOB = accountResultSet.getDate("DateOfBirth");
				String Gmail = accountResultSet.getString("gmail");
				String password = accountResultSet.getString("pass");
				Blob blob = accountResultSet.getBlob("image");
				// Convert the Blob object to an Image object
				InputStream inputStream = blob.getBinaryStream();
				Image image = new Image(inputStream);
				User User = new User(accountsID, username, DOB, Gmail, image, password);
				addFriends.add(User);
			}

			// Close the accountStatement and accountResultSet
			accountResultSet.close();
			accountStatement.close();
		}
		return addFriends;
	}// The filterUsers method remains the same:

	private List<User> filterUsers(List<User> users, String searchText) {
		List<User> filteredUsers = new ArrayList<>();

		for (User user : users) {
			if (user.getUserName().toLowerCase().contains(searchText.toLowerCase())) {
				filteredUsers.add(user);
			}
		}

		return filteredUsers;
	}

}