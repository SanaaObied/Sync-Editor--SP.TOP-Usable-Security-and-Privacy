package src.application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

class connection {

	public connection() {

	}

	private static String dburl;
	private static String dbUserName = "root";
	private static String dbPassword = "1020304050Ss";
	private static String url = "127.0.0.1";
	private static String port = "3306";
	private static String dbName = "synceditors";

	private static Connection con;

	public Connection connect() {

		return con;
	}

//	//to connection between database and java
	public void connectDB() throws ClassNotFoundException, SQLException {

		try {
			dburl = "jdbc:mysql://" + url + ":" + port + "/" + dbName + "?verifyServerCertificate=false";
			Properties p = new Properties();
			p.setProperty("user", dbUserName);
			p.setProperty("password", dbPassword);
			p.setProperty("useSSL", "false");
			p.setProperty("autoReconnect", "true");
			Class.forName("com.mysql.jdbc.Driver");

			con = (Connection) DriverManager.getConnection(dburl, p);

			System.out.println("Connection succeed");
		} catch (Exception e) {
			System.out.println("Connection failed");
		}

	}

	// check if a query is executed or not
	public void ExecuteStatement(String SQL) throws SQLException {

		try {
			Statement stmt = con.createStatement();
			stmt.execute(SQL);
			System.out.println("SQL statement is executed!");
			stmt.close();
		} catch (SQLException s) {
			s.printStackTrace();
			System.out.println("SQL statement is not executed!");

		}
	}

}
