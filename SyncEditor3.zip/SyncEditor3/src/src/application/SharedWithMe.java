package src.application;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SharedWithMe {

	private ObservableList<info> data = FXCollections.observableArrayList();
	private TableView table = new TableView<>();

	public Pane sharedWithMe(int accountID) {
		Pane pane = new Pane();

		HBox title = new HBox(10);
		title.getStyleClass().add("hboxes");
		title.setLayoutX(30);
		title.setLayoutY(30);

		Image alert = new Image("ShareWithMeDark.png");
		ImageView alertsIcon = new ImageView(alert);
		alertsIcon.setFitWidth(40);
		alertsIcon.setFitHeight(40);
		pane.getChildren().add(alertsIcon);

		Label myalerts = new Label("Shared With Me");
		myalerts.getStyleClass().add("tit");
		myalerts.setLayoutX(222);
		pane.getChildren().add(myalerts);

		title.getChildren().addAll(alertsIcon, myalerts);
		pane.getChildren().add(title);

		TextField search = new TextField();
		// search.getStyleClass().add("textField");
		search.setLayoutX(870);
		search.setLayoutY(30);
		search.setPrefWidth(300);
		search.setPrefHeight(40);
		search.setPromptText("Search Shared With Me...");
		pane.getChildren().add(search);

		search.textProperty().addListener((observable, oldValue, newValue) -> {
			filterTable(newValue);
		});

		Image sea = new Image("Search.png");

		ImageView searchIcon = new ImageView(sea);
		searchIcon.setFitWidth(30);
		searchIcon.setFitHeight(30);

		// delete file
		Button seachbutton = new Button();
		// delete.getStyleClass().add("alert");
		seachbutton.setLayoutX(1170);
		seachbutton.setLayoutY(30);
		seachbutton.setGraphic(searchIcon);
		pane.getChildren().add(seachbutton);

//		seachbutton.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent arg0) {
//				 filterTable(search.getText());
//			}
//		});

		Line line = new Line(20, 100, 1240, 100);
		pane.getChildren().add(line);

		pane.getChildren().add(table);
		tableV(accountID);

		Image trueImg = new Image("Deletefile.png");

		ImageView trueIcon = new ImageView(trueImg);
		trueIcon.setFitWidth(35);
		trueIcon.setFitHeight(40);

		// delete file
		Button delete = new Button();
		// delete.getStyleClass().add("alert");
		delete.setLayoutX(1185);
		delete.setLayoutY(160);
		delete.setGraphic(trueIcon);
		pane.getChildren().add(delete);
		delete.getStyleClass().add("whiteBG");

		delete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				info o = (info) table.getSelectionModel().getSelectedItem();

				if (o != null) {
					System.out.println(o.getFilename());
					deleteFile(accountID, o);
					search.clear();
				} else
					Main.warning.WarningMessage("", "Please Select from the table what do you want to delete!! ");
			}
		});

		return pane;
	}

	private void tableV(int accountID) {
		table.setLayoutX(70);
		table.setLayoutY(160);
		table.getColumns().clear();
		table.getItems().clear();
		table.refresh();
		table.setPrefSize(1100, 550);
		table.setEditable(true);
		table.getStyleClass().add("table-view2");

		TableColumn<info, String> admin = new TableColumn<>("Admin");
		admin.setPrefWidth(300);
		admin.setCellValueFactory(new PropertyValueFactory<>("a"));

		TableColumn<info, String> filename = new TableColumn<>("File Name");
		filename.setPrefWidth(500);
		filename.setCellValueFactory(new PropertyValueFactory<>("f"));

		TableColumn<info, String> privilege = new TableColumn<>("Privilege");
		privilege.setPrefWidth(300);
		privilege.setCellValueFactory(new PropertyValueFactory<>("p"));

		table.getColumns().addAll(admin, filename, privilege);

		ArrayList<info> ids = new ArrayList<>();
		ArrayList<String> names = new ArrayList<>();

		try {
			Main.conne.connectDB();

			Statement statement = Main.conne.connect().createStatement();
			ResultSet result = statement.executeQuery("SELECT f.accountsID, f.fileName, e.privilege "
					+ "FROM editors e " + "JOIN files f ON e.fileID = f.fileID "
					+ "JOIN accounts a ON e.editor = a.accountsID " + "WHERE a.accountsID = " + accountID + ";");

			while (result.next()) {
				System.out.println("hi hi " + result.getString(2));
				ids.add(new info(result.getInt(1), result.getString(2), result.getBoolean(3)));
			}

			if (result != null)
				result.close();
			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("SQL error occurred: " + e.getMessage());
		}

		try {
			Main.conne.connectDB();

			Statement statement = Main.conne.connect().createStatement();
			ResultSet result = null;
			for (info id : ids) {
				result = statement.executeQuery("SELECT a.accountsID, a.userName " + "FROM files f, accounts a "
						+ "WHERE f.accountsID = a.accountsID && a.accountsID = " + id.getId() + " LIMIT 1 ;");

				while (result.next()) {
					names.add(result.getString(2));
				}
			}

			if (result != null)
				result.close();
			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("SQL error occurred: " + e.getMessage());
		}

		for (int i = 0; i < ids.size(); i++) {
			String privilegeType = ids.get(i).isReadOnly() ? "Read/Write" : "Read Only";
			table.getItems().add(new info(names.get(i), ids.get(i).getFilename(), privilegeType));
			data.add(new info(names.get(i), ids.get(i).getFilename(), privilegeType));
		}

		table.refresh();
	}

	private void deleteFile(int id, info object) {
		Stage stage = new Stage();
		stage.setTitle("Remove File");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("DeleteFile.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"Are you sure you want to permanently delete \'" + object.getF() + "\' from your shared files?");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(450);
		roles.setFont(new Font("Arial", 16));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Text str = new Text("Deleting this file will result in the loss of all Reading/Writing privileges.");
		// alert.getStyleClass().add("tit");
		str.setWrappingWidth(480);
		str.setFont(new Font("Arial", 15));
		str.setLayoutX(20);
		str.setLayoutY(150);
		pane.getChildren().add(str);

		Button Cancel = new Button("Cancel");
		pane.getChildren().add(Cancel);
		Cancel.setFont(new Font(20));
		Cancel.getStyleClass().add("butt");
		Cancel.setLayoutX(305);
		Cancel.setLayoutY(180);

		Cancel.setOnAction(e -> {
			stage.close();
		});

		Button delete = new Button("Remove");
		pane.getChildren().add(delete);
		delete.setFont(new Font(20));
		delete.getStyleClass().add("butt");
		delete.setLayoutX(410);
		delete.setLayoutY(180);

		delete.setOnAction(e -> {
			try {
				Main.conne.connectDB();

				Statement statement = Main.conne.connect().createStatement();
				if (object.isReadOnly())
					statement.execute("delete e\r\n" + "FROM editors e ,files f ,accounts a \r\n"
							+ "WHERE a.accountsID = " + id
							+ " AND e.fileID = f.fileID AND e.editor = a.accountsID AND e.privilege=0 And  f.fileName='"
							+ object.getF() + "';");
				else
					statement.execute("delete e\r\n" + "FROM editors e ,files f ,accounts a \r\n"
							+ "WHERE a.accountsID = " + id
							+ " AND e.fileID = f.fileID AND e.editor = a.accountsID AND e.privilege=1 And  f.fileName='"
							+ object.getF() + "';");

				System.out.println("delete e FROM editors e ,files f ,accounts a WHERE a.accountsID = " + id
						+ " AND e.fileID = f.fileID AND e.editor = a.accountsID AND e.privilege=" + object.isReadOnly()
						+ " And  f.fileName='" + object.getF() + "';");
				statement.close();
				Main.conne.connect().close();

			} catch (ClassNotFoundException e0) {
				e0.printStackTrace();
			} catch (SQLException e1) {
				System.err.println("SQL error occurred: " + e1.getMessage());
			}
			tableV(id);
			stage.close();
		});

		Scene scene = new Scene(pane, 550, 250);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	private void filterTable(String searchTerm) {
		ObservableList<info> filteredData = FXCollections.observableArrayList();

		for (info item : data) {
			if (item.getA().toLowerCase().contains(searchTerm.toLowerCase())) {
				filteredData.add(item);
			}
		}

		table.setItems(filteredData);
	}

}
