package src.application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SharedWithMePane {

	private TableView table = new TableView<>();

	public Pane sharedWithMe() {
		Pane pane = new Pane();

		HBox title = new HBox(10);
		title.getStyleClass().add("hboxes");
		title.setLayoutX(30);
		title.setLayoutY(30);

		Image alert = new Image("ShareWithMeDark.png");
		ImageView alertsIcon = new ImageView(alert);
		alertsIcon.setFitWidth(40);
		alertsIcon.setFitHeight(40);
		pane.getChildren().add(alertsIcon);

		Label myalerts = new Label("Shared With Me");
		myalerts.getStyleClass().add("tit");
		myalerts.setLayoutX(222);
		pane.getChildren().add(myalerts);

		title.getChildren().addAll(alertsIcon, myalerts);
		pane.getChildren().add(title);

		TextField search = new TextField();
		// search.getStyleClass().add("textField");
		search.setLayoutX(870);
		search.setLayoutY(30);
		search.setPrefWidth(300);
		search.setPrefHeight(40);
		search.setPromptText("Search Shared With Me...");
		pane.getChildren().add(search);

		Image sea = new Image("Search.png");

		ImageView searchIcon = new ImageView(sea);
		searchIcon.setFitWidth(30);
		searchIcon.setFitHeight(30);

		// delete file
		Button seachbutton = new Button();
		// delete.getStyleClass().add("alert");
		seachbutton.setLayoutX(1170);
		seachbutton.setLayoutY(30);
		seachbutton.setGraphic(searchIcon);
		pane.getChildren().add(seachbutton);

		seachbutton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

			}
		});

		Line line = new Line(20, 100, 1240, 100);
		pane.getChildren().add(line);

		pane.getChildren().add(table);
		tableV();

		Image trueImg = new Image("Deletefile.png");

		ImageView trueIcon = new ImageView(trueImg);
		trueIcon.setFitWidth(35);
		trueIcon.setFitHeight(40);

		// delete file
		Button delete = new Button();
		// delete.getStyleClass().add("alert");
		delete.setLayoutX(1185);
		delete.setLayoutY(160);
		delete.setGraphic(trueIcon);
		pane.getChildren().add(delete);
		delete.getStyleClass().add("whiteBG");

		delete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				deleteFile("\'File Name\'");
			}
		});

		return pane;
	}

	private void tableV() {
		table.setLayoutX(70);
		table.setLayoutY(160);
		table.getColumns().clear();
		table.getItems().clear();
		table.refresh();
		// table.setPrefWidth(1100);
		table.setPrefSize(1100, 550);
		table.setEditable(true);
		table.getStyleClass().add("table-view2");

		TableColumn<info, String> admin = new TableColumn<>("Admin");
		admin.setPrefWidth(300);
		admin.setCellValueFactory(new PropertyValueFactory<info, String>("a"));

		TableColumn<info, String> filename = new TableColumn<>("File Name");
		filename.setPrefWidth(500);
		filename.setCellValueFactory(new PropertyValueFactory<info, String>("f"));

		TableColumn<info, String> privilege = new TableColumn<>("Privilege");
		privilege.setPrefWidth(300);
		privilege.setCellValueFactory(new PropertyValueFactory<info, String>("p"));

		table.getColumns().addAll(admin, filename, privilege);

		for (int i = 0; i < 20; i++) {

			table.getItems().add(new info("Noah Zain", "How to train your cat", "Read Only"));

		}

		table.refresh();
	}

	private void deleteFile(String fileName) {
		Stage stage = new Stage();
		stage.setTitle("Remove File");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("DeleteFile.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"Are you sure you want to permanently delete \'" + fileName + "\' from your shared files?");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(450);
		roles.setFont(new Font("Arial", 16));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Text str = new Text("Deleting this file will result in the loss of all Reading/Writing privileges.");
		// alert.getStyleClass().add("tit");
		str.setWrappingWidth(480);
		str.setFont(new Font("Arial", 15));
		str.setLayoutX(20);
		str.setLayoutY(150);
		pane.getChildren().add(str);

		Button Cancel = new Button("Cancel");
		pane.getChildren().add(Cancel);
		Cancel.setFont(new Font(20));
		Cancel.getStyleClass().add("butt");
		Cancel.setLayoutX(305);
		Cancel.setLayoutY(180);

		Cancel.setOnAction(e -> {
			stage.close();
		});

		Button delete = new Button("Remove");
		pane.getChildren().add(delete);
		delete.setFont(new Font(20));
		delete.getStyleClass().add("butt");
		delete.setLayoutX(410);
		delete.setLayoutY(180);

		delete.setOnAction(e -> {

		});

		Scene scene = new Scene(pane, 550, 250);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

}
