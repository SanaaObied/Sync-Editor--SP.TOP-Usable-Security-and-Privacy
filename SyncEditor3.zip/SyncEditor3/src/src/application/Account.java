package src.application;

import java.util.Date;
import java.util.TreeSet;

import javafx.scene.image.Image;

public class Account {
	private int AccountID;
	private String userName;
	private Date DOB;
	private String password;
	private String gimal;
	private Image image;
	private String userImage; // New field for the account image
	private boolean privileges;
	private int id;
	private TreeSet avlFile = new TreeSet();
	private TreeSet avlUser = new TreeSet();
	private final byte[] imageBytes;

	public Account() {

		super();
		this.imageBytes = null;
	}

	public Account(int AccountID) {
		this.AccountID = AccountID;
		this.imageBytes = null;

	}

	public Account(String userName, byte[] imageBytes) {
		this.userName = userName;
		this.imageBytes = imageBytes;
	}

	public Account(String userName, Date dOB, String password, String gimal, TreeSet avlFile, TreeSet avlUser) {
		this.imageBytes = null;
		this.userName = userName;
		DOB = dOB;
		this.password = password;
		this.gimal = gimal;
		this.avlFile = avlFile;
		this.avlUser = avlUser;
	}

	public Account(String userName, Date DOB, String password, String gimal, String userImage, boolean privileges) {
		this.imageBytes = null;
		this.userName = userName;
		this.DOB = DOB;
		this.password = password;
		this.gimal = gimal;
		this.userImage = userImage;
		this.privileges = privileges;
	}

	public Account(String userName, Date dOB, String password, String gimal) {
		this.imageBytes = null;
		this.userName = userName;
		DOB = dOB;
		this.password = password;
		this.gimal = gimal;
	}

	public Account(int AccountID, String userName, Date dOB, String password, Image image, String gimal) {
		this.imageBytes = null;
		this.AccountID = AccountID;
		this.userName = userName;
		DOB = dOB;
		this.password = password;
		this.image = image;
		this.gimal = gimal;
	}

	public Account(int AccountID, String userName, Date dOB, String password, Image image, String gimal,
			TreeSet avlFile, TreeSet avlUser) {
		this.imageBytes = null;
		this.AccountID = AccountID;
		this.userName = userName;
		this.DOB = dOB;
		this.password = password;
		this.gimal = gimal;
		this.avlFile = avlFile;
		this.avlUser = avlUser;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte[] getImageBytes() {
		return imageBytes;
	}

	public boolean isPrivileges() {
		return privileges;
	}

	public void setPrivileges(boolean privileges) {
		this.privileges = privileges;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserImage() {
		return userImage;
	}

	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGimal() {
		return gimal;
	}

	public void setGimal(String gimal) {
		this.gimal = gimal;
	}

	public TreeSet getAvlFile() {
		return avlFile;
	}

	public void setAvlFile(TreeSet avlFile) {
		this.avlFile = avlFile;
	}

	public TreeSet getAvlUser() {
		return avlUser;
	}

	public void setAvlUser(TreeSet avlUser) {
		this.avlUser = avlUser;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public int getAccountID() {
		return AccountID;
	}

	public void setAccountID(int accountID) {
		AccountID = accountID;
	}

	
	
	@Override
	public String toString() {
		return "Account [userName=" + userName + ", DOB=" + DOB + ", password=" + password + ", gimal=" + gimal + "]";
	}

}
