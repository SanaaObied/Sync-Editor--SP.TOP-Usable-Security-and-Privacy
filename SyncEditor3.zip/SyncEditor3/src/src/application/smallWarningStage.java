package src.application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class smallWarningStage {

	public void WarningMessage(String title, String message) {
		Stage stage = new Stage();
		stage.setTitle(title);

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("Icon.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("error.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(message);
		roles.setWrappingWidth(320);
		roles.setFont(new Font("Arial", 20));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(22));
		ok.setPrefSize(60, 20);
		// ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}
}
