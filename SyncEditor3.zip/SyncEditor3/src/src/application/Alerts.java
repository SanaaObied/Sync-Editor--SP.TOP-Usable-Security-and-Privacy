package src.application;

import java.io.ByteArrayInputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Alerts {
	int numOfFiles;
	int numOfFriends;

	public Pane alert(int id) {
		// ArrayList<FriendsRequst> friendsArray = new ArrayList<>();

		Pane pane = new Pane();

		HBox title = new HBox(10);
		title.getStyleClass().add("hboxes");
		title.setLayoutX(30);
		title.setLayoutY(30);

		Image alert = new Image("AlertsDark.png");
		ImageView alertsIcon = new ImageView(alert);
		alertsIcon.setFitWidth(40);
		alertsIcon.setFitHeight(40);
		pane.getChildren().add(alertsIcon);

		Label myalerts = new Label("Alerts");
		myalerts.getStyleClass().add("tit");
		myalerts.setLayoutX(222);
		pane.getChildren().add(myalerts);

		title.getChildren().addAll(alertsIcon, myalerts);
		pane.getChildren().add(title);

		Line line = new Line(20, 100, 1240, 100);
		pane.getChildren().add(line);

		// number of alerts
		Label numOfAlerts = new Label();
		numOfAlerts.setLayoutX(1075);
		numOfAlerts.setLayoutY(75);
		numOfAlerts.setFont(new Font(15));
		pane.getChildren().add(numOfAlerts);

		ScrollPane scrollPane = new ScrollPane();
		VBox alertsList = new VBox(25);

		scrollPane.setLayoutX(80);
		scrollPane.setLayoutY(170);
		scrollPane.setContent(alertsList);
		scrollPane.setPrefSize(1110, 600);
		scrollPane.setStyle("-fx-background-color:white;");
		pane.getChildren().add(scrollPane);

		try {
			Main.conne.connectDB();

			// Create a statement object to execute the query
			Statement statement = Main.conne.connect().createStatement();
			Main.conne.ExecuteStatement(
					"select a.image, f.sender, a.userNAme from accounts a, friendsrequst f where  f.reciver=" + id
							+ " AND a.accountsID = f.sender;");
			// Execute the query and get the result set
			ResultSet result = statement.executeQuery(
					"select COUNT(*) AS recordCount, a.image, f.sender, a.userNAme from accounts a, friendsrequst f where  f.reciver="
							+ id + " AND a.accountsID = f.sender group by a.image, f.sender, a.userNAme;");

			while (result.next()) {
				numOfFriends = result.getInt(1);
				System.out.println(numOfFriends + " hi worood");
				Pane newPane = new Pane();
				newPane.setStyle("-fx-background-color:white;");
				newPane.setPrefSize(1090, 120);
				newPane.getStyleClass().add("friendpane");
				alertsList.getChildren().add(newPane);

				// display user icon
				ImageView imag = new ImageView();
				imag.setFitWidth(80);
				imag.setFitHeight(80);
				imag.getStyleClass().add("img");

				Image image1 = Main.sett.getImageFromDatabase(result.getInt(3));

				if (image1 != null) {
					imag.setImage(image1);
					// Add imageView to your JavaFX scene or layout
				} else {
					imag.setImage(new Image("user.png"));
				}

				// Create a Circle object to use as a clipping shape
				Circle clip = new Circle(40, 40, 40);

				// Set the clipping shape to the image view
				imag.setClip(clip);
				imag.setLayoutX(20);
				imag.setLayoutY(20);

				newPane.getChildren().add(imag);

				Text text1 = new Text(result.getString(4) + ", ");
				text1.setStyle("-fx-font-weight: bold; -fx-font-size: 25.0px;");
				Text text2 = new Text("Wants To Add You As Their Friend.");
				text2.setFont(new Font(25));

				HBox hbox = new HBox();
				hbox.getChildren().addAll(text1, text2);

				hbox.setLayoutX(120); // Set the X position
				hbox.setLayoutY(45); // Set the Y position

				newPane.getChildren().add(hbox);

				Image trueImg = new Image("accept.png");

				ImageView trueIcon = new ImageView(trueImg);
				trueIcon.setFitWidth(40);
				trueIcon.setFitHeight(40);

				// back to first page
				Label truee = new Label();
				truee.getStyleClass().add("alert");
				truee.setLayoutX(920);
				truee.setLayoutY(40);
				truee.setGraphic(trueIcon);
				newPane.getChildren().add(truee);

				truee.setId(result.getString(3));
				pane.setId(result.getString(3));
				truee.setOnMouseClicked(event -> {
					alertsList.getChildren()
							.removeIf(node -> node instanceof Pane && truee.getId().equals(((Pane) node).getId()));
					try {
						Main.conne.connectDB();

						numOfAlerts.setText("(" + (numOfFiles + numOfFriends - 1) + ") New Notifications");
						Main.conne.connect();

						// Create a statement object to execute the query
						Statement statement2 = Main.conne.connect().createStatement();

						statement2.execute("delete from friendsrequst where sender = " + truee.getId()
								+ " AND reciver = " + id + ";");

						statement2.close();
						Main.conne.connect().close();

					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// Handle other SQLExceptions, if necessary
						System.err.println("SQL error occurred: " + e.getMessage());
					}

					try {
						Main.conne.connectDB();

						Main.conne.connect();

						// Create a statement object to execute the query
						Statement statement2 = Main.conne.connect().createStatement();

						statement2.execute("insert into befriends value(" + truee.getId() + "," + id + ");");

						statement2.close();
						Main.conne.connect().close();

					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// Handle other SQLExceptions, if necessary
						System.err.println("SQL error occurred: " + e.getMessage());
					}

//					Main.theMain.gethbox().getChildren().clear();
//					Main.theMain.gethbox().getChildren().addAll(Main.theMain.getPane(), Main.al.alert(id));
				});

				Image falseImg = new Image("decline.png");

				ImageView falseIcon = new ImageView(falseImg);
				falseIcon.setFitWidth(40);
				falseIcon.setFitHeight(40);

				// back to first page
				Label falsee = new Label();
				falsee.getStyleClass().add("alert");
				falsee.setLayoutX(1000);
				falsee.setLayoutY(40);
				falsee.setGraphic(falseIcon);
				newPane.getChildren().add(falsee);
				falsee.setId(result.getString(3));

				falsee.setOnMouseClicked(event -> {
					try {
						Main.conne.connectDB();

						numOfAlerts.setText("(" + (numOfFiles + numOfFriends - 1) + ") New Notifications");
						removePaneById(alertsList, falsee.getId());
						Main.conne.connect();

						// Create a statement object to execute the query
						Statement statement2 = Main.conne.connect().createStatement();

						statement2.execute("delete from friendsrequst where sender = " + truee.getId()
								+ " AND reciver = " + id + ";");

						statement2.close();
						Main.conne.connect().close();

					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// Handle other SQLExceptions, if necessary
						System.err.println("SQL error occurred: " + e.getMessage());
					}
				});
			}

			result.close();
			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// Handle other SQLExceptions, if necessary
			System.err.println("SQL error occurred: " + e.getMessage());
		}

		// get files requests
		try {
			Main.conne.connectDB();

			// Create a statement object to execute the query
			Statement statement = Main.conne.connect().createStatement();

			// Execute the query and get the result set
			ResultSet result = statement.executeQuery(
					"SELECT COUNT(*) AS recordCount, a.image, f.sender, a.userName, fi.fileName, f.fileID \r\n"
							+ "FROM accounts a\r\n" + "JOIN sharefile f ON a.accountsID = f.sender\r\n"
							+ "JOIN files fi ON fi.fileID = f.fileID\r\n" + "WHERE f.recever = " + id + "\r\n"
							+ "GROUP BY a.image, f.sender, a.userName, fi.fileName, f.fileID\r\n" + ";");

			while (result.next()) {
				numOfFiles = result.getInt(1);
				Pane newPane = new Pane();
				newPane.setStyle("-fx-background-color:white;");
				newPane.setPrefSize(1090, 220);
				newPane.getStyleClass().add("friendpane");
				alertsList.getChildren().add(newPane);

				// display user icon
				ImageView imag = new ImageView();
				imag.setFitWidth(80);
				imag.setFitHeight(80);
				imag.getStyleClass().add("img");

				Image image1 = Main.sett.getImageFromDatabase(result.getInt(3));

				if (image1 != null) {
					imag.setImage(image1);
					// Add imageView to your JavaFX scene or layout
				} else {
					System.out.println("Failed to retrieve the image from the database.");
				}

				// Create a Circle object to use as a clipping shape
				Circle clip = new Circle(40, 40, 40);

				// Set the clipping shape to the image view
				imag.setClip(clip);
				imag.setLayoutX(20);
				imag.setLayoutY(20);

				newPane.getChildren().add(imag);

				Text text1 = new Text(result.getString(4) + ", ");
				text1.setStyle("-fx-font-weight: bold; -fx-font-size: 25.0px;");
				Text text2 = new Text("Is Inviting You To Edit At Their Workspace.\n(" + result.getString(5) + ").");
				text2.setFont(new Font(25));

				HBox hbox = new HBox();
				hbox.getChildren().addAll(text1, text2);

				hbox.setLayoutX(120); // Set the X position
				hbox.setLayoutY(45); // Set the Y position

				newPane.getChildren().add(hbox);

				Image trueImg = new Image("accept.png");

				ImageView trueIcon = new ImageView(trueImg);
				trueIcon.setFitWidth(40);
				trueIcon.setFitHeight(40);

				// back to first page
				Button truee = new Button("  JOIN  ");
				truee.getStyleClass().add("alert");
				truee.setLayoutX(340);
				truee.setLayoutY(125);
				truee.setGraphic(trueIcon);
				newPane.getChildren().add(truee);

				truee.setId(result.getString(6));

				truee.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent arg0) {
						try {
							numOfAlerts.setText("(" + (numOfFiles + numOfFriends - 1) + ") New Notifications");
							Main.conne.connectDB();

							// Create a statement object to execute the query
							Statement statement2 = Main.conne.connect().createStatement();

							statement2.execute("delete from friendsrequst where sender = " + truee.getId()
									+ " AND reciver = " + id + ";");

							statement2.close();
							Main.conne.connect().close();

						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SQLException e) {
							// Handle other SQLExceptions, if necessary
							System.err.println("SQL error occurred: " + e.getMessage());
						}

					}
				});

				Image falseImg = new Image("decline.png");

				ImageView falseIcon = new ImageView(falseImg);
				falseIcon.setFitWidth(40);
				falseIcon.setFitHeight(40);

				// back to first page
				Button falsee = new Button("  IGNORE  ");
				falsee.getStyleClass().add("alert");
				falsee.setLayoutX(570);
				falsee.setLayoutY(125);
				falsee.setGraphic(falseIcon);
				newPane.getChildren().add(falsee);

				falsee.setId(result.getString(6));

				falsee.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent arg0) {
						try {
							numOfAlerts.setText("(" + (numOfFiles + numOfFriends - 1) + ") New Notifications");
							Main.conne.connectDB();

							// Create a statement object to execute the query
							Statement statement2 = Main.conne.connect().createStatement();

							statement2.execute("delete from sharefile where fileID=" + falsee.getId()
									+ " And recever = " + id + ";");

							statement2.close();
							Main.conne.connect().close();

						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SQLException e) {
							// Handle other SQLExceptions, if necessary
							System.err.println("SQL error occurred: " + e.getMessage());
						}

					}
				});
			}

			result.close();
			statement.close();
			Main.conne.connect().close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// Handle other SQLExceptions, if necessary
			System.err.println("SQL error occurred: " + e.getMessage());
		}
		numOfAlerts.setText("(" + (numOfFiles + numOfFriends) + ") New Notifications");

		return pane;
	}

	private void removePaneById(VBox vBox, String targetId) {
		vBox.getChildren().removeIf(node -> node instanceof Pane && targetId.equals(((Pane) node).getId()));
	}
}
