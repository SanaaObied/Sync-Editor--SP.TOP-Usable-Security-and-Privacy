package src.application;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.web.HTMLEditor;
import javafx.stage.Stage;

public class TextEditorPane extends VBox {

	private Button back, save, edit;
	private TextField titletxf;
	private HTMLEditor editor;
	private Label addNewFriend;
//	private Stage stage = new Stage();
	private LeaveWithoutSaving LeaveWithoutSaving;
	private boolean saved = false;
	private sql sql = new sql();
	private SharedFilesInFriendPage SharedFilesInFriendPage;
//	private Login Login = new Login();
	private Account Account = new Account();
	private String title;
	private ArrayList<EditorsAndViewers> AddToProject = new ArrayList<>();
	private KickingOutUser KickingOutUser;

	// the constructor should receive the file object, the admin, list of editors
	public TextEditorPane() {

		// this information should be dynamic
		title = "Jumping the rope is the fun!";
		String insideText = "everything is a lie....... WAKE UP!";

		ImageView saveImg = new ImageView(new Image("save.png"));
		ImageView editImage = new ImageView(new Image("edit.png"));
		ImageView arrowBack = new ImageView(new Image("arrow.png"));
		ImageView addFriend = new ImageView(new Image("AddNew.png"));

		addFriend.setFitWidth(45);
		addFriend.setFitHeight(45);
		saveImg.setFitWidth(25);
		saveImg.setFitHeight(25);
		editImage.setFitWidth(25);
		editImage.setFitHeight(25);
		arrowBack.setFitWidth(25);
		arrowBack.setFitHeight(25);

		addNewFriend = new Label();
		back = new Button("", arrowBack);
		save = new Button("", saveImg);
		edit = new Button("", editImage);
		titletxf = new TextField(title);
		editor = new HTMLEditor();

		back.setStyle("-fx-background-color:transparent;");
		save.setStyle("-fx-background-color:transparent;");
		edit.setStyle("-fx-background-color:transparent;");

		// setting properties
		addNewFriend.setGraphic(addFriend);
		titletxf.setFont(Font.font("Times New Roman", FontWeight.BOLD, 17));
		editor.lookup(".top-toolbar").setStyle("-fx-alignment: CENTER;");
		editor.lookup(".bottom-toolbar").setStyle("-fx-alignment: CENTER;");
		editor.setPrefWidth(1300);
		titletxf.setEditable(false);
		titletxf.setStyle("-fx-background-color: transparent;-fx-border-width: 0;");

		titletxf.setOnMouseClicked(e -> {
			titletxf.setEditable(true);
		});

		edit.setOnMouseClicked(e -> {
			titletxf.setEditable(false);
			String newTitle = titletxf.getText();
			Files files = new Files();
			if (newTitle == null || newTitle.isBlank()) {
				newTitle = title;
			}
			files.setFileName(newTitle);

			// Update the file name in the database
			try {
				String query = "UPDATE Files SET FileName = " + newTitle + " WHERE FileID = " + getFileId(title);
				PreparedStatement statement = sql.getConnection().prepareStatement(query);
				statement.setString(1, newTitle);
				statement.setInt(2, files.getFileId()); // Assuming you have a getFileId() method in the Files class to
				Account.getAvlFile().remove(new Files(files.getFileId(), title));
				Files file = new Files(files.getFileId(), newTitle);
				Account.getAvlFile().add(file);// retrieve the file ID
				statement.executeUpdate();
				System.out.println("Saved As : " + newTitle);
				// Optionally, display a success message or perform other actions
			} catch (SQLException ex) {
				ex.printStackTrace();
				// Handle any potential exceptions that may occur during the database operation
			}
		});
		back.setOnAction(e -> {
			if (!saved) {
				Scene scene = new Scene(LeaveWithoutSaving = new LeaveWithoutSaving(), 550, 650);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.setResizable(false);
				stage.show();
				saved = true;
				// Add ActionListener to the Save button in the LeaveWithoutSaving class
				LeaveWithoutSaving.getSave().setOnAction(saveEvent -> {
					String htmlText = editor.getHtmlText();
					String password = " ";
					// Encrypt the HTML text
					String encryptedText = encryptedData(htmlText, password);

					// Assuming you have a database connection named "connection" established
					try {
						int fileId = getFileId(title);

						String query = "UPDATE Files SET texts = ? WHERE file_id = ?";
						PreparedStatement statement = sql.getConnection().prepareStatement(query);
						statement.setString(1, encryptedText);
						statement.setInt(2, fileId);
						int rowsAffected = statement.executeUpdate();

						if (rowsAffected > 0) {
							// Update successful
							System.out.println("Text updated successfully for file ID: " + fileId);
						} else {
							// No rows affected, file ID not found
							System.out.println("File ID not found: " + fileId);
						}

						// Optionally, display a success message or perform other actions
					} catch (NumberFormatException ex) {
						// Handle the case where the entered file ID is not a valid integer
						System.out.println("Invalid file ID entered");
					} catch (SQLException ex) {
						ex.printStackTrace();
						// Handle any potential exceptions that may occur during the database operation
					}
					save.fire();

					Platform.exit();
				});
			} else {
				Platform.exit(); // Close the application
			}
		});

		save.setOnAction(e -> {
			saved = true;
			String htmlText = editor.getHtmlText();
			String password = " ";
			// Encrypt the HTML text
			String encryptedText = encryptedData(htmlText, password);

			// Assuming you have a database connection named "connection" established
			try {
				int fileId = getFileId(title);

				String query = "UPDATE Files SET texts = ? WHERE file_id = ?";
				PreparedStatement statement = sql.getConnection().prepareStatement(query);
				statement.setString(1, encryptedText);
				statement.setInt(2, fileId);
				int rowsAffected = statement.executeUpdate();

				if (rowsAffected > 0) {
					// Update successful
					System.out.println("Text updated successfully for file ID: " + fileId);
				} else {
					// No rows affected, file ID not found
					System.out.println("File ID not found: " + fileId);
				}

				// Optionally, display a success message or perform other actions
			} catch (NumberFormatException ex) {
				// Handle the case where the entered file ID is not a valid integer
				System.out.println("Invalid file ID entered");
			} catch (SQLException ex) {
				ex.printStackTrace();
				// Handle any potential exceptions that may occur during the database operation
			}
		});

		addNewFriend.setOnMouseClicked(e -> {
			System.out.println("WHYYY");
			getShareFileWithFriend();
		});

		// the title part of the top pane
		HBox titleBox = new HBox();
		titleBox.getChildren().addAll(titletxf, edit);
		titleBox.setAlignment(Pos.CENTER_LEFT);
		titleBox.setPadding(new Insets(0, 10, 0, 10));

//		// the list of editors//change here to dynamic looping
		HBox people = new HBox(5);
//
		people.getChildren().addAll(new EditorsAndViewers(new Image("ICON.png"), "Hanadi Asfour", true, true, true),
				new EditorsAndViewers(new Image("Lock.png"), "Baheya Asfour", false, true, false),
				new EditorsAndViewers(new Image("User.png"), "Manar Hamad", true, false, false),
				new EditorsAndViewers(new Image("File.png"), "Omani Gani", false, false, false),
				new EditorsAndViewers(new Image("save.png"), "Moomoo Mais", true, false, false),
				new EditorsAndViewers(new Image("ICON.png"), "JohnDoe", true, true, false));

		people.getChildren().add(addNewFriend);// adding the option to add new friends

		people.setPadding(new Insets(7, 20, 7, 20));

		for (int i = 0; i < AddToProject.size(); i++) {

			for (EditorsAndViewers friend : AddToProject) {
				Image image = new Image("User.png"); // Assuming you have the image for each friend
				people.getChildren().add(
						new EditorsAndViewers(friend.getImg(), friend.getName(), true, friend.isIsallowed(), false));

			}
		}

		// insert the hbox of editors in here
		ScrollPane theEditors = new ScrollPane();
		theEditors.getStyleClass().add("scroll-pane");
		theEditors.setVbarPolicy(ScrollBarPolicy.NEVER);
		theEditors.setContent(people);
		theEditors.setPrefHeight(70);
		theEditors.setFitToWidth(true);

		// this grid pane holds the top elements of the editor
		GridPane topPane = new GridPane();
		topPane.add(back, 0, 0);
		topPane.add(save, 1, 0);
		topPane.add(titleBox, 2, 0);
		topPane.add(theEditors, 3, 0);
		topPane.setGridLinesVisible(true);
		topPane.setStyle("-fx-border-color:black;");
		topPane.setStyle("-fx-background-color:white;");
		topPane.setPrefHeight(70);
		topPane.setAlignment(Pos.TOP_LEFT);

		// Create column constraints
		ColumnConstraints col1 = new ColumnConstraints();
		ColumnConstraints col2 = new ColumnConstraints();
		ColumnConstraints col3 = new ColumnConstraints(400);
		ColumnConstraints col4 = new ColumnConstraints();

		col4.setFillWidth(true);

		// Set Hgrow property to make GridPane grow horizontally
		col1.setHgrow(javafx.scene.layout.Priority.NEVER);
		col2.setHgrow(javafx.scene.layout.Priority.NEVER);
		col4.setHgrow(javafx.scene.layout.Priority.ALWAYS);

		topPane.getColumnConstraints().addAll(col1, col2, col3, col4);

		getChildren().addAll(topPane, editor);
		setStyle("-fx-background-color:white;");

	}

	private ArrayList<User> getAllUsers(int fileID) {
		ArrayList<User> users = new ArrayList<>();
		// Retrieve data from the Accounts table
		String accountsQuery = "SELECT * " + "FROM Accounts " + "WHERE accountsID IN (" + "    SELECT recever "
				+ "    FROM ShareFile " + "    WHERE fileID = ?" + ")";
		try {
			PreparedStatement accountsStatement = sql.getConnection().prepareStatement(accountsQuery);
			accountsStatement.setInt(1, fileID);
			ResultSet accountsResultSet = accountsStatement.executeQuery();

			while (accountsResultSet.next()) {
				int accountID = accountsResultSet.getInt("accountsID");
				String accountName = accountsResultSet.getString("userame");
				Date DOB = accountsResultSet.getDate("DateOfBirth");
				String Gmail = accountsResultSet.getString("gmail");
				String password = accountsResultSet.getString("pass");
				Blob blob = accountsResultSet.getBlob("image");
				// Convert the Blob object to an Image object
				InputStream inputStream = blob.getBinaryStream();
				Image imagView = new Image(inputStream);
				// Retrieve other columns as needed

				User user = new User(accountID, accountName, DOB, password, imagView, Gmail);
				users.add(user);
			}

			accountsResultSet.close();
			accountsStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Retrieve data from the Editors table
		String editorsQuery = "SELECT * " + "FROM Editors " + "WHERE editor = ?";
		try {
			PreparedStatement editorsStatement = sql.getConnection().prepareStatement(editorsQuery);
			for (User user : users) {
				editorsStatement.setInt(1, user.getAccountID());
				ResultSet editorsResultSet = editorsStatement.executeQuery();

				while (editorsResultSet.next()) {
					int editorsID = editorsResultSet.getInt("editorsID");
					boolean privilege = editorsResultSet.getBoolean("privilege");
					int fileid = editorsResultSet.getInt("fileID");
					int editor = editorsResultSet.getInt("editor");

					// Create a User object based on the retrieved data
					AddToProject
							.add(new EditorsAndViewers(user.getImage(), user.getUserName(), false, privilege, false));

				}

				editorsResultSet.close();
			}

			editorsStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}

	public TextField getTitletxf() {
		return titletxf;
	}

	public void setTitletxf(TextField titletxf) {
		this.titletxf = titletxf;
	}

	private String encryptedData(String text, String password) {
		String saltString = generateSalt();
		String encryptedString = null; // Store the encrypted string

		try {
			// Derive the AES key from the password using PBKDF2
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(saltString), 65536,
					256);
			SecretKey secretKey = factory.generateSecret(spec);
			SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), "AES");

			// Create the cipher object
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

			// Perform the encryption
			byte[] encryptedData = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));

			// Encode the encrypted data as Base64 string
			encryptedString = Base64.getEncoder().encodeToString(encryptedData);

			System.out.println("Encrypted string: " + encryptedString);
			System.out.println("Salt: " + saltString);
		} catch (Exception e) {
			e.printStackTrace();

		}

		try {
			// Decode the salt from Base64
			byte[] salt = Base64.getDecoder().decode(saltString);

			// Derive the AES key from the password using PBKDF2
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
			SecretKey secretKey = factory.generateSecret(spec);
			SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), "AES");

			// Create the cipher object
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

			// Decode the encrypted string from Base64
			byte[] encryptedDataDecoded = Base64.getDecoder().decode(encryptedString);

			// Perform the decryption
			byte[] decryptedData = cipher.doFinal(encryptedDataDecoded);

			// Convert the decrypted data to the original plaintext
			String originalString = new String(decryptedData, StandardCharsets.UTF_8);

		} catch (Exception e) {
			e.printStackTrace();

		}
		return encryptedString;
	}

	private static String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		return Base64.getEncoder().encodeToString(salt);
	}

	public String getAdminEmail(String username) {
		String email = null;
		try {
			Connection connection = sql.getConnection();
			String query = "SELECT gmail FROM Accounts WHERE userName = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				email = resultSet.getString("gmail");
				System.out.println(email);
			}
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return email;
	}

	// Add shared Friend in fail
	public Stage getShareFileWithFriend() {
		Stage s = new Stage();

		Image image = new Image("ICON.png");

		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(270);
		imageView.setFitHeight(190);

		TextField textField = new TextField();
		textField.setPromptText("Search My Friends");
		textField.setStyle("-fx-prompt-text-fill: black;");
		textField.setPrefWidth(300);
		textField.setPrefHeight(40);
		textField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));

		Image image5 = new Image("Search.png");
		ImageView imageView5 = new ImageView(image5);
		imageView5.setFitWidth(40);
		imageView5.setFitHeight(40);

		HBox hBox1 = new HBox();
		hBox1.setAlignment(Pos.CENTER_LEFT);
		hBox1.getChildren().addAll(textField, imageView5);

		// Create an HBox with ImageView, Label, and CheckBox

		ImageView imageView2 = new ImageView(new Image("User1.png"));
		imageView2.setFitWidth(100);
		imageView2.setFitHeight(100);
		HBox contentHBox = createHBox("User1.png", "Sanaa", false);

		HBox contentHBox2 = createHBox("User1.png", "Hanadi", true);
		Separator dashedLine3 = new Separator();
		dashedLine3.getStyleClass().add("dashed-line");
		VBox v2 = new VBox(contentHBox, dashedLine3, contentHBox2);
		v2.setAlignment(Pos.BASELINE_LEFT);
		v2.setSpacing(5); // Adjust spacing as needed
		v2.setPadding(new Insets(10)); // Adjust padding as needed
		v2.setPadding(new Insets(10, 10, 10, 10)); // Adjust padding as needed

		// Create a ScrollPane and set the content to the TableView
		ScrollPane scrollPane = new ScrollPane(v2);

		// Create a ScrollPane and set the content to the VBox
		// scrollPane.setPadding(new Insets(10)); // Adjust padding as needed
		scrollPane.setPrefSize(10, 300);

		Button button1 = new Button("Add");

		// button1.setTextFill(blue);
		button1.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");

		// button2.setTextFill(blue);
		button1.setAlignment(Pos.CENTER);

		VBox v = new VBox(hBox1, scrollPane, button1);
		v.setAlignment(Pos.BASELINE_LEFT);
		v.setSpacing(20); // Adjust spacing as needed

		v.setPadding(new Insets(30, 30, 30, 30)); // Adjust padding as needed
		v.setAlignment(Pos.CENTER);

		s.setTitle("Share with A Friend");
		s.getIcons().add(new Image("ICON.png")); // Set application icon
		Scene scene = new Scene(v, 500, 500);
		v.setStyle("-fx-background-color:#c9e9f6;");

		s.setScene(scene);
		// HBox people = new HBox();
		try {
			// Connect to the database
			Connection connection = sql.getConnection();

			// Prepare the SQL statement to retrieve friends from the beFriends table
			String sql = "SELECT A.accountsID, A.userName, A.image FROM beFriends AS BF "
					+ "JOIN Accounts AS A ON BF.seconds = A.accountsID " + "WHERE BF.firsts = ?";

			// Set the firsts parameter to the Admin ID you want to share the file with
			int adminID = 1; // Replace with the actual Admin ID
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, adminID);

			// Execute the SQL statement and retrieve the result set
			ResultSet resultSet = statement.executeQuery();

			// Iterate through the result set and add friends to the HBox
			while (resultSet.next()) {
				int friendAccountID = resultSet.getInt("accountsID");
				String friendUsername = resultSet.getString("userName");
				String friendImage = resultSet.getString("image");

				// Create an EditorsAndViewers object for the friend
				EditorsAndViewers friend = new EditorsAndViewers(new Image(friendImage), friendUsername, true, false,
						true);
				System.out.println("Ah");

				// Add the friend to the HBox
				v.getChildren().add(friend);
			}

			// Close the database connections
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		s.show();
		return s;
	}

	private HBox createHBox(String image1Path, String labelText, boolean checkBoxSelected) {
		Image image1 = new Image(image1Path);
		ImageView imageView1 = new ImageView(image1);
		imageView1.setFitWidth(100); // Adjust width as needed
		imageView1.setFitHeight(100); // Adjust height as needed

		Label label = new Label(labelText);
		label.setStyle("-fx-font-size: 25;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");

		CheckBox checkBox = new CheckBox();
		checkBox.setSelected(checkBoxSelected);

		HBox contentHBox = new HBox(90);
		contentHBox.setAlignment(Pos.CENTER);
		contentHBox.getChildren().addAll(imageView1, label, checkBox);

		return contentHBox;
	}

	public int getFileId(String title) {
		int fileId = 0;

		// SQL query
		String sql = "SELECT fileID FROM Files WHERE fileName = " + title;

		// Gmail value entered by the user
		String enteredName = title;

		try (Connection connection = DriverManager.getConnection(
				"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
				"pinkflowers"); PreparedStatement statement = connection.prepareStatement(sql)) {

			// Set the parameter value for the prepared statement
			statement.setString(1, enteredName);

			// Execute the query
			ResultSet resultSet = statement.executeQuery();

			// Check if the result set has a row
			if (resultSet.next()) {
				// Retrieve the accountID value from the result set
				fileId = resultSet.getInt("fileName");

				// Output the accountID value
				System.out.println("File ID: " + fileId);
			} else {
				System.out.println("No file found with the specified name.");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fileId;
	}

	private void searchForFriend(String searchTerm, VBox friendsVBox) {
		friendsVBox.getChildren().clear();

		try {
			PreparedStatement selectStatement = ((Connection) sql)
					.prepareStatement("SELECT userName, image FROM Accounts WHERE userName LIKE ?");
			selectStatement.setString(1, "%" + searchTerm + "%"); // Use LIKE to perform a partial match

			ResultSet resultSet = selectStatement.executeQuery();

			while (resultSet.next()) {
				String userName = resultSet.getString("userName");
				String userImage = resultSet.getString("image");
				if (userImage == null) {
					userImage = "User1.png";
				}
				String name = userName;
				HBox friendHBox = createHBox(userImage, name, false);
				friendsVBox.getChildren().add(friendHBox);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException as needed
		}
	}

}