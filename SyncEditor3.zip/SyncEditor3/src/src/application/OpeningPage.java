package src.application;

import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class OpeningPage {

//	public Stage showLogin() {
//		Stage stage = new Stage();
//				
//				Scene scene = new Scene(Main.login,500,500);
//				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//				stage.setScene(scene);
//				// stage.setResizable(false);
//				stage.show();
//				return stage;
//			}

	public Stage getStart() {
		Stage s = new Stage();
		Image image = new Image("ICON.png");

		// Create Image View
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(150);
		imageView.setFitHeight(150);
		// Create Label
		Label title = new Label("Sync Editor");
		Font f = Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 50);// type of The Text Main Screen
		Font f2 = Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 30);// type of The Text Main Screen

		title.setFont(f);

		title.setPadding(new Insets(15, 15, 15, 15));
		title.setAlignment(Pos.TOP_CENTER);// to put title in Top of Center
		// Set up colors
		Color color = Color.BLACK;
		// Create Buttons
		Button login = new Button("Login");
		login.setStyle(
				"-fx-font-size: 15;" + "-fx-border-width: 1;" + "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");

		Button newAcc = new Button("Sign Up");
		newAcc.setStyle(

				"-fx-font-size: 15;" + "-fx-border-width: 1;" + "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");

		// login.setPadding(new Insets(15, 15, 15, 15));
		login.setStyle("-fx-background-color:#c9e9f6;");
		login.setTextFill(color);
		login.setMaxWidth(150);
		login.setMaxHeight(200);
		login.setFont(f2);
		// newAcc.setPadding(new Insets(15, 15, 15, 15));
		newAcc.setStyle("-fx-background-color: #c9e9f6;");
		newAcc.setTextFill(color);
		newAcc.setMaxWidth(150);
		newAcc.setMaxHeight(200);
		newAcc.setFont(f2);

		// Set actions for the buttons
		// button1.setOnAction(e -> label.setText("Button 1 Clicked"));
		login.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				s.close();
				Main.login.getStart().show();
			}
		});

		// button2.setOnAction(e -> label.setText("Button 2 Clicked"));
		newAcc.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				s.close();
				Main.signup.signUp();
			}
		});

		// Create a vertical box layout
		VBox vbox = new VBox(40);
		vbox.setStyle("-fx-background-color: while;");
		vbox.setAlignment(Pos.CENTER);
		vbox.setPadding(new Insets(15, 15, 15, 15));
		vbox.getChildren().addAll(imageView, title, login, newAcc);
		// Create the scene
		Scene scene = new Scene(vbox, 500, 600);
		// vbox.setStyle("-fx-background-color: #ADD8E6;");
		// Set the stage title and scene
		s.setTitle("Sync Editor");
		s.setScene(scene);
		s.getIcons().add(image);
		// s.setFullScreen(true);

		// Show the stage
		s.show();
		return s;
	}
}
