package src.application;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class MyFilesPage {
	private GridPane gridPane2 = new GridPane();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;
	TreeSet avlFile = new TreeSet();
	TreeSet avlUser = new TreeSet();
	private TextField textField;
	private CheckBox readWriteCheckBox;
	private CheckBox readOnlyCheckBox;
	String fileName;
	private VBox v;
	Label name;
	App masseges;
	theMainScreen_MYfile myfile = Main.theMain;

	public MyFilesPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	Button button2 = new Button("Create");

	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/synceditors", "root", "1020304050Ss");
			System.out.println("Correct connection");
		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
		}
	}

	GridPane gridPane;

	public GridPane getStart() {
		connect();
		button2 = new Button("Create");
		button2.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-font-weight: Bold;"
				+ "-fx-pref-width: 100;" + "-fx-alignment: CENTER;");

		gridPane = new GridPane();

		try {
			// Retrieve file names from the database for the specified account ID
			PreparedStatement selectFilesStatement = con
					.prepareStatement("SELECT fileName FROM Files WHERE accountsID = ?");
			selectFilesStatement.setInt(1, myfile.id);

			ResultSet filesResultSet = selectFilesStatement.executeQuery();

			while (filesResultSet.next()) {
				String fileNameFromDB = filesResultSet.getString("fileName");

				// Create a VBox for each file from the database
				VBox dbFileVBox = createVBoxFromDatabase(fileNameFromDB);

				// Adding the database file VBox to the GridPane
				addElement(dbFileVBox);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		Label title = new Label("My Files");
		title.setTextFill(Color.BLACK);
		title.setFont(Font.font("Verdana", FontWeight.BOLD, 25));
		title.setAlignment(Pos.CENTER_LEFT);

		Image image4 = new Image("File.png");
		ImageView imageView4 = new ImageView(image4);
		imageView4.setFitWidth(80);
		imageView4.setFitHeight(80);

		TextField textField = new TextField();
		textField.setPromptText("Search My Files");
		textField.setStyle("-fx-prompt-text-fill: black;");
		textField.setPrefWidth(300);
		textField.setPrefHeight(60);
		textField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		Button search = new Button();
		Image image5 = new Image("Search.png");
		ImageView imageView5 = new ImageView(image5);
		imageView5.setFitWidth(60);
		imageView5.setFitHeight(55);
		search.setGraphic(imageView5);
		search.setOnAction(event -> {
			System.out.println("MouseClicked event triggered");
			try {
				searchFiles(textField.getText());
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		HBox hBox1 = new HBox(5);
		hBox1.setAlignment(Pos.CENTER);
		hBox1.getChildren().addAll(imageView4, title);

		HBox hBox2 = new HBox(5);
		hBox2.setAlignment(Pos.CENTER);
		hBox2.getChildren().addAll(textField, search);

		HBox hBox = new HBox(600);
		hBox.setAlignment(Pos.CENTER_LEFT);
		hBox.getChildren().addAll(hBox1, hBox2);

		Separator dashedLine = new Separator();
		dashedLine.getStyleClass().add("dashed-line");

		Button newFiles = new Button(" ");
		Image image6 = new Image("NewFile.png");
		ImageView imageView6 = new ImageView(image6);
		imageView6.setStyle("-fx-background-color:white;");

		newFiles.setGraphic(imageView6);
		imageView6.setFitWidth(150);
		imageView6.setFitHeight(150);
		Label create = new Label("Create New File");
		newFiles.setPrefSize(140, 140);
		create.setStyle("-fx-background-color: white;" + "-fx-font-size: 14;" + "-fx-font-weight: Bold;"
				+ "-fx-alignment: CENTER;");
		create.setTextFill(Color.BLACK);
		newFiles.setOnAction(event -> {
			getCreatNewFile();
		});
		create.setAlignment(Pos.CENTER);
		// Add the button to the GridPane
		newFiles.setAlignment(Pos.BASELINE_LEFT);
		VBox hBox21 = new VBox(10);
		hBox21.setAlignment(Pos.CENTER_LEFT);
		hBox21.getChildren().addAll(newFiles, create);

		VBox v = new VBox(30);
		gridPane.add(v, 0, 0);

		Separator dashedLine3 = new Separator();
		dashedLine3.getStyleClass().add("dashed-line");

		gridPane2.setHgap(150); // Set the horizontal gap between columns

		// Set alignment for the GridPane
		gridPane.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(20, 10, 10, 10));
		v.getChildren().addAll(hBox, dashedLine, hBox21, dashedLine3, gridPane2);
		v.setPrefSize(1260, 900);
		v.setAlignment(Pos.TOP_LEFT);
		gridPane.setPadding(new Insets(20, 10, 10, 10));

		// return gridPane
		// ;
//		gridPane.setPrefSize(1400, 700);

		return gridPane;
	}

	private void updateGridPane() {
		// Clear existing content in the GridPane
		gridPane2.getChildren().clear();
		try {
			// Retrieve file names from the database
			PreparedStatement selectFilesStatement = con
					.prepareStatement("SELECT fileName FROM Files WHERE accountsID = ?");
			selectFilesStatement.setInt(1, myfile.id);
			ResultSet filesResultSet = selectFilesStatement.executeQuery();

			while (filesResultSet.next()) {
				String fileNameFromDB = filesResultSet.getString("fileName");

				// Create a VBox for each file from the database
				VBox dbFileVBox = createVBoxFromDatabase(fileNameFromDB);

				// Adding the database file VBox to the GridPane
				addElement(dbFileVBox);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void searchFiles(String searchText) {
		// Clear the gridPane before adding new search results
		gridPane2.getChildren().clear();
		currentColumn = 0;
		currentRow = 0;

		try {
			// Print debug statement to check if the method is invoked
			System.out.println("Searching for files...");

			// Prepare and execute the search query
			String searchQuery = "SELECT fileName FROM Files WHERE fileName LIKE ? and accountsID = " + myfile.id;
			PreparedStatement searchStatement = con.prepareStatement(searchQuery);
			searchStatement.setString(1, "%" + searchText + "%");

			ResultSet resultSet = searchStatement.executeQuery();

			// Process the search results
			while (resultSet.next()) {
				String fileNameFromDB = resultSet.getString("fileName");

				// Print debug statement to check each file found
				System.out.println("Found file: " + fileNameFromDB);

				// Create a VBox for each file from the database
				VBox dbFileVBox = createVBoxFromDatabase(fileNameFromDB);

				// Adding the database file VBox to the GridPane
				addElement(dbFileVBox);
			}

		} catch (SQLException ex) {
			// Print the stack trace to identify the SQL exception
			ex.printStackTrace();
		}
	}

	private int currentColumn = 0;
	private int currentRow = 0;

	public MyFilesPage(GridPane gridPane2) {
		this.gridPane2 = gridPane2;
	}

	public void addElement(VBox vbox) {
		gridPane2.add(vbox, currentColumn, currentRow);
		gridPane2.setVgap(15);
		currentColumn++;
		if (currentColumn >= 5) {
			currentColumn = 0;
			currentRow++;
		}
	}

	public VBox createVBox(String fileName) {
		VBox vbox = new VBox(15);

		vbox.setStyle("-fx-background-color: #f2f2f2;"); // Set background color
		Image fileImage = new Image("File.png");
		ImageView fileImageView = new ImageView(fileImage);
		fileImageView.setFitWidth(150);
		fileImageView.setFitHeight(110);

		Label fileNameLabel = new Label(fileName);

		Image deleteImage = new Image("DeleteFile.png");
		ImageView deleteImageView = new ImageView(deleteImage);
		deleteImageView.setFitWidth(30);
		deleteImageView.setFitHeight(30);

		Image findUserImage = new Image("FindUser.png");
		ImageView findUserImageView = new ImageView(findUserImage);
		findUserImageView.setFitWidth(30);
		findUserImageView.setFitHeight(30);

		Image editImage = new Image("edit.png");
		ImageView editImageView = new ImageView(editImage);
		editImageView.setFitWidth(30);
		editImageView.setFitHeight(30);

		HBox hBox31 = new HBox(5);
		hBox31.setAlignment(Pos.BASELINE_LEFT);
		hBox31.getChildren().addAll(deleteImageView, findUserImageView, editImageView);

		vbox.getChildren().addAll(fileImageView, fileNameLabel, hBox31);
		vbox.setAlignment(Pos.BASELINE_LEFT);
		return vbox;
	}

	// Method to create a VBox dynamically based on data retrieved from the database
	public VBox createVBoxFromDatabase(String fileNameFromDB) {

		String dummyFileImage = "File.png";
		String dummyDeleteImage = "DeleteFile.png";
		String dummyFindUserImage = "FindUser.png";
		String dummyEditImage = "edit.png";

		VBox vbox = new VBox(15);

		vbox.setStyle("-fx-background-color: #f2f2f2;"); // Set background color
		Image fileImage = new Image(dummyFileImage);
		ImageView fileImageView = new ImageView(fileImage);
		fileImageView.setFitWidth(150);
		fileImageView.setFitHeight(110);

		Label fileNameLabel = new Label(fileNameFromDB);

		Image deleteImage = new Image(dummyDeleteImage);
		ImageView deleteImageView = new ImageView(deleteImage);
		deleteImageView.setFitWidth(30);
		deleteImageView.setFitHeight(30);
		deleteImageView.setOnMouseClicked(e -> {
			getDeleteFile(fileNameFromDB);
		});

		Image findUserImage = new Image(dummyFindUserImage);
		ImageView findUserImageView = new ImageView(findUserImage);
		findUserImageView.setFitWidth(30);
		findUserImageView.setFitHeight(30);
		findUserImageView.setOnMouseClicked(e -> {
			getEditorsOfThisFile(fileNameFromDB);
		});

		Image editImage = new Image(dummyEditImage);
		ImageView editImageView = new ImageView(editImage);
		editImageView.setFitWidth(30);
		editImageView.setFitHeight(30);
		editImageView.setOnMouseClicked(e -> {
			TextInputDialog dialog = new TextInputDialog(fileNameFromDB);
			dialog.setTitle("Edit File Name");
			dialog.setHeaderText("Enter the new file name:");
			dialog.setContentText("File Name:");

			String oldName = fileNameLabel.getText();
			Optional<String> result = dialog.showAndWait();
			result.ifPresent(newFileName -> {
				if (!newFileName.isEmpty()) {
					// Update the label with the new file name
					fileNameLabel.setText(newFileName);

					// Find the file ID by the new file name
					int newFileID = findFileIDByName(oldName);

					if (newFileID != -1) {
						// Update the file name in the database
						updateFileNameInDatabase(newFileID, newFileName);

						// You can add additional logic here if needed
					} else {
						System.out.println("File ID not found for the new file name: " + newFileName);
					}
				}
			});
		});

		HBox hBox31 = new HBox(5);
		hBox31.setAlignment(Pos.BASELINE_LEFT);
		hBox31.getChildren().addAll(deleteImageView, findUserImageView, editImageView);

		vbox.getChildren().addAll(fileImageView, fileNameLabel, hBox31);
		vbox.setAlignment(Pos.BASELINE_LEFT);
		return vbox;
	}

	private void updateFileNameInDatabase(int fileID, String newFileName) {
		String query = "UPDATE Files SET fileName = ? WHERE fileID = ?";
		try (PreparedStatement statement = con.prepareStatement(query)) {
			statement.setString(1, newFileName);
			statement.setInt(2, fileID);

			// Execute the update statement
			int rowsUpdated = statement.executeUpdate();

			if (rowsUpdated > 0) {
				showAlert(Alert.AlertType.NONE, "Success", "File name updated successfully in the database.");
			} else {
				showAlert(Alert.AlertType.ERROR, "Error", "File name update failed. File ID not found: " + fileID);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException
			showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while updating the file name.");
		}
	}

	private void showAlert(Alert.AlertType alertType, String title, String content) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);

		// Add OK button
		alert.getButtonTypes().setAll(ButtonType.OK);

		// Show the alert and wait for user response
		alert.showAndWait();
	}

	private int findFileIDByName(String fileName) {
		String query = "SELECT fileID FROM Files WHERE fileName = ? and accountsID =" + myfile.id;
		try (PreparedStatement statement = con.prepareStatement(query)) {
			statement.setString(1, fileName);

			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					return resultSet.getInt("fileID");
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException
		}

		return -1; // Return -1 if the file ID is not found
	}

	public Stage getEditorsOfThisFile(String fileName) {
		Stage s3 = new Stage();

		Image image = new Image("ICON.png");

		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(270);
		imageView.setFitHeight(190);

		Image image2 = new Image("File.png");

		ImageView photoImageView = new ImageView(image2);
		photoImageView.setFitWidth(90);
		photoImageView.setFitHeight(90);
		Label photoLabel = new Label(fileName);
		photoLabel
				.setStyle("-fx-font-size: 20;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n");
		photoLabel.setAlignment(Pos.CENTER);
		// Create an HBox for photo and label
		HBox photoHBox = new HBox(20);
		photoHBox.getChildren().addAll(photoImageView, photoLabel);
		photoHBox.setAlignment(Pos.CENTER_LEFT);
		VBox v = new VBox(); // Create VBox to hold HBox elements

		int fileID = getFileID(fileName);

		String shareFileQuery = "SELECT S.sender, S.recever, A.userName AS receiverName " + "FROM shareFile S "
				+ "JOIN Accounts A ON S.recever = A.accountsID " + "WHERE S.fileID = ?";

		try (PreparedStatement shareFileStatement = con.prepareStatement(shareFileQuery)) {
			shareFileStatement.setInt(1, fileID);

			ResultSet resultSet = shareFileStatement.executeQuery();

			while (resultSet.next()) {
				int senderID = resultSet.getInt("sender");
				int receiverID = resultSet.getInt("recever");
				String receiverName = resultSet.getString("receiverName");

				// Retrieve the image of the receiver
				Image receiverImage = getImageFromDatabase(receiverID);

				// Assuming you have a method to create an HBox for each shared account
				HBox sharedAccountHBox = createHBox123(receiverName, receiverImage, false, true, fileID);
				v.getChildren().add(sharedAccountHBox);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Handle the exception appropriately
		} // Handle the exception appropriately

		v.setAlignment(Pos.CENTER_LEFT);
		v.setSpacing(10); // Adjust spacing as needed
		v.setPadding(new Insets(20, 20, 20, 20)); // Adjust padding as needed

		// Create a ScrollPane and set the content to the VBox
		ScrollPane scrollPane = new ScrollPane(v);
		scrollPane.setPrefSize(10, 300);

		VBox vbox = new VBox(photoHBox, scrollPane);
		vbox.setSpacing(20); // Adjust spacing between HBoxes
		vbox.setAlignment(Pos.CENTER);
		vbox.setPadding(new Insets(25, 25, 25, 25)); // Adjust padding as needed

		s3.setTitle("Editors Of This File");
		s3.getIcons().add(new Image("ICON.png")); // Set application icon
		Scene scene = new Scene(vbox, 800, 500);
		vbox.setStyle("-fx-background-color: #c9e9f6;");

		s3.setScene(scene);

		s3.show();
		return s3;
	}

	private HBox createHBox123(String userName, Image userImage, boolean readButtonSelected,
			boolean readWriteButtonSelected, int fileID) {
		ImageView userImageView = new ImageView(userImage);
		userImageView.setFitWidth(60);
		userImageView.setFitHeight(60);

		Label label1 = new Label(userName);
		label1.setStyle("-fx-font-size: 14;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width: 3.5;");

		RadioButton readButton = new RadioButton("Read Only");
		readButton.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width: 3.5;");
		readButton.setSelected(readButtonSelected);
		ToggleGroup toggleGroup = new ToggleGroup();
		readButton.setToggleGroup(toggleGroup);

		RadioButton readWriteButton = new RadioButton("Read/Write");
		readWriteButton.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width: 3.5;");
		readWriteButton.setSelected(readWriteButtonSelected);
		readWriteButton.setToggleGroup(toggleGroup);

		Image image2 = new Image("kickOut.png");
		ImageView imageView2 = new ImageView(image2);
		imageView2.setFitWidth(60);
		imageView2.setFitHeight(60);

		// Create HBox to hold the first set of components
		HBox hbox1 = new HBox(userImageView, label1, readButton, readWriteButton, imageView2);
		hbox1.setAlignment(Pos.CENTER_LEFT);
		hbox1.setSpacing(60);
		hbox1.setPadding(new Insets(15, 15, 15, 15));

		// Use the values of readButtonSelected and readWriteButtonSelected to determine
		// privilege
		boolean privilege = readWriteButtonSelected;

		// Store changes in the database
		storeEditorsChanges(fileID, userName, privilege);

		return hbox1;
	}

	private void storeEditorsChanges(int fileID, String userName, boolean readWriteSelected) {
		// Assuming con is declared and initialized somewhere in your class

		// Retrieve editorID based on userName
		try {
			int editorID = getEditorID(userName);

			if (editorID > 0) {
				// Update or insert into Editors table
				String sql = "INSERT INTO Editors (privilege, fileID, editor) VALUES (?, ?, ?) "
						+ "ON DUPLICATE KEY UPDATE privilege = VALUES(privilege)";

				try (PreparedStatement updateStatement = con.prepareStatement(sql)) {
					updateStatement.setBoolean(1, readWriteSelected);
					updateStatement.setInt(2, fileID);
					updateStatement.setInt(3, editorID);

					// Print values for debugging
					System.out.println("Attempting to insert/update into Editors table:");
					System.out.println("fileID: " + fileID);
					System.out.println("editorID: " + editorID);

					// Print the SQL statement
					System.out.println("SQL Statement: " + sql);

					// Execute the statement
					updateStatement.executeUpdate();

					System.out.println("Editors table updated successfully");
				}
			}
		} catch (SQLIntegrityConstraintViolationException ex) {
			ex.printStackTrace();
			System.out.println("Error: SQL Integrity Constraint Violation");
			System.out.println("FileID: " + fileID);
			System.out.println("Editor userName: " + userName);
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("Error: SQL Exception");
			// Handle other SQLExceptions if needed
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Unexpected error occurred");
		} finally {
			// Close the connection (if needed)
			// You may want to handle this in a separate method or elsewhere, depending on
			// your application structure
			// if (con != null) {
			// try {
			// con.close();
			// } catch (SQLException e) {
			// e.printStackTrace();
			// }
			// }
		}
	}

	// Helper method to get editorID based on userName
	private int getEditorID(String userName) throws SQLException {
		int editorID = getEditorID(userName);
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/synceditors", "root",
				"1020304050Ss")) {
			String query = "SELECT accountsID FROM Accounts WHERE userName = ?";
			try (PreparedStatement statement = con.prepareStatement(query)) {
				statement.setString(1, userName);

				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						editorID = resultSet.getInt("accountsID");
					}
				}
			}
		}
		return editorID;
	}

	public Stage getDeleteFile(String fileName) {
		Stage s = new Stage();

		Image image = new Image("ICON.png");

		// Create Image View
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(60);
		imageView.setFitHeight(50);

		Image image2 = new Image("DeleteFile.png");

		// Create an ImageView for the photo
		ImageView photoImageView = new ImageView(image2);
		photoImageView.setFitWidth(100);
		photoImageView.setFitHeight(100);
		Label photoLabel = new Label(
				"Are You Sure You want to permanetly delete " + fileName + " " + "From Your Files ? ");
		photoLabel.setStyle("-fx-font-size: 16;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");
		// Create an HBox for photo and label
		HBox photoHBox = new HBox(20);
		photoHBox.getChildren().addAll(photoImageView, photoLabel);
		photoHBox.setAlignment(Pos.CENTER);

		Label photoLabel2 = new Label(
				"Deleting this file will result in the loss of all Reading / Writing Privileges .");
		Color blue = Color.BLACK;

		photoLabel2.setAlignment(Pos.CENTER);
		photoLabel2.setStyle("-fx-font-size: 14;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");
		Button button1 = new Button("Cancel");
		Button button2 = new Button("Delete");
		button1.setTextFill(blue);
		button1.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 100;" + "-fx-alignment: CENTER;");
		button1.setOnAction(e -> {
			s.close();
		});
		button2.setTextFill(blue);
		button2.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 100;" + "-fx-alignment: CENTER;");
		button2.setOnAction(e -> {
			// Show confirmation dialog without header text before deleting
			Alert alert = new Alert(Alert.AlertType.NONE);
			alert.setContentText("File deleted successfully");
			alert.getButtonTypes().setAll(ButtonType.YES);
			alert.setGraphic(new ImageView(new Image("DeleteFile.png")));
			alert.showAndWait();

			if (alert.getResult() == ButtonType.YES) {
				// Call method to delete file from SQL and update tree view
				deleteFileFromDatabase(fileName);
			}

		});

		// Create a VBox for label and buttons
		HBox vbox = new HBox(20);
		vbox.getChildren().addAll(button1, button2);
		vbox.setAlignment(Pos.BASELINE_RIGHT);

		StackPane root = new StackPane();

		VBox vboxF = new VBox(30);
		vboxF.setAlignment(Pos.CENTER);
		vboxF.setPadding(new Insets(15, 15, 15, 15));
		vboxF.getChildren().addAll(photoHBox, photoLabel2, vbox);
		root.getChildren().add(vboxF);
		// Create the scene
		Scene scene = new Scene(root, 800, 300);
		root.setStyle("-fx-background-color:#c9e9f6;"); // Set t
		// vbox.setStyle("-fx-background-color: #ADD8E6;");
		// Set the stage title and scene
		s.setTitle("Delete File");
		s.getIcons().add(new Image("ICON.png")); // Set application icon

		s.setScene(scene);
		s.getIcons().add(image);

		// Show the stage
		s.show();
		return s;
	}

	private void deleteFileFromDatabase(String fileName) {
		try {
			// Delete dependent rows from the sharefile table
			PreparedStatement deleteShareFileStatement = con.prepareStatement(
					"DELETE FROM sharefile WHERE fileID IN (SELECT fileID FROM Files WHERE fileName = ?)");
			deleteShareFileStatement.setString(1, fileName);
			deleteShareFileStatement.executeUpdate();

			// Delete dependent rows from the editors table
			PreparedStatement deleteEditorsStatement = con.prepareStatement(
					"DELETE FROM editors WHERE fileID IN (SELECT fileID FROM Files WHERE fileName = ?)");
			deleteEditorsStatement.setString(1, fileName);
			deleteEditorsStatement.executeUpdate();

			// Now you can safely delete the file from the Files table
			PreparedStatement deleteStatement = con.prepareStatement("DELETE FROM Files WHERE fileName = ?");
			deleteStatement.setString(1, fileName);

			int rowsAffected = deleteStatement.executeUpdate();

			if (rowsAffected > 0) {
//				avlFile.remove(fileName);
				updateGridPane();
				System.out.println("File deleted successfully");
			} else {
				System.out.println("File not found or deletion unsuccessful");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.err.println("SQLException: " + ex.getMessage());
			System.err.println("SQLState: " + ex.getSQLState());
			System.err.println("VendorError: " + ex.getErrorCode());
		}
	}

	Image image1 = new Image("User.png");
	Image image22 = new Image("KickOut.png");

	Button shareWithFriend = new Button("Share with a friend");
	Button create = new Button("Create");
	VBox v2;

	private int getFileID(String fileName) {
		int fileID = -1; // Default value if the file is not found

		// Fetch fileID based on fileName from the Files table
		String getFileIDQuery = "SELECT fileID FROM Files WHERE fileName = ?";

		try (PreparedStatement statement2 = con.prepareStatement(getFileIDQuery)) {
			statement2.setString(1, fileName);

			try (ResultSet resultSet2 = statement2.executeQuery()) {
				if (resultSet2.next()) {
					fileID = resultSet2.getInt("fileID");
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException
		}

		return fileID;
	}

	public Stage getCreatNewFile() {
		Stage s2 = new Stage();

		Label photoLabel = new Label("File Name");
		photoLabel
				.setStyle("-fx-font-size: 20;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n");
		photoLabel.setAlignment(Pos.CENTER_LEFT);
		photoLabel.setPadding(new Insets(15, 5, 10, 10)); // Adjust padding as needed
		TextField textField = new TextField();
		textField.setPromptText("Creat New File ");
		textField.setStyle("-fx-prompt-text-fill: black;");
		textField.setPrefWidth(300);
		textField.setPrefHeight(90);
		textField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));

		// Create ImageView and Label for the first set
		ImageView imageView1 = new ImageView(image1);
		imageView1.setFitWidth(60); // Adjust width as needed
		imageView1.setFitHeight(60); // Adjust height as needed

		Image image21 = new Image("User1.png");

		// Create ImageView and Label for the first set
		ImageView imageView12 = new ImageView(image21);
		imageView12.setFitWidth(60); // Adjust width as needed
		imageView12.setFitHeight(60); // Adjust height as needed
		HBox userHBox = null;
		// Assuming you have a database connection named "con"
		try {
			connect();
			// Create a PreparedStatement to execute the SQL query
			PreparedStatement selectStatement = con
					.prepareStatement("SELECT userName, image AS userImage FROM Accounts WHERE userName = ?");
			selectStatement.setString(1, myfile.username); // Replace with the desired username
			int senderID = getAccountsID(myfile.username);

			// Execute the query
			ResultSet resultSet = selectStatement.executeQuery();

			if (resultSet.next()) {
				String userName = resultSet.getString("userName");

				Image userImage = getImageFromDatabase(senderID);

				// Create ImageView and Label for the user
				ImageView userImageView = new ImageView(userImage);
				userImageView.setFitWidth(90); // Adjust width as needed
				userImageView.setFitHeight(90); // Adjust height as needed

				Label userNameLabel = new Label(userName);
				userNameLabel.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
						+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");

				// Create HBox with user information
				userHBox = new HBox(userImageView, userNameLabel);
				userHBox.setAlignment(Pos.CENTER_LEFT);
				userHBox.setSpacing(170); // Adjust spacing as needed
				userHBox.setPadding(new Insets(10)); // Adjust padding as needed

			} else {
				// User not found in the database
				System.out.println("User not found");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		ImageView adminImageView = new ImageView(new Image("admin.png"));
		adminImageView.setFitWidth(90); // Adjust width as needed
		adminImageView.setFitHeight(90); // Adjust height as needed
		Label ad = new Label("Admin");
		ad.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");
		userHBox.getChildren().addAll(ad, adminImageView);
		Separator dashedLine3 = new Separator();
		dashedLine3.getStyleClass().add("dashed-line");
		// HBox hbox1 = createHBox123("Sanaa Obied", "User.png", "KickOut.png", true,
		// false);
		v2 = new VBox(userHBox, dashedLine3);

		v2.setAlignment(Pos.BASELINE_LEFT);
		v2.setSpacing(5); // Adjust spacing as needed

		v2.setPadding(new Insets(10, 10, 10, 10)); // Adjust padding as needed

		// Create a ScrollPane and set the content to the VBox
		ScrollPane scrollPane = new ScrollPane(v2);
		// scrollPane.setPadding(new Insets(10)); // Adjust padding as needed
		scrollPane.setPrefSize(10, 300);

		shareWithFriend = new Button("Share with a friend");
		button2 = new Button("Create");
		// button1.setTextFill(blue);
		shareWithFriend.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-font-weight: Bold;"
				+ "-fx-pref-width: 230;" + "-fx-alignment: CENTER;");
		shareWithFriend.setOnAction(e -> {
			getShareFileWithFriend();
		});
		// button2.setTextFill(blue);
		create.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" +

				"-fx-font-weight: Bold;" + "-fx-pref-width: 100;" + "-fx-alignment: CENTER;");
		create.setOnAction(e -> {
			// Retrieve the file name from the text field
			fileName = textField.getText();

			try {
				// Get the accountsID for the sender (modify the username as needed)
				int senderID = myfile.id;

				connect();
				// Insert data into Files table
				PreparedStatement insertFileStatement = con.prepareStatement(
						"INSERT INTO Files (fileName, accountsID, texts) VALUES (?, ?, ?)",
						Statement.RETURN_GENERATED_KEYS);

				insertFileStatement.setString(1, fileName);
				insertFileStatement.setInt(2, senderID);
				insertFileStatement.setBytes(3, null); // You can set the file content here if needed

				int affectedRows = insertFileStatement.executeUpdate();

				if (affectedRows > 0) {
					// Retrieve the generated keys (if any)
					ResultSet generatedFileKeys = insertFileStatement.getGeneratedKeys();
					if (generatedFileKeys.next()) {
						int fileID = generatedFileKeys.getInt(1);

						if (name != null) {
							// Get the accountsID for the receiver (modify the username as needed)

							int receiverID = getAccountsID(name.getText());

							// Insert data into shareFile table
							PreparedStatement insertShareFileStatement = con.prepareStatement(
									"INSERT INTO shareFile (sender, recever, fileID) VALUES (?, ?, ?)");

							insertShareFileStatement.setInt(1, senderID);
							insertShareFileStatement.setInt(2, receiverID);
							insertShareFileStatement.setInt(3, fileID);

							insertShareFileStatement.executeUpdate();

							// Insert data into Editors table
							PreparedStatement insertEditorsStatement = con.prepareStatement(
									"INSERT INTO Editors (privilege, fileID, editor) VALUES (?, ?, ?)");

							insertEditorsStatement.setBoolean(1, true); // Assuming true for Write privilege
							insertEditorsStatement.setInt(2, fileID);
							insertEditorsStatement.setInt(3, senderID);

							insertEditorsStatement.executeUpdate();

							// Create a new Files object with the retrieved information
							Files newFile = new Files(fileName); // Update this constructor as needed
							avlFile.add(newFile);

							// Creating an instance of FileManager
							// Creating a VBox for a new file
							VBox newFileVBox = createVBox(fileName);

							// Adding the new file VBox to the GridPane
							addElement(newFileVBox);
							String receiverEmail = getEmailFromID(receiverID);
							System.out.println("the email is " + receiverEmail);
							masseges = new App(receiverEmail);
							// Display a success message (optional)
							Alert alert = new Alert(Alert.AlertType.NONE);
							alert.setTitle("File Created");
							alert.setHeaderText(null);
							alert.setContentText("The file has been created and shared successfully!");

							ButtonType okButton = new ButtonType("OK");
							alert.getButtonTypes().setAll(okButton);

							Optional<ButtonType> result = alert.showAndWait();
							if (result.isPresent() && result.get() == okButton) {
								// Close the stage
								s2.close();
							}
						}

						// Clear the text field
						// textField.clear();
					}
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		});

		// Create a VBox for label and buttons
		HBox vbox = new HBox(20);
		vbox.getChildren().addAll(shareWithFriend, create);
		vbox.setAlignment(Pos.BASELINE_RIGHT);
		VBox vbox2 = new VBox(photoLabel, textField, scrollPane, vbox);
		vbox2.setSpacing(25); // Adjust spacing between HBoxes

		vbox2.setAlignment(Pos.BASELINE_LEFT);
		vbox2.setPadding(new Insets(25, 25, 25, 25)); // Adjust padding as needed

		s2.setTitle("Editors Of This File");
		s2.getIcons().add(new Image("ICON.png")); // Set application icon
		Scene scene = new Scene(vbox2, 900, 500);
		vbox2.setStyle("-fx-background-color: #c9e9f6;");

		s2.setScene(scene);

		s2.show();
		return s2;
	}

	private String getEmailFromID(int accountsID) {
		String email = null;

		try {
			// Assuming con is declared and initialized somewhere in your class
			String query = "SELECT gmail FROM Accounts WHERE accountsID = ?";

			try (PreparedStatement statement = con.prepareStatement(query)) {
				statement.setInt(1, accountsID);

				try (ResultSet innerResultSet = statement.executeQuery()) {
					if (innerResultSet.next()) {
						email = innerResultSet.getString("gmail");
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace(); // Handle the exception appropriately
		}

		return email;
	}

	public Image getImageFromDatabase(int id) {
		try {

			// SQL query to select the image data
			String sql = "SELECT image FROM accounts WHERE accountsID = " + id + ";";

			try (Statement statement = con.createStatement()) {
				// Execute the query
				ResultSet resultSet = statement.executeQuery(sql);

				if (resultSet.next()) {
					// Get the image data from the result set
					byte[] imageData = resultSet.getBytes("image");

					ByteArrayInputStream bis = null;
					// Convert the image data to a JavaFX Image
					if (imageData != null) {
						bis = new ByteArrayInputStream(imageData);

						return new Image(bis);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null && !con.isClosed()) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	// Helper method to get accountsID based on username
	private int getAccountsID(String username) throws SQLException {
		connect();
		String query = "SELECT accountsID FROM Accounts WHERE userName = ?";
		try (PreparedStatement statement = con.prepareStatement(query)) {
			statement.setString(1, username);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getInt("accountsID");
			} else {
				throw new SQLException("User not found: " + username);
			}
		}
	}

	private HBox createHBox123(String userName, String userImage, String kickOutImage, boolean isReadOnly,
			boolean isReadWrite, List<String> selectedFriends) {
		HBox hbox = new HBox(130);
		hbox.setAlignment(Pos.CENTER_LEFT);

		// Create an ImageView for the user image
		ImageView userImageView = new ImageView(new Image("User1.png"));
		userImageView.setFitWidth(60);
		userImageView.setFitHeight(60);

		// Create a Label for the user name
		Label userNameLabel = new Label(userName);
		userNameLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 14));

		// Create a ToggleGroup for radio buttons
		ToggleGroup toggleGroup = new ToggleGroup();

		// Create a RadioButton for read-only privilege
		RadioButton readOnlyRadioButton = new RadioButton("Read-only");
		readOnlyRadioButton.setToggleGroup(toggleGroup);
		readOnlyRadioButton.setSelected(isReadOnly);

		// Create a RadioButton for read-write privilege
		RadioButton readWriteRadioButton = new RadioButton("Read-write");
		readWriteRadioButton.setToggleGroup(toggleGroup);
		readWriteRadioButton.setSelected(isReadWrite);

		// Create an ImageView for the kick-out image
		ImageView kickOutImageView = new ImageView(new Image("kickOut.png"));
		kickOutImageView.setFitWidth(20);
		kickOutImageView.setFitHeight(20);

		// Add all the elements to the HBox
		hbox.getChildren().addAll(userImageView, userNameLabel, readOnlyRadioButton, readWriteRadioButton,
				kickOutImageView);

		// Add an event handler to the HBox to update the selectedFriends list
		hbox.setOnMouseClicked(event -> {
			// Assuming the Label is the second child in the HBox
			Label label = (Label) hbox.getChildren().get(1);

			// If the friend's name is not already in the list, add it
			if (!selectedFriends.contains(label.getText())) {
				selectedFriends.add(label.getText());
			} else {
				// If the friend's name is already in the list, remove it
				selectedFriends.remove(label.getText());
			}

			System.out.println("Selected Friends: " + selectedFriends);
		});

		return hbox;
	}

	ImageView imageView2 = new ImageView(new Image("User1.png"));

	public Stage getShareFileWithFriend() {
		Stage stage = new Stage();

		Image image = new Image("ICON.png");

		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(270);
		imageView.setFitHeight(190);

		TextField searchTextField = new TextField();
		searchTextField.setPromptText("Search My Friends");
		searchTextField.setStyle("-fx-prompt-text-fill: black;");
		searchTextField.setPrefWidth(250);
		searchTextField.setPrefHeight(50);
		searchTextField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));

		Image searchImage = new Image("Search.png");
		ImageView searchImageView = new ImageView(searchImage);
		searchImageView.setFitWidth(40);
		searchImageView.setFitHeight(40);

		Button searchButton = new Button();
		searchButton.setGraphic(searchImageView);
		searchButton.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");
		VBox friendsVBox = new VBox();
		searchButton.setOnAction(event -> {

			String searchTerm = searchTextField.getText();

			searchForFriend(searchTerm, friendsVBox);

		});

		HBox searchHBox = new HBox(15);
		searchHBox.setAlignment(Pos.CENTER_LEFT);
		searchHBox.getChildren().addAll(searchTextField, searchButton);

		friendsVBox.setAlignment(Pos.BASELINE_LEFT);
		friendsVBox.setSpacing(5);
		friendsVBox.setPadding(new Insets(10, 10, 10, 10));

		fetchFriendsFromDatabase(friendsVBox, myfile.username);
		ScrollPane scrollPane = new ScrollPane(friendsVBox);
		scrollPane.setPrefSize(10, 300);

		Button addButton = new Button("Add");
		addButton.setStyle("-fx-background-color: white;" + "-fx-font-size: 20;" + "-fx-border-width: 1;"
				+ "-fx-font-weight: Bold;" + "-fx-pref-width: 90;");

		addButton.setAlignment(Pos.CENTER);
		addButton.setAlignment(Pos.CENTER);
		addButton.setOnAction(e -> {
			name = new Label();

			try {
				shareFilesWithSelectedFriends(friendsVBox, myfile.username, selectedFriends, name);

				int senderID = getAccountsID(myfile.username);
				Image friendImage = getImageFromDatabase(senderID);

				// Collect unique names from selectedFriends
				Set<String> uniqueNames = selectedFriends.stream().filter(friend -> friend != null)
						.filter(text -> text != null).collect(Collectors.toSet());

				// Create an HBox for each unique name
				for (String friendName : uniqueNames) {
					v2.getChildren().add(createHBox123(friendName, friendImage.getUrl(), "kickOutImage.png", false,
							true, selectedFriends));
				}
			} catch (SQLException | NullPointerException ex) {
				ex.printStackTrace();
			}
		});

		VBox mainVBox = new VBox(searchHBox, scrollPane, addButton);
		mainVBox.setAlignment(Pos.CENTER);
		mainVBox.setSpacing(20);
		mainVBox.setPadding(new Insets(30, 30, 30, 30));

		stage.setTitle("Share with A Friend");
		stage.getIcons().add(new Image("ICON.png"));
		Scene scene = new Scene(mainVBox, 500, 500);
		mainVBox.setStyle("-fx-background-color:#c9e9f6;");

		stage.setScene(scene);

		stage.show();

		return stage;
	}

	private int getAccountIdFromDatabase(String name) {
		int accountId = -1; // Default value if the account ID is not found
		// Assuming you are using JDBC to interact with the database
		connect();
		try (Connection connection = con) {
			// Prepare the SQL statement
			String sql = "SELECT accountsID FROM Accounts WHERE userName = ?";
			PreparedStatement statement = connection.prepareStatement(sql);

			// Set the parameter value
			statement.setString(1, name);

			// Execute the query
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				// Retrieve the account ID from the result set
				accountId = resultSet.getInt("accountsID");
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountId;
	}

	private void searchForFriend(String searchTerm, VBox friendsVBox) {
		friendsVBox.getChildren().clear();

		try {
			PreparedStatement selectStatement = con
					.prepareStatement("SELECT userName, image FROM Accounts WHERE userName LIKE ?");
			selectStatement.setString(1, "%" + searchTerm + "%"); // Use LIKE to perform a partial match

			ResultSet resultSet = selectStatement.executeQuery();

			while (resultSet.next()) {
				String userName = resultSet.getString("User.png");
//				String userImage = resultSet.getString("image");
				Image userImage = getImageFromDatabase(getAccountIdFromDatabase(myfile.username));

				if (userImage == null) {
					userImage = new Image("User1.png");
				}
				Label name = new Label(userName);
				HBox friendHBox = createFriendHBox(userImage, name, false);
				friendsVBox.getChildren().add(friendHBox);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException as needed
		}
	}

	private void fetchFriendsFromDatabase(VBox friendsVBox, String userName) {
		try {
			connect();
			PreparedStatement selectStatement = con
					.prepareStatement("SELECT userName, image FROM Accounts WHERE accountsID IN "
							+ "(SELECT firsts FROM beFriends WHERE seconds = "
							+ "(SELECT accountsID FROM Accounts WHERE userName = ?) UNION "
							+ "SELECT seconds FROM beFriends WHERE firsts = "
							+ "(SELECT accountsID FROM Accounts WHERE userName = ?)) " + "AND userName <> ?");
			selectStatement.setString(1, userName);
			selectStatement.setString(2, userName);
			selectStatement.setString(3, userName);

			ResultSet resultSet = selectStatement.executeQuery();

			try {
				connect();

				while (resultSet.next()) {
					String friendName = resultSet.getString("userName");
					System.out.println("Freind Name is " + friendName);

					// Convert Blob to byte array
					int id = getAccountsID(friendName);
					// Convert byte array to Image
					Image friendImage = getImageFromDatabase(id);

					// Convert Image to String URL representation
//					String friendImagePath = friendImage.getUrl();

					// Assuming createFriendHBox method is correctly implemented
					if (friendName != null) {
						System.out.println("Friend Name is " + friendName);
						Label name = new Label(friendName);
						HBox friendHBox = createFriendHBox(friendImage, name, false);
						friendsVBox.getChildren().add(friendHBox);
					} else {
						System.out.println("Friend Name is null");
					}

					// Add friendHBox to the specified VBox
				}
			} catch (SQLException e) {
				e.printStackTrace(); // Handle the exception appropriately
			}

			con.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle SQLException as needed
		}
	}

	private Image getDefaultImage() {
		// Replace with the path to your default image
		String defaultImagePath = "User.png";
		return new Image(defaultImagePath);
	}

	private void shareFilesWithSelectedFriends(VBox friendsVBox, String senderUserName, List<String> selectedFriends,
			Label name) {
		// Loop through the selected friends and perform the file-sharing action
		for (Node node : friendsVBox.getChildren()) {
			if (node instanceof HBox) {
				HBox friendHBox = (HBox) node;
				// Assuming the Label is the second child in the HBox
				Label label = (Label) friendHBox.getChildren().get(1);
				String friendName = label.getText();

				if (selectedFriends.contains(friendName)) {
					// selectedFriends.add(friendName);
					// Share files with the selected friend
					name.setText(friendName);
					// Add your file-sharing logic here
				}
			}
		}
	}

	List<String> selectedFriends;

	private HBox createFriendHBox(Image image1Path, Label labelText, boolean checkBoxSelected) {
		ImageView imageView1 = new ImageView(image1Path);
		imageView1.setFitWidth(80);
		imageView1.setFitHeight(80);
		System.out.println("Label Text: " + labelText);
		labelText.setStyle("-fx-font-size: 25;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");

		CheckBox checkBox = new CheckBox();
		checkBox.setSelected(checkBoxSelected);

		// Assuming you have a List<String> to store the names of selected friends
		selectedFriends = new ArrayList<>();

		// Add an event handler to the CheckBox
		checkBox.setOnAction(event -> {
			if (checkBox.isSelected()) {
				// Add the name to the list when checkbox is selected
				selectedFriends.add(labelText.getText());
			} else {
				// Remove the name from the list when checkbox is not selected
				selectedFriends.remove(labelText);
			}
		});

		HBox friendHBox = new HBox(100);
		friendHBox.setAlignment(Pos.TOP_LEFT);
		friendHBox.getChildren().addAll(imageView1, labelText, checkBox);

		return friendHBox;
	}

}