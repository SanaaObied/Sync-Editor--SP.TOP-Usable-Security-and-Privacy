package src.application;

import java.sql.SQLException;
import java.sql.Statement;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ResetPassword {

	private PasswordField password, rewritePassword;
	private Button reset;
	private Label back;
	private String email;

	public Stage getStart(String email) {

		this.email = email;

		Stage stage = new Stage();
		BorderPane root = new BorderPane();

		Scene scene = new Scene(root, 600, 410);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);

		password = new PasswordField();
		rewritePassword = new PasswordField();
		reset = new Button("Continue");
		back = new Label();
		Label header = new Label("Reset Password");
		ImageView arrow = new ImageView(new Image("arrow.png"));
		ImageView lockImg = new ImageView(new Image("Lock.png"));
		ImageView rewriteImg = new ImageView(new Image("rewritePassword.png"));
		ImageView resetPassImg = new ImageView(new Image("resetPassword.png"));

		Text matchPass = new Text("");
		matchPass.setFill(Color.RED);

		back.setOnMouseClicked(e -> {

			stage.close();
			Main.login.getStart().show();

		});

		// Add an EventHandler to the textProperty
		password.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (password.getText().trim().isEmpty()) {
				password.getStyleClass().clear();
				password.getStyleClass().add("textField");
			} else if (!Main.chickpass.isStrongPassword(newValue)) {
				System.out.println("Current Password: " + newValue);
				password.getStyleClass().clear();
				password.getStyleClass().add("errorTextF2");

			} else {
				password.getStyleClass().clear();
				password.getStyleClass().add("greenTextF");
				matchPass.setText("Strong Password");
				matchPass.setFill(Color.GREEN);

			}
		});

		// Add an EventHandler to the textProperty
		rewritePassword.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (rewritePassword.getText().trim().isEmpty()) {
				matchPass.setText(" ");
				rewritePassword.getStyleClass().clear();
				rewritePassword.getStyleClass().add("textField");
			} else if (!rewritePassword.getText().equals(password.getText())) {
				System.out.println("Current Password: " + newValue);
				rewritePassword.getStyleClass().clear();
				rewritePassword.getStyleClass().add("errorTextF2");
				matchPass.setText("Password not matching");
				matchPass.setFill(Color.RED);

			} else {
				matchPass.setText(" ");
				rewritePassword.getStyleClass().clear();
				rewritePassword.getStyleClass().add("greenTextF");

			}
		});

		reset.setOnAction(e -> {

			if (rewritePassword.getText().equals(password.getText())) {// matching

				if (Main.chickpass.isStrongPassword(password.getText())) {// is strong and matching

					try {
						Main.conne.connectDB();

						// Create a statement object to execute the query
						Statement statement = Main.conne.connect().createStatement();

						statement.execute("UPDATE Accounts SET pass = '" + password.getText() + "' ;");

						System.out.println("UPDATED");
						statement.close();
						Main.conne.connect().close();

					} catch (ClassNotFoundException f) {
						// TODO Auto-generated catch block
						f.printStackTrace();
					} catch (SQLException f) {
						// Handle other SQLExceptions, if necessary
						System.err.println("SQL error occurred: " + f.getMessage());
					}

					stage.close();
					Main.signup.signUp();

				} else {// not strong

					Main.signup.strongPassword();
				}
			} else {// not matching

				Main.warning.WarningMessage("", "The passwords entered aren't matching.");
			}
		});

		arrow.setFitWidth(40);
		arrow.setFitHeight(40);
		lockImg.setFitWidth(30);
		lockImg.setFitHeight(30);
		rewriteImg.setFitWidth(30);
		rewriteImg.setFitHeight(30);
		resetPassImg.setFitWidth(47);
		resetPassImg.setFitHeight(47);

		header.getStyleClass().add("login-Header");
		header.setGraphic(resetPassImg);
		header.setContentDisplay(ContentDisplay.LEFT);
		header.setGraphicTextGap(20);
		back.setContentDisplay(ContentDisplay.LEFT);
		back.setGraphic(arrow);
		password.setPromptText("New Password");
		rewritePassword.setPromptText("Rewrite Password");
		password.setPrefSize(230, 35);
		rewritePassword.setPrefSize(230, 35);
		password.getStyleClass().add("textField");
		rewritePassword.getStyleClass().add("textField");
		reset.getStyleClass().add("login");
		reset.setPrefSize(200, 20);

		GridPane inputs = new GridPane();
		inputs.setHgap(10);
		inputs.setVgap(20);
		inputs.add(password, 0, 0);
		inputs.add(lockImg, 1, 0);
		inputs.add(rewritePassword, 0, 1);
		inputs.add(rewriteImg, 1, 1);
		inputs.add(matchPass, 0, 2);
		inputs.setAlignment(Pos.CENTER);
		inputs.setPadding(new Insets(0, 0, 20, 0));

		VBox center = new VBox(50);
		center.setAlignment(Pos.TOP_CENTER);
		center.getChildren().addAll(header, inputs, reset);

		root.setTop(back);
		root.setAlignment(back, Pos.CENTER_LEFT);
		root.setCenter(center);
		root.setPadding(new Insets(15, 15, 20, 15));
		root.setStyle("-fx-background-color:white;");
		stage.show();
		return stage;
	}

	private void strongPassword() {
		Stage stage = new Stage();
		stage.setTitle("Security Alert");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("Alert-100.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(5);
		AIcon.setLayoutY(50);
		pane.getChildren().add(AIcon);

		Text alert = new Text(
				"The password you entered is weak, which increases the risk of unauthorized access to your account. ");
		// alert.getStyleClass().add("tit");
		alert.setWrappingWidth(370);
		alert.setFont(new Font("Arial", 18));
		alert.setLayoutX(70);
		alert.setLayoutY(60);
		pane.getChildren().add(alert);

		Text roles = new Text(
				"To create a strong password: \n\n  1. Use at least 8 characters. \n  2. Mix uppercase and lowercase letters, numbers,"
						+ "\n       and symbols. \n  3. Avoid patterns and common words like 12345.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(30);
		roles.setLayoutY(190);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(330);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	private void done() {

		System.out.println("DONE");
		Stage DoneStage = new Stage();

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		DoneStage.getIcons().add(icon);

		Pane pane = new Pane();
		pane.getStyleClass().add("whiteBG");

		Image backImg = new Image("done.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"Your Password was successfully updated!\n\nMake sure not to share your password with anyone to avoid loosing your account.");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 20));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(22));
		ok.setPrefSize(60, 20);
		// ok.getStyleClass().add("butt");
		ok.setLayoutX(215);
		ok.setLayoutY(210);

		ok.setOnAction(e -> {
			DoneStage.close();
//			signupStage.close();
			Main.firstPage.getStart().show();
		});

		Scene scene = new Scene(pane, 500, 270);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		DoneStage.setScene(scene);
		DoneStage.setResizable(false);
		DoneStage.show();
	}

	public PasswordField getPassword() {
		return password;
	}

	public PasswordField getRewritePassword() {
		return rewritePassword;
	}

	public Button getReset() {
		return reset;
	}

	public Label getBack() {
		return back;
	}

}
