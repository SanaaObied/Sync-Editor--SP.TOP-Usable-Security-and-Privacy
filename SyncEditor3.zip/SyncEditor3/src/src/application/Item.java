package src.application;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.CheckBox;
import javafx.scene.image.ImageView;

public class Item {
	private final ObjectProperty<ImageView> image;
    private final String label;
    private final CheckBox checkBox;

    public Item(ImageView image, String label, CheckBox checkBox) {
        this.image = new SimpleObjectProperty<>(image);
        this.label = label;
        this.checkBox = checkBox;
    }

    public ImageView getImage() {
        return image.get();
    }

    public ObjectProperty<ImageView> imageProperty() {
        return image;
    }

    public String getLabel() {
        return label;
    }

    public CheckBox getCheckBox() {
        return checkBox;
    }
}
