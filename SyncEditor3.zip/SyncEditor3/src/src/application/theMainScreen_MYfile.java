package src.application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class theMainScreen_MYfile {

//	HBox leftRight = new HBox();
//	public HBox gethbox() {
//		return leftRight;
//	}
//	
//	public Pane getPane() {
//		return leftPane;
//	}

	int id;
	String username;

	ImageView imag;

	public void updateImage(Image newImage) {

		imag.setImage(newImage);

	}

	public Stage getMainStage() {
		return MainStage;
	}

	Stage MainStage;

	public void mainScreen(String username, int id) {
		this.id = id;
		this.username = username;
		Pane leftPane = new Pane();

		MainStage = new Stage();
		MainStage.setTitle("Sync Editer");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		MainStage.getIcons().add(icon);

		// split a pane to left and right
		// the left one

		leftPane.setPrefWidth(250);
		leftPane.setStyle("-fx-background-color: #c9e9f6");

		Image im = Main.sett.getImageFromDatabase(id);
		// display user icon
		imag = new ImageView(im);
		imag.setFitWidth(140);
		imag.setFitHeight(140);
		imag.getStyleClass().add("img");

		if (im != null) {
			imag.setImage(im);
			// Add imageView to your JavaFX scene or layout
		} else {
			System.out.println("Failed to retrieve the image from the database.");
		}

		// Create a Circle object to use as a clipping shape
		Circle clip = new Circle(70, 70, 70);

		// Set the clipping shape to the image view
		imag.setClip(clip);

		leftPane.getChildren().add(imag);
		imag.setLayoutX(50);
		imag.setLayoutY(20);

		Circle active = new Circle(10, Color.GREEN);
		active.setLayoutX(170);
		active.setLayoutY(140);
		leftPane.getChildren().add(active);

		// label for user name
		Label Uname = new Label(username);
		Uname.getStyleClass().add("custom-root2");
		Uname.setPrefSize(250, 30);
		Uname.setLayoutY(165);
		leftPane.getChildren().add(Uname);
		Uname.setStyle("-fx-underline: true;");

		// My Files
		HBox files = new HBox(10);
		files.getStyleClass().add("hboxes");

		Image fil = new Image("File.png");
		ImageView fileIcon = new ImageView(fil);
		fileIcon.setFitWidth(30);
		fileIcon.setFitHeight(30);

		Button myFiles = new Button("My Files");
		myFiles.getStyleClass().add("custom-root3");

		files.getChildren().addAll(fileIcon, myFiles);

		// My Friends
		HBox friendsBox = new HBox(10);
		friendsBox.getStyleClass().add("hboxes");

		Image fri = new Image("Friends.png");
		ImageView friendIcon = new ImageView(fri);
		friendIcon.setFitWidth(30);
		friendIcon.setFitHeight(30);

		Button myfriend = new Button("Friends");
		myfriend.getStyleClass().add("custom-root3");

		friendsBox.getChildren().addAll(friendIcon, myfriend);

		// My Alerts
		HBox alerts = new HBox(10);
		alerts.getStyleClass().add("hboxes");

		Image alert = new Image("Alerts.png");
		ImageView alertsIcon = new ImageView(alert);
		alertsIcon.setFitWidth(30);
		alertsIcon.setFitHeight(30);

		Button myalerts = new Button("Alerts");
		myalerts.getStyleClass().add("custom-root3");

		alerts.getChildren().addAll(alertsIcon, myalerts);

		// Share with me
		HBox shares = new HBox(10);
		shares.getStyleClass().add("hboxes");

		Image share = new Image("ShareWithMe.png");
		ImageView sharesIcon = new ImageView(share);
		sharesIcon.setFitWidth(30);
		sharesIcon.setFitHeight(30);

		Button shareWithMee = new Button("Shared With Me");
		shareWithMee.getStyleClass().add("custom-root3");

		shares.getChildren().addAll(sharesIcon, shareWithMee);

		VBox boxes1 = new VBox(10);
		boxes1.setLayoutY(230);
		leftPane.getChildren().add(boxes1);
		boxes1.getChildren().addAll(files, friendsBox, alerts, shares);

		// Settings
		HBox settings = new HBox(10);
		settings.getStyleClass().add("hboxes");

		Image setting = new Image("Setting.png");
		ImageView settingIcon = new ImageView(setting);
		settingIcon.setFitWidth(30);
		settingIcon.setFitHeight(30);

		Button mysetting = new Button("Settings");
		mysetting.getStyleClass().add("custom-root3");

		settings.getChildren().addAll(settingIcon, mysetting);

		// Share with me
		HBox signOut = new HBox(10);
		signOut.getStyleClass().add("hboxes");

		Image out = new Image("SignOut.png");
		ImageView outIcon = new ImageView(out);
		outIcon.setFitWidth(30);
		outIcon.setFitHeight(30);

		Button logOut = new Button("Sign Out");
		logOut.getStyleClass().add("custom-root3");

		signOut.getChildren().addAll(outIcon, logOut);

		VBox boxes = new VBox(15);
		boxes.setLayoutY(670);
		leftPane.getChildren().add(boxes);
		boxes.getChildren().addAll(settings, signOut);
//____________________________________________________________________________________________________
//____________________________________________________________________________________________________
//____________________________________________________________________________________________________

		// the right one

		ScrollPane scrollPane = new ScrollPane();

		HBox leftRight = new HBox();

		Main.myFilesPage = new MyFilesPage();

		scrollPane.setContent(Main.myFilesPage.getStart());
		leftRight.getChildren().addAll(leftPane, scrollPane);

		myFiles.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				if (Main.isSaved) {
					scrollPane.setContent(Main.myFilesPage.getStart());
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
					Main.isSaved = false;
				} else {
					scrollPane.setContent(Main.myFilesPage.getStart());
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
				}
			}
		});

		Main.friends = new Friends();
		myfriend.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				if (Main.isSaved) {
					scrollPane.setContent(Main.friends);
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
					Main.isSaved = false;
				} else {
					scrollPane.setContent(Main.friends);
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
				}

			}
		});

		myalerts.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				// scrollPane.setContent(al.alert(24));
				if (Main.isSaved) {
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, Main.al.alert(id));
					Main.isSaved = false;
				} else {
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, Main.al.alert(id));
				}

			}
		});

		shareWithMee.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				if (Main.isSaved) {
					scrollPane.setContent(Main.shared.sharedWithMe(id));
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
					Main.isSaved = false;
				} else {
					scrollPane.setContent(Main.shared.sharedWithMe(id));
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, scrollPane);
				}

			}
		});

		mysetting.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				// scrollPane.setContent(sett.MYSettings());
				if (Main.isSaved) {
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, Main.sett.MYSettings(id));
					Main.isSaved = false;
				} else {
					leftRight.getChildren().clear();
					leftRight.getChildren().addAll(leftPane, Main.sett.MYSettings(id));
				}

			}
		});

		logOut.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				if (Main.isSaved) {
					Main.isSaved = false;
					MainStage.close();
				} else {
					MainStage.close();
				}

			}
		});

		leftRight.setStyle("-fx-background-color:white;");
		Scene scene = new Scene(leftRight);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		MainStage.setScene(scene);
		// stage.setResizable(false);
		System.out.println(scene.getWidth());
		MainStage.setMaximized(true);
		MainStage.show();

	}
}
