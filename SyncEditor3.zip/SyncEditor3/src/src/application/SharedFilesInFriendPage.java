package src.application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SharedFilesInFriendPage {
	public Stage getStart(String fileName, String fileShare) {
		Stage s = new Stage();

		Image image = new Image("ICON.png");

		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(270);
		imageView.setFitHeight(190);

		Image image2 = new Image("sharedFiles.png");

		ImageView photoImageView = new ImageView(image2);
		photoImageView.setFitWidth(100);
		photoImageView.setFitHeight(100);
		Label photoLabel = new Label(fileName + " shares the following files with you");
		photoLabel
				.setStyle("-fx-font-size: 20;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n");
		photoLabel.setAlignment(Pos.CENTER);
		// Create an HBox for photo and label
		HBox photoHBox = new HBox(20);
		photoHBox.getChildren().addAll(photoImageView, photoLabel);
		photoHBox.setAlignment(Pos.CENTER_LEFT);

		Image image1 = new Image("File.png");
		Image image22 = new Image("UnShareFile.png");

		// Create ImageView and Label for the first set
		ImageView imageView1 = new ImageView(image1);
		imageView1.setFitWidth(60); // Adjust width as needed
		imageView1.setFitHeight(60); // Adjust height as needed

		Label label1 = new Label(fileShare);
		label1.setStyle("-fx-font-size: 20;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");
		RadioButton radioButton1 = new RadioButton("Read/Write");
		radioButton1.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
		// Create ImageView and Label for the second set
		ImageView imageView2 = new ImageView(image22);
		imageView2.setFitWidth(60); // Adjust width as needed
		imageView2.setFitHeight(60); // Adjust height as needed

		RadioButton radioButton2 = new RadioButton("Read Only");
		radioButton2.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
		// Create HBox to hold the first set of components
		HBox hbox1 = new HBox(imageView1, label1, radioButton1, radioButton2, imageView2);
		hbox1.setAlignment(Pos.CENTER_LEFT);
		hbox1.setSpacing(60); // Adjust spacing as needed
		hbox1.setPadding(new Insets(10)); // Adjust padding as needed

		HBox hbox123 = createHBox123("Getting to space", true, false);

		Separator dashedLine3 = new Separator();
		dashedLine3.getStyleClass().add("dashed-line");

		VBox v = new VBox(hbox123, dashedLine3, hbox1);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setSpacing(10); // Adjust spacing as needed
		v.setPadding(new Insets(10)); // Adjust padding as needed
		v.setPadding(new Insets(20, 20, 20, 20)); // Adjust padding as needed

		// Create a ScrollPane and set the content to the VBox
		ScrollPane scrollPane = new ScrollPane(v);
		// scrollPane.setPadding(new Insets(10)); // Adjust padding as needed
		scrollPane.setPrefSize(10, 300);

		VBox vbox = new VBox(photoHBox, scrollPane);
		vbox.setSpacing(20); // Adjust spacing between HBoxes

		vbox.setAlignment(Pos.CENTER);
		vbox.setPadding(new Insets(25, 25, 25, 25)); // Adjust padding as needed

		s.setTitle("Shared Files");
		s.getIcons().add(new Image("ICON.png")); // Set application icon
		Scene scene = new Scene(vbox, 900, 500);
		vbox.setStyle("-fx-background-color:#c9e9f6;");

		s.setScene(scene);

		s.show();
		return s;
	}

	private HBox createHBox123(String labelText, boolean radioButton1Selected, boolean radioButton2Selected) {
		Image image21 = new Image("File.png");
		ImageView imageView12 = new ImageView(image21);
		imageView12.setFitWidth(60);
		imageView12.setFitHeight(60);
		ToggleGroup toggleGroup = new ToggleGroup();

		Image image222 = new Image("UnShareFile.png");
		ImageView imageView122 = new ImageView(image222);
		imageView122.setFitWidth(60);
		imageView122.setFitHeight(60);

		Label label14 = new Label(labelText);
		label14.setStyle("-fx-font-size: 20;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ "-fx-border-width:  3.5;");

		RadioButton radioButton12 = new RadioButton("Read/Write");
		radioButton12.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
		radioButton12.setSelected(radioButton1Selected);

		RadioButton radioButton22 = new RadioButton("Read Only");
		radioButton22.setStyle("-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-border-width:  3.5;");
		radioButton22.setSelected(radioButton2Selected);
		ImageView imageView22 = new ImageView(image222);
		imageView22.setFitWidth(60);
		imageView22.setFitHeight(60);
		radioButton12.setToggleGroup(toggleGroup);
		radioButton22.setToggleGroup(toggleGroup);

		HBox hbox123 = new HBox(imageView12, label14, radioButton12, radioButton22, imageView22);
		hbox123.setAlignment(Pos.CENTER_LEFT);
		hbox123.setSpacing(60);
		hbox123.setPadding(new Insets(10));
		return hbox123;
	}
}
