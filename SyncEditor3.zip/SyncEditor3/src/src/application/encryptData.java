package src.application;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Scanner;

public class encryptData {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insert the string: ");
        String plaintext = scanner.nextLine();

        System.out.print("Enter the password: ");
        String password = scanner.nextLine();

        String saltString = generateSalt();
        String encryptedString = null; // Store the encrypted string

        try {
            // Derive the AES key from the password using PBKDF2
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(saltString), 65536, 256);
            SecretKey secretKey = factory.generateSecret(spec);
            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), "AES");

            // Create the cipher object
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

            // Perform the encryption
            byte[] encryptedData = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

            // Encode the encrypted data as Base64 string
            encryptedString = Base64.getEncoder().encodeToString(encryptedData);

            System.out.println("Encrypted string: " + encryptedString);
            System.out.println("Salt: " + saltString);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        System.out.print("Enter the salt: ");
        saltString = scanner.nextLine();

        try {
            // Decode the salt from Base64
            byte[] salt = Base64.getDecoder().decode(saltString);

            // Derive the AES key from the password using PBKDF2
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
            SecretKey secretKey = factory.generateSecret(spec);
            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), "AES");

            // Create the cipher object
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

            // Decode the encrypted string from Base64
            byte[] encryptedDataDecoded = Base64.getDecoder().decode(encryptedString);

            // Perform the decryption
            byte[] decryptedData = cipher.doFinal(encryptedDataDecoded);

            // Convert the decrypted data to the original plaintext
            String originalString = new String(decryptedData, StandardCharsets.UTF_8);

            System.out.println("Original string: " + originalString);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        scanner.close();
    }

    private static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }
}