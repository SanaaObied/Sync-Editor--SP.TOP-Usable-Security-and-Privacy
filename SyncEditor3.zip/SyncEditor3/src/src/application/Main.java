package src.application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

	static boolean isSaved = false;

	static ResetPassword reset = new ResetPassword();
	static SignUPScreen signup = new SignUPScreen();
	static Alerts al = new Alerts();
	static SharedWithMe shared = new SharedWithMe();
	static Settings sett = new Settings();
	static Friends friends;
	static MyFilesPage myFilesPage;
	static theMainScreen_MYfile theMain = new theMainScreen_MYfile();
	static smallWarningStage warning = new smallWarningStage();
	static connection conne = new connection();
	static CheckPassword chickpass = new CheckPassword();
//	static TextEditorPane edit = new TextEditorPane();

	static OpeningPage firstPage = new OpeningPage();

	static Login login = new Login();

	@Override
	public void start(Stage primaryStage) {

		//firstPage.getStart().show();

//		Scene s = new Scene(login,550,550);
//		primaryStage.setScene(s);
//		primaryStage.show();

	theMain.mainScreen("hanadi", 1);
//		signup.signUp();
		// rf.removeFriends(new FriendAccount(6, "WoroodAssi", "wo@gmail.com") , new
		// Account(1, STYLESHEET_MODENA, STYLESHEET_CASPIAN));

//		System.out.println(chickpass.isStrongPassword("Worood1#"));

	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		launch(args);

//		connectionEx();

	}

}
