package src.application;

public class FriendsRequst {
	String Type;
	Account friends;
	public FriendsRequst(String type, Account friends) {
		super();
		Type = type;
		this.friends = friends;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public Account getFriends() {
		return friends;
	}
	public void setFriends(Account friends) {
		this.friends = friends;
	}
	@Override
	public String toString() {
		return "FriendsRequst [Type=" + Type + ", friends=" + friends + "]";
	}
	
}
