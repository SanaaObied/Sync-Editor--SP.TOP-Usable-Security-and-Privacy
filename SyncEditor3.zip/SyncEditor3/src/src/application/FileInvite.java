package src.application;

public class FileInvite {
	String TypeFile;
	Account users;

	public FileInvite(String typeFile, Account users) {
		super();
		TypeFile = typeFile;
		this.users = users;
	}

	public String getTypeFile() {
		return TypeFile;
	}

	public void setTypeFile(String typeFile) {
		TypeFile = typeFile;
	}

	public Account getUsers() {
		return users;
	}

	public void setUsers(Account users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "FileInvite [TypeFile=" + TypeFile + ", users=" + users + "]";
	}

}
