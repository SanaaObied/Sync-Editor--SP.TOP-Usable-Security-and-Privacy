package src.application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class KickingOutUser extends VBox {
	private Button cancel, kick;

	public KickingOutUser(String name) {

		ImageView kickImg = new ImageView(new Image("kickOut.png"));
		cancel = new Button("Cancel");
		kick = new Button("Kick");
		Label warning1 = new Label("Kicking this person removes all privileges they own");
		Label warning2 = new Label("to this file.");
		Label warning3 = new Label("Are you sure you want to kick out '" + name + "'?");

		warning1.setFont(Font.font("Times New Roman", 22));
		warning2.setFont(Font.font("Times New Roman", 22));
		warning3.setFont(Font.font("Times New Roman", 20));
		cancel.getStyleClass().add("plain-button");
		kick.getStyleClass().add("plain-button");
		kickImg.setFitHeight(80);
		kickImg.setFitWidth(80);

		// holds the warning lines on top
		VBox topWarningLine = new VBox(10);
		topWarningLine.getChildren().addAll(warning1, warning2);
		topWarningLine.setAlignment(Pos.CENTER_LEFT);

		// the picture and the top warning
		GridPane top = new GridPane();
		top.setHgap(15);
		top.add(kickImg, 0, 0);
		top.add(topWarningLine, 1, 0);

		// holds the buttons
		HBox buttons = new HBox(40);
		buttons.getChildren().addAll(cancel, kick);
		buttons.setPadding(new Insets(20, 0, 30, 0));
		buttons.setAlignment(Pos.CENTER_RIGHT);

		setSpacing(20);
		getChildren().addAll(top, warning3, buttons);
		setStyle("-fx-background-color:#EEFAFF;");
		setAlignment(Pos.CENTER_LEFT);
		setPadding(new Insets(50, 20, 10, 20));

	}

	public Button getCancel() {
		return cancel;
	}

	public Button getKick() {
		return kick;
	}

}
