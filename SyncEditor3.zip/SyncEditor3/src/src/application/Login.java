package src.application;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Login {
	private Label forgotPassword, creatAccount, back;
	protected TextField gmail;
	private PasswordField password;
	private Button login;
	private sql sqlConnection = new sql();
	private SignUPScreen signUp = new SignUPScreen();
	private User user = new User();
	private Account Accounts;
	private String email, phone, username, ID;

	public Stage getStart() {
		BorderPane root = new BorderPane();
		Stage stage = new Stage();
		Scene scene = new Scene(root, 500, 500);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);

		ImageView icon = new ImageView(new Image("ICON.png"));
		ImageView arrow = new ImageView(new Image("arrow.png"));
		ImageView emailPic = new ImageView(new Image("email.png"));
		ImageView lock = new ImageView(new Image("Lock.png"));
		Label header = new Label("Login");
		forgotPassword = new Label("Forgot Password?");
		creatAccount = new Label("Create One!");
		back = new Label();
		gmail = new TextField();
		password = new PasswordField();
		login = new Button("Continue");

		// Assuming xback is your Label
		arrow.setOnMouseClicked(e -> {

			stage.close();
			Main.firstPage.getStart().show();
		});

		login.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				try {

					Connection connection = sqlConnection.getConnection();
					System.out.println("Connected to the database!");

					email = gmail.getText();
					String passwords = password.getText();
					boolean loginSuccessful = validateLogin(connection, email, passwords);
					String usernameQuery = "SELECT userName FROM Accounts WHERE gmail = ?";
					PreparedStatement statement0 = connection.prepareStatement(usernameQuery);
					statement0.setString(1, email);
					ResultSet resultSet = statement0.executeQuery();

					String phoneQuery = "SELECT phone FROM Accounts WHERE gmail = ?";
					PreparedStatement statement2 = connection.prepareStatement(phoneQuery);
					statement2.setString(1, email);
					ResultSet resultSet2 = statement2.executeQuery();

					if (resultSet2.next()) {
						phone = resultSet2.getString("phone");
						System.out.println("PHONE: " + phone);
					}

					if (resultSet.next()) {
						username = resultSet.getString("userName");
						System.out.println("Username: " + username);
						if (loginSuccessful) {

							ID = getAccountIdFromDatabase(username) + "";
							stage.close();

							VerificationLogin ver = new VerificationLogin(email, phone, username, ID, 1);

							continueToMainPage(username, email, connection, resultSet);

						} else {
							gmail.setText(null);
							password.setText(null);
							InvalidInfo();
						}
					} else {
						gmail.setText(null);
						password.setText(null);
						NotexistedAccount();
					}

					connection.close();
					System.out.println("Disconnected from the database!");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		});
//forgetSCreen
		forgotPassword.setOnMouseClicked(e -> {
			if (!gmail.getText().isBlank() && emailExist(gmail.getText())) {

				stage.close();

				VerificationResetPassword ver = new VerificationResetPassword(gmail.getText().trim());

			} else {

				InvalidInfo();

			}
		});
		// creatAccountScreen
		creatAccount.setOnMouseClicked(e ->

		{
			stage.close();
			signUp.signUp();
		});
		back.setContentDisplay(ContentDisplay.LEFT);
		back.setGraphic(arrow);
		back.setOnMouseClicked(e -> {
			System.exit(0);
		});
		header.setGraphic(icon);
		header.setContentDisplay(ContentDisplay.TOP);
		header.getStyleClass().add("login-Header");
		Text t = new Text(" ");
		t.setFont(Font.font(10));

		icon.setFitWidth(90);
		icon.setFitHeight(90);
		arrow.setFitWidth(40);
		arrow.setFitHeight(40);
		emailPic.setFitWidth(30);
		emailPic.setFitHeight(30);
		lock.setFitWidth(30);
		lock.setFitHeight(30);

		setProperties();

		GridPane inputs = new GridPane();
		inputs.setHgap(10);
		inputs.setVgap(6);
		inputs.add(gmail, 0, 0);
		inputs.add(emailPic, 1, 0);
		inputs.add(t, 0, 1);
		inputs.add(password, 0, 2);
		inputs.add(lock, 1, 2);
		inputs.add(forgotPassword, 0, 3);
		inputs.setAlignment(Pos.CENTER);
		inputs.setPadding(new Insets(38, 0, 10, 0));
		VBox center = new VBox();
		center.getChildren().addAll(header, inputs);
		center.setAlignment(Pos.TOP_CENTER);

		Label askQuestion = new Label("Don't have an account?");
		HBox labels = new HBox(2);
		labels.setAlignment(Pos.CENTER);
		labels.getChildren().addAll(askQuestion, creatAccount);

		VBox bottom = new VBox();
		bottom.setAlignment(Pos.CENTER);
		bottom.getChildren().addAll(login, labels);

		root.setTop(arrow);
		root.setAlignment(arrow, Pos.CENTER_LEFT);
		root.setCenter(center);
		root.setAlignment(center, Pos.CENTER);
		root.setBottom(bottom);
		root.setAlignment(bottom, Pos.CENTER_LEFT);
		root.setPadding(new Insets(10, 10, 30, 20));
		root.setStyle("-fx-background-color:white;");
		return stage;

	}

	public void continueToMainPage(String username, String email, Connection connection, ResultSet resultSet) {

		System.out.println("Login successful!");

		//////////////////////////////////////////////////////////////////
		//////////////////// Account ID ////////////////////////////////////
		//////////////////////////////////////////////////////////////////

//		Main.theMain.mainScreen(username, 1);

		//////////////////////////////////////////////////////////////////
		//////////////////// Account ID ////////////////////////////////////
		//////////////////////////////////////////////////////////////////

		// Main.mainScreen(username);

		try {
			Statement statement = connection.createStatement();

			// Retrieve the account ID for the entered email
			String accountQuery = "SELECT accountsID FROM Accounts WHERE gmail = '" + email + "'";
			ResultSet accountResultSet = statement.executeQuery(accountQuery);

			// Check if the account exists
			if (accountResultSet.next()) {
				int accountID = accountResultSet.getInt("accountsID");

				// Retrieve records from Accounts table for the account ID
				String accountsQuery = "SELECT * FROM Accounts WHERE accountsID = " + accountID;
				ResultSet accountsResultSet = statement.executeQuery(accountsQuery);

				// Process the result set
				while (accountsResultSet.next()) {
					int accountsID = accountsResultSet.getInt("accountsID");
					String userName = accountsResultSet.getString("username");
					Date DOB = accountsResultSet.getDate("DateOfBirth");
					String Gmail = accountsResultSet.getString("gmail");
					String password = accountsResultSet.getString("pass");
					Blob blob = accountsResultSet.getBlob("image");
					// Convert the Blob object to an Image object
//					InputStream inputStream = blob.getBinaryStream();

					Accounts = new Account(accountsID, userName, DOB, Gmail, null, password);
//					Main.theMain = new theMainScreen_MYfile(userName, accountsID);

					Image imagView = getImageFromDatabase(accountsID);
					if (imagView != null) {
						Accounts.setImage(imagView);
						// Add imageView to your JavaFX scene or layout
					} else {
						System.out.println("Failed to retrieve the image from the database.");
					}

					User User = new User();
					User.getAvlUser().add(new User(accountsID, userName, DOB, Gmail, imagView, password));
					// Perform necessary actions with the retrieved data
					System.out.println("Account ID: " + accountsID);
					System.out.println("Username: " + userName);
					// Print other retrieved columns
					// ...
				}

				accountsResultSet.close();

				// Retrieve records from Files table for the account ID
				String filesQuery = "SELECT * FROM Files WHERE accountsID = " + accountID;
				ResultSet filesResultSet = statement.executeQuery(filesQuery);

				// Process the result set
				while (filesResultSet.next()) {
					int fileID = filesResultSet.getInt("fileID");
					String fileName = filesResultSet.getString("fileName");
					Blob text = filesResultSet.getBlob("texts");
					int accountIDs = filesResultSet.getInt("accountsID");
					User user = new User(accountIDs);
					Files files = new Files(fileID, fileName, user);
					Accounts.getAvlFile().add(files);
					user.getList().add(files);
					// Perform necessary actions with the retrieved data
					System.out.println("File ID: " + fileID);
					System.out.println("File Name: " + fileName);
					// Print other retrieved columns
					// ...
				}

				filesResultSet.close();

				// Retrieve records from Editors table for the account ID
				/*String editorsQuery = "SELECT * FROM Editors WHERE editor = " + accountID;
				ResultSet editorsResultSet = statement.executeQuery(editorsQuery);

				// Process the result set
				while (editorsResultSet.next()) {
					int editorsID = editorsResultSet.getInt("editorsID");
					boolean privilege = editorsResultSet.getBoolean("privilege");
					int editeID = filesResultSet.getInt("editorsID");
					int accountsID = accountsResultSet.getInt("editor");
					int fileID = filesResultSet.getInt("fileID");
					User user = new User(accountsID);
					Files files = new Files(fileID, user);
					user.getList().add(files);
					String permission;
					if (privilege == false) {
						permission = "Read Only";
					} else {
						permission = "Read/Write";
					}
					ShareWithMe ShareWithMe = new ShareWithMe(files, Accounts, permission);

					// Retrieve other columns as needed
					// ...

					// Perform necessary actions with the retrieved data
					System.out.println("Editors ID: " + editorsID);
					System.out.println("Privilege: " + privilege);

				}

				editorsResultSet.close();*/

				// Retrieve records from FriendsRequest table for the account ID
				String friendsRequestQuery = "SELECT * FROM FriendsRequst WHERE reciver = ?";
				PreparedStatement friendsRequestStatement = connection.prepareStatement(friendsRequestQuery);
				friendsRequestStatement.setInt(1, accountID);
				ResultSet friendsRequestResultSet = friendsRequestStatement.executeQuery();

				// Process the result set
				while (friendsRequestResultSet.next()) {
					int requestID = friendsRequestResultSet.getInt("requstsID");
					int sender = friendsRequestResultSet.getInt("sender");
					int receiver = friendsRequestResultSet.getInt("reciver");
					Accounts = new Account(sender);
					// FriendsRequst FriendsRequst=new FriendsRequst();

					// Perform necessary actions with the retrieved data
					System.out.println("Request ID: " + requestID);
					System.out.println("Sender: " + sender);
					System.out.println("Receiver: " + receiver);
					// Print other retrieved columns
					// ...
				}

				friendsRequestResultSet.close();
				friendsRequestStatement.close();

				// Retrieve records from shareFile table for the account ID
				String shareFileQuery = "SELECT * FROM shareFile WHERE recever = ?";
				PreparedStatement shareFileStatement = connection.prepareStatement(shareFileQuery);
				shareFileStatement.setInt(1, accountID);
				ResultSet shareFileResultSet = shareFileStatement.executeQuery();

				// Process the result set
				while (shareFileResultSet.next()) {
					int sender = shareFileResultSet.getInt("sender");
					int receiver = shareFileResultSet.getInt("recever");
					int fileID = shareFileResultSet.getInt("fileID");
					User user = new User(sender);
					Files FileInvite = new Files(fileID, user);

					// user.setInviteFile(fileID.);
					// Perform necessary actions with the retrieved data
					System.out.println("Sender: " + sender);
					System.out.println("Receiver: " + receiver);
					System.out.println("File ID: " + fileID);
					// Print other retrieved columns
					// ...
				}

				shareFileResultSet.close();
				shareFileStatement.close();
				// Create a list to store the friend IDs
				List<Integer> friendIds = new ArrayList<>();

				// Retrieve records from BeFriends table for the account ID
				String beFriendsQuery = "SELECT * FROM beFriends WHERE (firsts = ? OR seconds = ?) AND (firsts IN (SELECT accountsID FROM Accounts WHERE username = ?) OR seconds IN (SELECT accountsID FROM Accounts WHERE username = ?))";
				PreparedStatement statements = connection.prepareStatement(beFriendsQuery);
				statements.setInt(1, user.getAccountID());
				statements.setInt(2, user.getAccountID());
				statements.setString(3, user.getUserName());
				statements.setString(4, user.getUserName());
				ResultSet resultSets = statements.executeQuery();

				while (resultSet.next()) {
					int firsts = resultSets.getInt("firsts");
					int seconds = resultSets.getInt("seconds");

					// Retrieve additional data from the Accounts table based on the firsts and
					// seconds IDs
					String friendName = user.getUserNameById(firsts, connection); // Assuming you
																					// have a method
																					// to get the
																					// username by
																					// ID
					int friendId = user.getIdByName(friendName);

					// Add the friend ID to the list
					friendIds.add(friendId);

					PreparedStatement friendStatement = connection
							.prepareStatement("SELECT * FROM Accounts WHERE accountsID = ?");
					friendStatement.setInt(1, friendId);
					ResultSet friendResultSet = friendStatement.executeQuery();

					while (friendResultSet.next()) {
						// Retrieve the account data for the friend
						int accountId = friendResultSet.getInt("accountsID");
						String accountUsername = friendResultSet.getString("username");
						Date dateOfBirth = friendResultSet.getDate("DateOfBirth");
						String accountEmail = friendResultSet.getString("gmail");
						Blob blob = friendResultSet.getBlob("image");

						// Convert the Blob object to an Image object
						InputStream inputStream = blob.getBinaryStream();
						Image image = new Image(inputStream);
						String password = friendResultSet.getString("pass");

						System.out.println("Friend ID: " + accountId);
						System.out.println("Friend Username: " + accountUsername);
						// Print or process other relevant account data

						// Remove the friend from the AVL tree or any other data structure you're
						// using
						Account account = new Account();
						User friend = new User(accountId, accountUsername, dateOfBirth, accountEmail, image, password);
						account.getAvlUser().add(friend);
						friend.getFriendslist().add(friend);
					}

					friendResultSet.close();
					friendStatement.close();
				}

				resultSet.close();
				statement.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void setProperties() {

		password.getStyleClass().add("textField");
		gmail.getStyleClass().add("textField");

		gmail.setPromptText("Email");
		password.setPromptText("Password");
		gmail.setPrefSize(210, 35);
		password.setPrefSize(210, 35);
		forgotPassword.getStyleClass().add("forget");
		creatAccount.getStyleClass().add("forget");

		login.getStyleClass().add("login");
		login.setPrefSize(200, 40);

	}

	public Label getForgotPassword() {
		return forgotPassword;
	}

	public Label getCreatAccount() {
		return creatAccount;
	}

	public TextField getGmail() {
		return gmail;
	}

	public PasswordField getPassword() {
		return password;
	}

	public Button getLogin() {
		return login;
	}

	public Label getBack() {
		return back;
	}

	private boolean validateLogin(Connection connection, String email, String password) {
		String selectQuery = "SELECT * FROM Accounts WHERE gmail = ? AND pass = ?";
		try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {
			statement.setString(1, email);
			statement.setString(2, password);
			ResultSet resultSet = statement.executeQuery();
			return resultSet.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private boolean emailExist(String email) {

		Connection connection;
		try {
			connection = sqlConnection.getConnection();

			String selectQuery = "SELECT * FROM Accounts WHERE gmail = ?";
			try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {
				statement.setString(1, email);
				ResultSet resultSet = statement.executeQuery();
				return resultSet.next();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			connection.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;

	}

	public void NotexistedAccount() {
		Stage stage = new Stage();
		stage.setTitle("Account Not Found");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("notExist.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text("This account does not exist, create an account to log in.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public void InvalidInfo() {
		Stage stage = new Stage();
		stage.setTitle("Invalid login credentials!");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("error.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text("Please Check Your Password Or Your Email");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	private int getAccountIdFromDatabase(String name) {
		int accountId = -1; // Default value if the account ID is not found
		// Assuming you are using JDBC to interact with the database
		sql sql = new sql();
		try (Connection connection = sql.getConnection()) {
			// Prepare the SQL statement
			String sqlw = "SELECT accountsID FROM Accounts WHERE userName = ?";
			PreparedStatement statement = connection.prepareStatement(sqlw);

			// Set the parameter value
			statement.setString(1, name);

			// Execute the query
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				// Retrieve the account ID from the result set
				accountId = resultSet.getInt("accountsID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountId;
	}

	public Image getImageFromDatabase(int id) {
		try {
			Main.conne.connectDB();

			// SQL query to select the image data
			String sql = "SELECT image FROM Accounts WHERE accountsID = " + id + ";";

			try (Statement statement = Main.conne.connect().createStatement()) {
				// Execute the query
				ResultSet resultSet = statement.executeQuery(sql);

				if (resultSet.next()) {
					// Get the image data from the result set
					byte[] imageData = resultSet.getBytes("image");

					ByteArrayInputStream bis = null;
					// Convert the image data to a JavaFX Image
					if (imageData != null) {
						bis = new ByteArrayInputStream(imageData);

						return new Image(bis);
					}
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {

				if (Main.conne.connect() != null && !Main.conne.connect().isClosed()) {
					Main.conne.connect().close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

}
