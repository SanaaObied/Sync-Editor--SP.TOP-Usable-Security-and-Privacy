package src.application;

public class ShareWithMe {
	private Files FileName;
	private Account Admin;
	private String privilege;

	public ShareWithMe(Files fileName, Account admin, String privilege) {
		super();
		FileName = fileName;
		Admin = admin;
		this.privilege = privilege;
	}

	public Files getFileName() {
		return FileName;
	}

	public void setFileName(Files fileName) {
		FileName = fileName;
	}

	public Account getAdmin() {
		return Admin;
	}

	public void setAdmin(Account admin) {
		Admin = admin;
	}

	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}

	@Override
	public String toString() {
		return "ShareWithMe [FileName=" + FileName + ", Admin=" + Admin + ", privilege=" + privilege + "]";
	}

}
