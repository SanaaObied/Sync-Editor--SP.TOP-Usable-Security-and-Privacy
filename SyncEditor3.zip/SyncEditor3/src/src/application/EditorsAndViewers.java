package src.application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class EditorsAndViewers extends HBox {

	private Button arrowButton;
	private RadioMenuItem readOnly, readWrite;
	private ToggleGroup permissionToggle = new ToggleGroup();
	private Stage stage = new Stage();
	private KickingOutUser KickingOutUser;
	private HBox completeProfilePic;
	private sql sql = new sql();
	private Image img;
	private String name;
	private boolean status;
	private boolean isallowed;
	private boolean isAdmin;

	// takes in the user and the file they are editing in
	public EditorsAndViewers(Image img, String name, boolean status, boolean isallowed, boolean isAdmin) {

		ImageView decidedPicture = new ImageView(new Image("arrowDown.png"));
		decidedPicture.setFitHeight(20);
		decidedPicture.setFitWidth(20);

		if (isAdmin) {
			decidedPicture = new ImageView(new Image("admin.png"));

			decidedPicture.setFitHeight(30);
			decidedPicture.setFitWidth(30);
		}

		arrowButton = new Button("", decidedPicture);
		Circle profileCircle = new Circle(20);
		Circle statusCircle = new Circle(6);
		ContextMenu menu = getMenu(isallowed, name);// change the inputs depending on what the user and file objects say

		// setting properties
		profileCircle.setFill(new ImagePattern(img));
		arrowButton.setStyle("-fx-background-color:transparent;");
		profileCircle.setStroke(Color.BLACK);
		profileCircle.setStrokeWidth(3);
		statusCircle.setStroke(Color.BLACK);
		statusCircle.setStrokeWidth(2);

		// Change color based on online status
		if (status)
			statusCircle.setFill(Color.GREEN);
		else
			statusCircle.setFill(Color.RED);

		// Create a Horizontal pane box to hold the circles and name
		this.completeProfilePic = new HBox(-20);
		completeProfilePic.getChildren().addAll(profileCircle, statusCircle);
		completeProfilePic.setAlignment(Pos.BOTTOM_CENTER);

		if (!isAdmin)
			/// action of opening the context menu for the user (DONT CHANGE)
			arrowButton.setOnAction(e -> {
				double screenX = arrowButton.localToScreen(0, 0).getX() + arrowButton.getWidth() / 2;
				double screenY = arrowButton.localToScreen(0, 0).getY() + arrowButton.getHeight() / 2;
				menu.show(arrowButton, screenX, screenY);
			});

		else

			arrowButton.setOnAction(e -> {
				double screenX = arrowButton.localToScreen(0, 0).getX() + arrowButton.getWidth() / 2;
				double screenY = arrowButton.localToScreen(0, 0).getY() + arrowButton.getHeight() / 2;
				getSimpleMenu(name).show(arrowButton, screenX, screenY);
			});

		setAlignment(Pos.BOTTOM_CENTER);
		getChildren().addAll(completeProfilePic, arrowButton);

	}

	// given the permission and name to add to the menu
	private ContextMenu getMenu(boolean permission, String name) {

		ContextMenu menu = new ContextMenu();
		readOnly = new RadioMenuItem("Read Only");
		readWrite = new RadioMenuItem("Read/Write");
		Label namelbl = new Label(name);
		Label kicklbl = new Label("Kick Out");
		MenuItem theName = new MenuItem();
		MenuItem kickItem = new MenuItem();

		theName.setGraphic(namelbl);
		theName.setDisable(true);
		kickItem.setGraphic(kicklbl);
		menu.getStyleClass().add("custom-menu-item");
		readOnly.setToggleGroup(permissionToggle);
		readWrite.setToggleGroup(permissionToggle);

		// true means read and write, false means read only
		readWrite.setSelected(permission);
		readOnly.setSelected(!permission);

		menu.getItems().addAll(theName, new SeparatorMenuItem(), readWrite, readOnly, new SeparatorMenuItem(),
				kickItem);

		readOnly.setOnAction(e -> {
			System.out.println("read only is " + readOnly.isSelected());
			System.out.println("read and write is " + readWrite.isSelected());

			// Get the account ID for the selected user from the Accounts table
			int accountId = getAccountIdFromDatabase(name);

			// Update the permission in the ShareFile table
			updatePermissionInDatabase(accountId, false); // false means read-only

			// Perform any additional actions or UI updates as needed
		});

		readWrite.setOnAction(e -> {
			System.out.println("read only is " + readOnly.isSelected());
			System.out.println("read and write is " + readWrite.isSelected());

			// Get the account ID for the selected user from the Accounts table
			int accountId = getAccountIdFromDatabase(name);

			// Update the permission in the ShareFile table
			updatePermissionInDatabase(accountId, true); // true means read and write

			// Perform any additional actions or UI updates as needed
		});

		kickItem.setOnAction(e -> {
			Scene scene = new Scene(KickingOutUser = new KickingOutUser(name)); // Get the existing scene
			System.out.println("Why are you kicking " + name + " out? :(");
			scene.getRoot().getStyleClass().add("application"); // Add the CSS style class if needed
			stage.setScene(scene);
			System.out.println(scene.getWidth());
			// removeProfilePic();
			stage.show();
		});
		return menu;

	}

	public void removeProfilePic() {
		// Remove the profile picture HBox from its parent
		if (completeProfilePic.getParent() instanceof HBox) {
			HBox parentPane = (HBox) completeProfilePic.getParent();
			parentPane.getChildren().remove(completeProfilePic);
		}
	}

	public HBox getCompleteProfilePic() {
		return completeProfilePic;
	}

	public void setCompleteProfilePic(HBox completeProfilePic) {
		this.completeProfilePic = completeProfilePic;
	}

	private ContextMenu getSimpleMenu(String name) {
		ContextMenu menu = new ContextMenu();

		Label namelbl = new Label(name);
		MenuItem theName = new MenuItem();

		theName.setGraphic(namelbl);
		theName.setDisable(true);
		menu.getStyleClass().add("custom-menu-item");

		menu.getItems().add(theName);

		return menu;

	}

	private void updatePermissionInDatabase(int accountId, boolean permission) {
		try (Connection connection = sql.getConnection()) {
			// Check existing entry in Editors table
			boolean existingEntry = checkExistingEntry(connection, accountId);

			if (existingEntry) {
				// Existing entry found, perform the update
				String updateSql = "UPDATE Editors SET privilege = " + permission + " WHERE editor = " + accountId;
				System.out.println("SQL Query: " + updateSql);
				System.out.println("Account ID: " + accountId);

				try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
					updateStatement.setBoolean(1, permission);
					updateStatement.setInt(2, accountId);

					int rowsAffected = updateStatement.executeUpdate();
					System.out.println("Rows affected: " + rowsAffected);

					if (rowsAffected > 0) {
						System.out.println("Permission updated successfully.");
					} else {
						System.out.println("Failed to update permission. No rows affected.");
					}
				}
			} else {
				// No existing entry, insert a new entry
				String insertSql = "INSERT INTO Editors (privilege, fileID, editor) VALUES (?, ?, ?)";
				System.out.println("SQL Query: " + insertSql);
				System.out.println("Account ID: " + accountId);

				try (PreparedStatement insertStatement = connection.prepareStatement(insertSql)) {
					insertStatement.setBoolean(1, permission);
					// You may need to set appropriate values for fileID and editor
					insertStatement.setInt(2, 1); // Example value, replace with your logic
					insertStatement.setInt(3, accountId);

					int rowsAffected = insertStatement.executeUpdate();
					System.out.println("Rows affected: " + rowsAffected);

					if (rowsAffected > 0) {
						System.out.println("New entry added successfully.");
					} else {
						System.out.println("Failed to add new entry. No rows affected.");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQLException: " + e.getMessage());
		}
	}

	private boolean checkExistingEntry(Connection connection, int accountId) throws SQLException {
		String checkSql = "SELECT * FROM Editors WHERE editor = ?";
		try (PreparedStatement checkStatement = connection.prepareStatement(checkSql)) {
			checkStatement.setInt(1, accountId);
			ResultSet resultSet = checkStatement.executeQuery();

			if (resultSet.next()) {
				System.out.println("Existing entry in Editors table:");
				System.out.println("EditorsID: " + resultSet.getInt("editorsID"));
				System.out.println("Privilege: " + resultSet.getBoolean("privilege"));
				System.out.println("FileID: " + resultSet.getInt("fileID"));
				System.out.println("Editor: " + resultSet.getInt("editor"));
				return true; // Entry exists
			} else {
				System.out.println("No existing entry in Editors table for Account ID: " + accountId);
				return false; // Entry doesn't exist
			}
		}
	}

	private int getAccountIdFromDatabase(String name) {
		int accountId = -1; // Default value if the account ID is not found
		// Assuming you are using JDBC to interact with the database
		try (Connection connection = sql.getConnection()) {
			// Prepare the SQL statement
			String sql = "SELECT accountsID FROM Accounts WHERE userName = ?";
			PreparedStatement statement = connection.prepareStatement(sql);

			// Set the parameter value
			statement.setString(1, name);

			// Execute the query
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				// Retrieve the account ID from the result set
				accountId = resultSet.getInt("accountsID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountId;
	}

	public Image getImg() {
		return img;
	}

	public void setImg(Image img) {
		this.img = img;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public boolean isIsallowed() {
		return isallowed;
	}

	public void setIsallowed(boolean isallowed) {
		this.isallowed = isallowed;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

}
