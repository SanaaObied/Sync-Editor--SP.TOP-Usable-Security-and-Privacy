package src.application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.util.converter.LocalDateStringConverter;

public class SignUPScreen {

	boolean isName = false; // to chick if the account name is exist
	boolean isEmail = false; // to chick if the email is exist

	Date ddd = null;

	Stage signupStage;

	public void signUp() {
		signupStage = new Stage();

		signupStage.setTitle("Sync Editer");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("Icon.png");
		signupStage.getIcons().add(icon);

		Pane pane = new Pane();
		pane.getStyleClass().add("whiteBG");

		ImageView iconImag = new ImageView(icon);
		iconImag.setFitWidth(70);
		iconImag.setFitHeight(70);

		Label l = new Label();
		l.setLayoutX(240);
		l.setLayoutY(40);
		// l.getStyleClass().add("icon");
		l.setGraphic(iconImag);
		pane.getChildren().add(l);

		Image backImg = new Image("arrow.png");

		ImageView backIcon = new ImageView(backImg);
		backIcon.setFitWidth(30);
		backIcon.setFitHeight(30);

		// back to first page
		Button back = new Button();
		back.getStyleClass().add("whiteBG");
		back.setLayoutX(10);
		back.setLayoutY(35);
		back.setGraphic(backIcon);
		pane.getChildren().add(back);

		back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				signupStage.close();
				Main.firstPage.getStart().show();
			}
		});

		Text title = new Text("Sign Up");
		title.getStyleClass().add("tit");
		pane.getChildren().add(title);
		title.setLayoutX(225);
		title.setLayoutY(145);

		VBox Velements = new VBox(30);
		Velements.setLayoutX(150);
		Velements.setLayoutY(205);
		pane.getChildren().add(Velements);

		// user name
		Image userImg = new Image("user2.png");

		ImageView userIcon = new ImageView(userImg);
		userIcon.setFitWidth(30);
		userIcon.setFitHeight(30);

		TextField userNAme = new TextField();
		userNAme.getStyleClass().add("textField");
		userNAme.setPrefWidth(230);
		userNAme.setPrefHeight(30);
		userNAme.setPromptText("User Name");

		HBox name = new HBox(10);
		name.getChildren().addAll(userNAme, userIcon);
		Velements.getChildren().add(name);

//		// date of birth
//		Image dateImg = new Image("Date.png");
//
//		ImageView dateIcon = new ImageView(dateImg);
//		dateIcon.setFitWidth(30);
//		dateIcon.setFitHeight(35);

//		// Create a DatePicker control
//		DatePicker datePicker = new DatePicker();
//
//		// Create a custom date format
//		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//
//		// Create a StringConverter to convert between LocalDate and String using the
//		// date format
//		StringConverter<LocalDate> stringConverter = new LocalDateStringConverter(dateFormatter, null);
//
//		// Set the StringConverter on the DatePicker
//		datePicker.setConverter(stringConverter);
//
//		// Set an initial date value
//		datePicker.setPromptText("Date Of Birth");
//		datePicker.setPrefWidth(230);
//		datePicker.setPrefHeight(35);
//		datePicker.getStyleClass().add("textField");
//
//		HBox date = new HBox(10);
//		date.getChildren().addAll(datePicker, dateIcon);
//		Velements.getChildren().add(date);

		// gmail
		Image gmailImg = new Image("email.png");

		ImageView gmailIcon = new ImageView(gmailImg);
		gmailIcon.setFitWidth(30);
		gmailIcon.setFitHeight(30);

		TextField gmailNAme = new TextField();
		gmailNAme.getStyleClass().add("textField");
		gmailNAme.setPrefWidth(230);
		gmailNAme.setPrefHeight(30);
		gmailNAme.setPromptText("username@gmail.com");

		HBox gmail = new HBox(10);
		gmail.getChildren().addAll(gmailNAme, gmailIcon);
		Velements.getChildren().add(gmail);

		// phone number
		Image phoneImg = new Image("telephone.png");

		ImageView phoneIcon = new ImageView(phoneImg);
		phoneIcon.setFitWidth(30);
		phoneIcon.setFitHeight(30);

		TextField phoneNAme = new TextField();
		phoneNAme.getStyleClass().add("textField");
		phoneNAme.setPrefWidth(230);
		phoneNAme.setPrefHeight(30);
		phoneNAme.setPromptText("05-********");

		HBox phone = new HBox(10);
		phone.getChildren().addAll(phoneNAme, phoneIcon);
		Velements.getChildren().add(phone);

//		// password
		Image passwordImg = new Image("Lock.png");

		ImageView passwordIcon = new ImageView(passwordImg);
		passwordIcon.setFitWidth(30);
		passwordIcon.setFitHeight(30);

		PasswordField passwordNAme = new PasswordField();
		passwordNAme.getStyleClass().add("textField");
		passwordNAme.setPrefWidth(230);
		passwordNAme.setPrefHeight(30);
		passwordNAme.setPromptText("Password");

		HBox password = new HBox(10);
		password.getChildren().addAll(passwordNAme, passwordIcon);
		Velements.getChildren().add(password);

		// password
		Image passwordImg2 = new Image("rewritePassword.png");

		ImageView passwordIcon2 = new ImageView(passwordImg2);
		passwordIcon2.setFitWidth(30);
		passwordIcon2.setFitHeight(30);

		PasswordField passwordNAme2 = new PasswordField();
		passwordNAme2.getStyleClass().add("textField");
		passwordNAme2.setPrefWidth(230);
		passwordNAme2.setPrefHeight(30);
		passwordNAme2.setPromptText("Rewrite Password");

		HBox password2 = new HBox(10);
		password2.getChildren().addAll(passwordNAme2, passwordIcon2);
		Velements.getChildren().add(password2);

		// Add an EventHandler to the textProperty
//		passwordNAme2.textProperty().addListener((observable, oldValue, newValue) -> {
//            // Print or display the password while typing
//            System.out.println("Current Password: " + newValue);
//        });

		Text matchPass = new Text("");
		matchPass.setFill(Color.RED);
		Velements.getChildren().add(matchPass);

		Button addAccount = new Button("Continue");
		pane.getChildren().add(addAccount);
		addAccount.setFont(new Font(20));
		addAccount.setPrefSize(150, 20);
		addAccount.getStyleClass().add("butt");
		addAccount.setLayoutX(190);
		addAccount.setLayoutY(550);

		Text goToLogin = new Text("Already have an account? ");
		pane.getChildren().add(goToLogin);
		goToLogin.setLayoutX(190);
		goToLogin.setLayoutY(610);

		Text login = new Text("Log in. ");
		login.getStyleClass().add("logI");
		login.setStyle("-fx-underline: true;");
		login.setFill(Color.LIGHTSTEELBLUE);
		pane.getChildren().add(login);
		login.setLayoutX(330);
		login.setLayoutY(610);

		login.setOnMouseClicked(e -> {
			signupStage.close();
			Main.login.getStart().show();
		});

//		datePicker.setOnAction(event -> {
//			LocalDate selectedDate = datePicker.getValue();
//			ddd = convertToDate(selectedDate);
//			System.out.println(ddd);
//
//		});

		// Add an EventHandler to the textProperty
		passwordNAme.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (passwordNAme.getText().trim().isEmpty()) {
				passwordNAme.getStyleClass().clear();
				passwordNAme.getStyleClass().add("textField");
			} else if (!Main.chickpass.isStrongPassword(newValue)) {
				System.out.println("Current Password: " + newValue);
				passwordNAme.getStyleClass().clear();
				passwordNAme.getStyleClass().add("errorTextF2");

			} else {
				passwordNAme.getStyleClass().clear();
				passwordNAme.getStyleClass().add("greenTextF");
				matchPass.setText("Strong Password");
				matchPass.setFill(Color.GREEN);

			}
		});

		// Add an EventHandler to the textProperty
		passwordNAme2.textProperty().addListener((observable, oldValue, newValue) -> {
			// Print or display the password while typing
			if (passwordNAme2.getText().trim().isEmpty()) {
				matchPass.setText(" ");
				passwordNAme2.getStyleClass().clear();
				passwordNAme2.getStyleClass().add("textField");
			} else if (!passwordNAme.getText().equals(passwordNAme2.getText())) {
				System.out.println("Current Password: " + newValue);
				passwordNAme2.getStyleClass().clear();
				passwordNAme2.getStyleClass().add("errorTextF2");
				matchPass.setText("Password not matching");
				matchPass.setFill(Color.RED);

			} else {
				matchPass.setText(" ");
				passwordNAme2.getStyleClass().clear();
				passwordNAme2.getStyleClass().add("greenTextF");

			}
		});

		addAccount.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				// if all the text-fields are full
				if (!userNAme.getText().trim().isEmpty()
//						&& datePicker.getValue() != null
						&& !gmailNAme.getText().isEmpty() && gmailNAme.getText().contains("@")
						&& !phoneNAme.getText().isEmpty() && phoneNAme.getText().trim().matches("\\d+")
						&& Integer.parseInt(phoneNAme.getText().trim().charAt(0) + "") == 0
						&& Integer.parseInt(phoneNAme.getText().trim().charAt(1) + "") == 5
						&& phoneNAme.getText().trim().length() == 10 && !phoneNAme.getText().trim().isEmpty()
						&& !passwordNAme.getText().isEmpty() && !passwordNAme2.getText().isEmpty()) {

					// chick if the name is exist or not:

//					try {
//						Main.conne.connectDB();
//
//						Main.conne.ExecuteStatement(
//								"select * from Accounts where userName = '" + userNAme.getText().trim() + "';");
//
//						// Create a statement object to execute the query
//						Statement statement = Main.conne.getCon().createStatement();
//
//						// Execute the query and get the result set
//						ResultSet result = statement.executeQuery(
//								"select * from Accounts where userName = '" + userNAme.getText().trim() + "';");
//
//						if (result.next()) {
//							existedAccountName();
//							System.out.println("error the account is exist");
//							isName = true;
//						} else
//							isName = false;
//
//						result.close();
//						statement.close();
//						Main.conne.getCon().close();
//
//					} catch (ClassNotFoundException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (SQLException e) {
//						// Handle other SQLExceptions, if necessary
//						System.err.println("SQL error occurred: " + e.getMessage());
//					}
//
//					// chick if the email is exist or not:
//					try {
//						Main.conne.connectDB();
//
//						Main.conne.ExecuteStatement(
//								"select * from Accounts where gmail = '" + gmailNAme.getText().trim() + "';");
//
//						// Create a statement object to execute the query
//						Statement statement = Main.conne.getCon().createStatement();
//
//						// Execute the query and get the result set
//						ResultSet result = statement.executeQuery(
//								"select * from Accounts where gmail = '" + gmailNAme.getText().trim() + "';");
//
//						if (result.next()) {
//							existedAccountEmail();
//							System.out.println("error the email is exist");
//							isEmail = true;
//						} else
//							isEmail = false;
//
//						result.close();
//						statement.close();
//						Main.conne.getCon().close();
//
//					} catch (ClassNotFoundException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (SQLException e) {
//						// Handle other SQLExceptions, if necessary
//						System.err.println("SQL error occurred: " + e.getMessage());
//					}

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

					try { // Assuming cc is an object with a method
//					testCon() that returns a Connection
						Main.conne.connectDB();

						Connection con = Main.conne.connect();

						Statement statement = con.createStatement();
						ResultSet resultSet = statement.executeQuery(
								"select * from Accounts where userName = '" + userNAme.getText().trim() + "';");

						if (resultSet.next()) {
							existedAccountName();
							System.out.println("error the account is exist");
							isName = true;
						} else
							isName = false;

						con.close();
					} catch (SQLException e) { // Handle SQLException
						e.printStackTrace();
					} catch (ClassNotFoundException e) { // Handle
//					ClassNotFoundException 
						e.printStackTrace();
					}

					/////////////////////////////////////////////////////////////////////////
					/////////////////////////////////////////////////////////////////////////
					/////////////////////////////////////////////////////////////////////////

					try { // Assuming cc is an object with a method
						Main.conne.connectDB();

						Connection con = Main.conne.connect();

						Statement statement = con.createStatement();
						ResultSet resultSet = statement.executeQuery(
								"select * from Accounts where gmail = '" + gmailNAme.getText().trim() + "';");

						if (resultSet.next()) {
							existedAccountName();
							System.out.println("error the account is exist");
							isEmail = true;
						} else
							isEmail = false;

						con.close();
					} catch (SQLException e) { // Handle SQLException
						e.printStackTrace();
					} catch (ClassNotFoundException e) { // Handle
						e.printStackTrace();
					}
//					

					// chick if the the first password == the second one:
					if (passwordNAme.getText().equals(passwordNAme2.getText())) {
						matchPass.setText("");
						// chick if the password is strong

						if (Main.chickpass.isStrongPassword(passwordNAme.getText())) {

//							String s = new SimpleDateFormat("yyyy-MM-dd").format(ddd);

							VerificationSignUp verify = new VerificationSignUp(userNAme.getText().trim(),
//									s,
									gmailNAme.getText().trim(), passwordNAme.getText(), phoneNAme.getText());

							// create the account
							// 1-verify by email
							// 2-insert new account

							userNAme.clear();
//							datePicker.setValue(null);
							gmailNAme.clear();
							passwordNAme.clear();
							passwordNAme2.clear();
							phoneNAme.clear();
						} else {
							strongPassword();
						}

					}

				} else {
					Main.warning.WarningMessage("", "Please enter your values to all sections!!!");
				}

			}
		});

		Scene scene = new Scene(pane, 550, 700);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		signupStage.setScene(scene);
		// stage.setResizable(false);
		signupStage.show();

	}

	public void strongPassword() {
		Stage stage = new Stage();
		stage.setTitle("Security Alert");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("Alert-100.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(5);
		AIcon.setLayoutY(50);
		pane.getChildren().add(AIcon);

		Text alert = new Text(
				"The password you entered is weak, which increases the risk of unauthorized access to your account. ");
		// alert.getStyleClass().add("tit");
		alert.setWrappingWidth(370);
		alert.setFont(new Font("Arial", 18));
		alert.setLayoutX(70);
		alert.setLayoutY(60);
		pane.getChildren().add(alert);

		Text roles = new Text(
				"To create a strong password: \n\n  1. Use at least 8 characters. \n  2. Mix uppercase and lowercase letters, numbers,"
						+ "\n       and symbols. \n  3. Avoid patterns and common words like 12345.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(30);
		roles.setLayoutY(190);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(330);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public void existedAccountEmail() {
		Stage stage = new Stage();
		stage.setTitle("Account Already Exists");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("error.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"This email is already in use. Please use a different email or sign in with the existing account.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public void existedAccountName() {
		Stage stage = new Stage();
		stage.setTitle("Account Already Exists");

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		stage.getIcons().add(icon);

		Pane pane = new Pane();

		Image backImg = new Image("error.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"This account name is already in use. Please use a different name or sign in with the existing account.");
		// alert.getStyleClass().add("tit");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 15));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(20));
		ok.setPrefSize(70, 20);
		ok.getStyleClass().add("butt");
		ok.setLayoutX(185);
		ok.setLayoutY(130);

		ok.setOnAction(e -> {
			stage.close();
		});

		Scene scene = new Scene(pane, 450, 200);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public Date convertToDate(LocalDate localDate) {
		ZoneId defaultZoneId = ZoneId.systemDefault();
		return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
	}

	public void done() {

		System.out.println("DONE");
		Stage DoneStage = new Stage();

		// stage.initStyle(StageStyle.DECORATED);
		Image icon = new Image("ICON.png");
		DoneStage.getIcons().add(icon);

		Pane pane = new Pane();
		pane.getStyleClass().add("whiteBG");

		Image backImg = new Image("done.png");

		ImageView AIcon = new ImageView(backImg);
		AIcon.setFitWidth(55);
		AIcon.setFitHeight(55);
		AIcon.setLayoutX(20);
		AIcon.setLayoutY(40);
		pane.getChildren().add(AIcon);

		Text roles = new Text(
				"Your account has been successfully created!\n\nYou can specify security methods to access your account through the login settings.");
		roles.setWrappingWidth(370);
		roles.setFont(new Font("Arial", 20));
		roles.setLayoutX(90);
		roles.setLayoutY(70);
		pane.getChildren().add(roles);

		Button ok = new Button("OK");
		pane.getChildren().add(ok);
		ok.setFont(new Font(22));
		ok.setPrefSize(60, 20);
		// ok.getStyleClass().add("butt");
		ok.setLayoutX(215);
		ok.setLayoutY(210);

		ok.setOnAction(e -> {
			DoneStage.close();
			signupStage.close();
			Main.firstPage.getStart().show();
		});

		Scene scene = new Scene(pane, 500, 270);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		DoneStage.setScene(scene);
		DoneStage.setResizable(false);
		DoneStage.show();
	}
}
