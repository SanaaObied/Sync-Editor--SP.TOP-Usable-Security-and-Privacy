package src.application;

import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Friends extends VBox {
	private TextField search;
	private Button searchButton;
	private Label addNewFriend;
	static int k = 0;
	private AddNewFriendPage AddNewFriendPage;
//	private Stage stage = new Stage();
	private GridPane theFriends; // Declare theFriends as a class member
	private static ArrayList<User> friends = new ArrayList<User>();// get the list of friends from constructor
	private Account Account = new Account();
	private sql sql = new sql();
	private int accountId;
	private Login Login = new Login();
	private HBox searching;

	public Friends() {
		// theFriends = new GridPane(); // Initialize theFriends
		// retrieveAndCreateInterfaces();
		ImageView friendLogo = new ImageView(new Image("FriendsDark.png"));
		ImageView addNewFriendImg = new ImageView(new Image("AddNew.png"));
		ImageView searchImg = new ImageView(new Image("Search.png"));
		Label header = new Label("Friends");
		search = new TextField();
		searchButton = new Button("", searchImg);
		addNewFriend = new Label("Add a New Friend");
		addNewFriend.setOnMouseClicked(e -> {
			Stage stage = new Stage();
			Scene scene = new Scene(AddNewFriendPage = new AddNewFriendPage());
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setScene(scene);
			System.out.println(scene.getWidth());
			// stage.setMaximized(true);
			stage.show();
		});

		// setting properties
		addNewFriend.setGraphic(addNewFriendImg);
		addNewFriend.setContentDisplay(ContentDisplay.TOP);
		addNewFriend.setGraphicTextGap(25);
		addNewFriend.setFont(Font.font(20));
		addNewFriend.setPadding(new Insets(0, 0, 0, 20));

		searchButton.setStyle("-fx-background-color:white; -fx-border-color:black;");
		searchButton.setPrefSize(45, 45);

		search.setFont(Font.font("Times New Roman", FontWeight.BOLD, 17));
		search.setStyle("-fx-border-color:black;");
		search.setPromptText("Search Friends");
		search.setPrefSize(255, 45);

		header.setGraphic(friendLogo);
		header.setContentDisplay(ContentDisplay.LEFT);
		header.setGraphicTextGap(20);
		header.getStyleClass().add("login-Header");

		friendLogo.setFitHeight(50);
		friendLogo.setFitWidth(50);

		addNewFriendImg.setFitWidth(120);
		addNewFriendImg.setFitHeight(120);

		searchImg.setFitWidth(25);
		searchImg.setFitHeight(25);

		// to hold the search gear
		searching = new HBox(3);
		searching.getChildren().addAll(search, searchButton);
		searching.setAlignment(Pos.CENTER_LEFT);

		searchButton.setOnAction(event -> {
			String searchText = search.getText();
			searchFriends(searchText);

		});

		// holds the title, searching parts, and add new friend
		GridPane topPart = new GridPane();
		topPart.setHgap(700);
		topPart.setVgap(80);
		topPart.add(header, 0, 0);
		topPart.add(searching, 1, 0);
		topPart.add(addNewFriend, 0, 1);
		topPart.setAlignment(Pos.CENTER_LEFT);
		topPart.setPadding(new Insets(0, 0, 20, 0));

		Line horizontalLine = new Line(0, 0, 1180, 0);
		horizontalLine.setStrokeWidth(2);

		theFriends = new GridPane();
		theFriends.setAlignment(Pos.CENTER);
		theFriends.setPadding(new Insets(35, 20, 20, 0));
		theFriends.setHgap(100);
		theFriends.setVgap(100);

		//////////////////////////////////
		// here is where you change it to be more dynamic
		//////////////////////////////////
		// Fill the grid with the users in friends list using nested loops

//		friends.add(new User(1, "Joe Alli", new Date(7 - 10), "passwo", new Image("User1.png"), "joealii23@gmail.com"));
//		friends.add(
//				new User(2, "Baheyabh", new Date(23 - 9), "passwo23", new Image("User.png"), "Baheyabh65t@gmail.com"));
//		friends.add(new User(3, "Margo", new Date(5 - 7), "passwo31113", new Image("User.png"), "Margo35@gmail.com"));
//		friends.add(
//				new User(4, "Waeal Nu", new Date(5 - 9), "passwo3111", new Image("User1.png"), "WaealNu627@gmail.com"));
		// Retrieve data from the database

		getMatchingUsers(Main.theMain.id);

		// Fill the grid with the users retrieved from the database
		for (User user : friends) {
			Image image = user.getImage();
			String name = user.getUserName();
			boolean online = user.isOnline();

			System.out.println(name);

			addFriend(image, name, online, currentColumn, currentRow);

			// Increment the column and row values
			currentColumn++;
			if (currentColumn == 4) {
				currentColumn = 0;
				currentRow++;
			}
		}
		// getMatchingUsers(accountId);

//		fill the grid with the users in friends list using nested loops
//		theFriends.add(new IndividualFriendPane(new Image("User.png"), "Hanadi Asfour", false), 0, 0);
//		theFriends.add(new IndividualFriendPane(new Image("email.png"), "Baheya Asfour", true), 1, 0);
//		theFriends.add(new IndividualFriendPane(new Image("Lock.png"), "Margo Thalji", false), 2, 0);
//		theFriends.add(new IndividualFriendPane(new Image("ICON.png"), "Samih Asfour", true), 3, 0);
//		theFriends.add(new IndividualFriendPane(new Image("Lock.png"), "Mohammad Asfour", false), 0, 1);
//		theFriends.add(new IndividualFriendPane(new Image("ICON.png"), "Hussein Asfour", true), 1, 1);
//		theFriends.add(new IndividualFriendPane(new Image("User.png"), "Raed Asfour", false), 2, 1);
//		theFriends.add(new IndividualFriendPane(new Image("email.png"), "Oliver Asfour", false), 3, 1);

		getChildren().addAll(topPart, horizontalLine, theFriends);
		setPadding(new Insets(50, 50, 20, 50));
		setStyle("-fx-background-color:white;");
	}

	public void addFriend(Image image, String name, boolean online, int column, int row) {
		IndividualFriendPane friendPane = new IndividualFriendPane(image, name, online);
		GridPane.setConstraints(friendPane, column, row);
		theFriends.getChildren().add(friendPane);
	}

	public void deleteFriend(User friend) {
		// Remove the profile picture HBox from its parent
		if (getParent() instanceof HBox) {
			HBox parentPane = (HBox) getParent();
			parentPane.getChildren().remove(this);
		}
	}

	public TextField getSearch() {
		return search;
	}

	public Button getSearchButton() {
		return searchButton;
	}

	public Label getAddNewFriend() {
		return addNewFriend;
	}

	public GridPane getTheFriends() {
		return theFriends;
	}

	public void setTheFriends(GridPane theFriends) {
		this.theFriends = theFriends;
	}

	private int currentRow = 0;
	private int currentColumn = 0;

	private ArrayList<User> getMatchingUsers(int accountId) {
		// ArrayList<User> matchingUsers = new ArrayList<>();
//		accountId = 1;
		friends = new ArrayList<User>();

		PreparedStatement selectStatement;
		try (Connection connection = DriverManager
				.getConnection("jdbc:mysql://127.0.0.1:3306/synceditors?sslmode=require", "root", "1020304050Ss")) {
			// Prepare the SQL query
			String sqlQuery = "SELECT accountsID,userName, gmail FROM Accounts WHERE accountsID IN "
					+ "(SELECT firsts FROM befriends WHERE seconds = "
					+ "(SELECT accountsID FROM Accounts WHERE userName = ?) UNION "
					+ "SELECT seconds FROM befriends WHERE firsts = "
					+ "(SELECT accountsID FROM Accounts WHERE userName = ?)) AND userName <> ?";

			try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
				// Set parameters for the prepared statement
				preparedStatement.setString(1, Main.theMain.username);
				preparedStatement.setString(2, Main.theMain.username);
				preparedStatement.setString(3, Main.theMain.username);

				// Execute the query
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					// Iterate through the result set and print friend details
					while (resultSet.next()) {
						String friendUserName = resultSet.getString("userName");
						String gmail = resultSet.getString("gmail");
						int id = resultSet.getInt("accountsID");

						System.out.println("Friend Username: " + friendUserName + ", gmail: " + gmail);

						User user = new User(id, friendUserName, null, null, new Image("User1.png"), gmail);

						System.out.println("ajjj");
						friends.add(user);
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

//		

		return friends;
	}

	public void searchFriends(String searchText) {
		// Clear the gridPane before adding new search results
		theFriends.getChildren().clear();
		currentColumn = 0;
		currentRow = 0;

		// Filter the users based on the search text
		ArrayList<User> filteredUsers = filterUsers(friends, searchText);

		// Add the filtered users to the grid pane
		for (User user : filteredUsers) {
			Image userImage = getImageFromDatabase(user.getAccountID());
			String userName = user.getUserName();
			boolean online = user.isOnline();
			addFriend(userImage, userName, online, currentColumn, currentRow);

			// Increment the column and row counters
			currentColumn++;
			if (currentColumn > 3) {
				currentColumn = 0;
				currentRow++;
			}
		}
	}

	private ArrayList<User> filterUsers(ArrayList<User> users, String searchText) {
		ArrayList<User> filteredUsers = new ArrayList<>();

		for (User user : users) {
			String userName = user.getUserName();
			if (userName != null && userName.toLowerCase().contains(searchText.toLowerCase())) {
				filteredUsers.add(user);
			}
		}

		return filteredUsers;
	}

	public Image getImageFromDatabase(int id) {
		try (Connection connection = DriverManager
				.getConnection("jdbc:mysql://127.0.0.1:3306/synceditors?sslmode=require", "root", "1020304050Ss")) {
			// SQL query to select the image data
			String sql = "SELECT image FROM accounts WHERE accountsID = ?";

			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, id);

				// Execute the query
				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						// Get the image data from the result set
						byte[] imageData = resultSet.getBytes("image");

						// Convert the image data to a JavaFX Image
						if (imageData != null) {
							ByteArrayInputStream bis = new ByteArrayInputStream(imageData);
							return new Image(bis);
						}
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int getAccountId(String gmail) {

		// SQL query
		String sql = "SELECT accountsID FROM Accounts WHERE gmail = ?";

		// Gmail value entered by the user
		String enteredGmail = Login.getGmail().getText();

		try (Connection connection = DriverManager.getConnection(
				"jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "synceditors" + "?sslmode=require", "root",
				"1020304050Ss"); PreparedStatement statement = connection.prepareStatement(sql)) {

			// Set the parameter value for the prepared statement
			statement.setString(1, enteredGmail);

			// Execute the query
			ResultSet resultSet = statement.executeQuery();

			// Check if the result set has a row
			if (resultSet.next()) {
				// Retrieve the accountID value from the result set
				accountId = resultSet.getInt("accountsID");

				// Output the accountID value
				System.out.println("Account ID: " + accountId);
			} else {
				System.out.println("No account found with the specified Gmail.");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountId;
	}

	private void searchFiles(String searchText) {
		// Clear the gridPane before adding new search results
		theFriends.getChildren().clear();
		currentColumn = 0;
		currentRow = 0;

		try {
			// Print debug statement to check if the method is invoked
			System.out.println("Searching for files...");

			// Prepare and execute the search query
			String searchQuery = "SELECT userName FROM Accounts WHERE userName LIKE ?";
			PreparedStatement searchStatement = sql.getConnection().prepareStatement(searchQuery);
			searchStatement.setString(1, "%" + searchText + "%");

			ResultSet resultSet = searchStatement.executeQuery();

			// Process the search results
			while (resultSet.next()) {
				String fileNameFromDB = resultSet.getString("userName");

				// Print debug statement to check each file found
				System.out.println("Found file: " + fileNameFromDB);

				// Create a VBox for each file from the database
				VBox dbFileVBox = createVBoxFromDatabase(fileNameFromDB);

				// Adding the database file VBox to the GridPane
				addElement(dbFileVBox);
			}

			// Close the result set, statement, and connection
			resultSet.close();
			searchStatement.close();
			sql.getConnection().close();
		} catch (SQLException ex) {
			// Print the stack trace to identify the SQL exception
			ex.printStackTrace();
		}
	}

	public void MyFilesPage(GridPane theFriends) {
		this.theFriends = theFriends;
	}

	public void addElement(VBox vbox) {
		theFriends.add(vbox, currentColumn, currentRow);
		theFriends.setVgap(15);
		currentColumn++;
		if (currentColumn >= 5) {
			currentColumn = 0;
			currentRow++;
		}
	}

	// Method to create a VBox dynamically based on data retrieved from the database
	public VBox createVBoxFromDatabase(String friends) {

		String dummyFileImage = "File.png";
		String dummyDeleteImage = "DeleteFile.png";
		String dummyFindUserImage = "FindUser.png";
		String dummyEditImage = "edit.png";

		VBox vbox = new VBox(15);

		vbox.setStyle("-fx-background-color: #f2f2f2;"); // Set background color
//        Image fileImage = new Image(dummyFileImage);
//        ImageView fileImageView = new ImageView(fileImage);
//        fileImageView.setFitWidth(150);
//        fileImageView.setFitHeight(110);

		// Label fileNameLabel = new Label(fileNameFromDB);

		Image deleteImage = new Image(dummyDeleteImage);
		ImageView deleteImageView = new ImageView(deleteImage);
		deleteImageView.setFitWidth(30);
		deleteImageView.setFitHeight(30);

		Image findUserImage = new Image(dummyFindUserImage);
		ImageView findUserImageView = new ImageView(findUserImage);
		findUserImageView.setFitWidth(30);
		findUserImageView.setFitHeight(30);

		Image editImage = new Image(dummyEditImage);
		ImageView editImageView = new ImageView(editImage);
		editImageView.setFitWidth(30);
		editImageView.setFitHeight(30);

		HBox hBox31 = new HBox(5);
		hBox31.setAlignment(Pos.BASELINE_LEFT);
		hBox31.getChildren().addAll(deleteImageView, findUserImageView, editImageView);

		vbox.getChildren().addAll(hBox31);
		vbox.setAlignment(Pos.BASELINE_LEFT);
		return vbox;
	}
}