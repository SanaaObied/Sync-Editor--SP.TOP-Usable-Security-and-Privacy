module SyncEditor2 {
	exports textCollab;
	exports src.application;

	requires java.sql;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.web;
	requires mail;
	requires twilio;
}