package textCollab;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Main extends Application {
	private TextArea textArea1;
	private TextArea textArea2;

	@Override
	public void start(Stage primaryStage) {

		// Create two text areas for collaboration
//		textArea1 = createCollaborativeTextArea();
//		textArea2 = createCollaborativeTextArea();

		// Arrange text areas horizontally
		HBox root = new HBox(textArea1, textArea2);

		// Set up the stage
		primaryStage.setTitle("Collaborative Editor");
		primaryStage.setScene(new Scene(root, 600, 400));
		primaryStage.show();

		// Create some IdentifierDigit instances
		IdentifierDigit digit1 = new IdentifierDigit(3, 1);
		IdentifierDigit digit2 = new IdentifierDigit(5, 2);

		// Create PositionIdentifier instances
		List<IdentifierDigit> digits1 = new ArrayList<>();
		digits1.add(digit1);
		digits1.add(digit2);

		List<IdentifierDigit> digits2 = new ArrayList<>();
		digits2.add(new IdentifierDigit(3, 1));
		digits2.add(new IdentifierDigit(5, 2));

		PositionIdentifier position1 = new PositionIdentifier(digits1);
		PositionIdentifier position2 = new PositionIdentifier(digits2);

		// Compare PositionIdentifier instances
		int positionComparison = position1.compareTo(position2);

		if (positionComparison < 0) {
			System.out.println("Position 1 is less than Position 2");
		} else if (positionComparison > 0) {
			System.out.println("Position 1 is greater than Position 2");
		} else {
			System.out.println("Position 1 is equal to Position 2");
		}

		// Compare IdentifierDigit instances
		int digitComparison = digit1.compareTo(new IdentifierDigit(3, 1));

		if (digitComparison < 0) {
			System.out.println("Digit 1 is less than Digit 2");
		} else if (digitComparison > 0) {
			System.out.println("Digit 1 is greater than Digit 2");
		} else {
			System.out.println("Digit 1 is equal to Digit 2");
		}

	}

//	private TextArea createCollaborativeTextArea(CollaborativeModel model) {
//		TextArea textArea = new TextArea();
//
//		// Set up event listeners to handle text changes
//		textArea.textProperty().addListener((observable, oldValue, newValue) -> {
//			// Update the model with the new text
//			model.setText(newValue);
//
//			// Apply the updated text to other text areas
//			updateOtherTextAreas(textArea, newValue);
//		});
//
//		return textArea;
//	}

	private void updateOtherTextAreas(TextArea currentTextArea, String newText) {
		// Determine the other text area
		TextArea otherTextArea = (currentTextArea == textArea1) ? textArea2 : textArea1;

		// Avoid triggering events when updating the text
		otherTextArea.textProperty().setValue(newText);
	}

	public static void main(String[] args) {
		launch(args);
	}
}
