package textCollab;

import java.util.ArrayList;
import java.util.List;

public class CollaborativeTextEditor {

	List<Character> characters; // List of characters in the document

	// Constructor
	CollaborativeTextEditor() {
		this.characters = new ArrayList<>();
	}

	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	// Remote Change: Insertion
	void remoteInsert(PositionIdentifier precedingPosition, char newValue) {
		// Find the index where the new character should be inserted based on preceding
		// position
		int insertionIndex = findInsertionIndex(precedingPosition);

		// Create a new position identifier for the inserted character
		PositionIdentifier newPosition = generatePositionBetween(characters.get(insertionIndex - 1).position,
				characters.get(insertionIndex).position);

		// Insert the new character at the calculated index
		characters.add(insertionIndex, new Character(newPosition, newValue));

		// Notify other clients about the remote insertion (this can involve network
		// communication)
		sendRemoteChange("add", new Character(newPosition, newValue));
	}

	// Helper method to find the index where a character should be inserted based on
	// position
	private int findInsertionIndex(PositionIdentifier precedingPosition) {
		for (int i = 0; i < characters.size(); i++) {
			if (precedingPosition.compareTo(characters.get(i).position) <= 0) {
				return i;
			}
		}
		return characters.size(); // Insert at the end if not found
	}

	// Helper method to generate a position identifier between two existing
	// positions
	private PositionIdentifier generatePositionBetween(PositionIdentifier position1, PositionIdentifier position2) {
		List<IdentifierDigit> newDigits = new ArrayList<>();

		// Iterate through the digits of both positions
		for (int i = 0; i < Math.min(position1.digits.size(), position2.digits.size()); i++) {
			IdentifierDigit digit1 = position1.digits.get(i);
			IdentifierDigit digit2 = position2.digits.get(i);

			// Calculate a new digit value that is between digit1 and digit2
			int newDigitValue = (digit1.digit + digit2.digit) / 2;

			// Use the site ID of the current client
			int siteId = getCurrentSiteId(); // Placeholder, replace with actual logic to get site ID

			// Create the new identifier digit
			IdentifierDigit newDigit = new IdentifierDigit(newDigitValue, siteId);

			// Add the new digit to the list
			newDigits.add(newDigit);

			// Break the loop if the digits are different, ensuring order preservation
			if (digit1.digit != digit2.digit) {
				break;
			}
		}

		// Create and return the new position identifier
		return new PositionIdentifier(newDigits);
	}

	// Placeholder method to get the current client's site ID
	private int getCurrentSiteId() {
		// Replace with actual logic to retrieve the site ID of the current client
		return 1; // Placeholder, replace with the actual site ID
	}

	// Helper method to send remote changes to other clients (placeholder
	// implementation)
	private void sendRemoteChange(String type, Character character) {
		// Placeholder implementation for sending remote changes to other clients
		System.out.println("Sending remote change: " + type + " " + character.value);
	}

	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	// Remote Change: Deletion
	void remoteDelete(PositionIdentifier position) {
		// Find the index of the character to be deleted based on the provided position
		int deletionIndex = findDeletionIndex(position);

		// Delete the character at the calculated index
		characters.remove(deletionIndex);

		// Notify other clients about the remote deletion (this can involve network
		// communication)
		sendRemoteChange("remove", position);
	}

	// Helper method to find the index of a character to be deleted based on
	// position
	private int findDeletionIndex(PositionIdentifier position) {
		for (int i = 0; i < characters.size(); i++) {
			if (position.compareTo(characters.get(i).position) == 0) {
				return i;
			}
		}
		// Handle the case where the character to be deleted is not found
		throw new IllegalArgumentException("Character not found for deletion at position: " + position);
	}

	// Helper method to send remote changes to other clients (placeholder
	// implementation)
	private void sendRemoteChange(String type, PositionIdentifier position) {
		// Placeholder implementation for sending remote changes to other clients
		System.out.println("Sending remote change: " + type + " " + position);
	}

	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	// Local Change: Insertion at Position n
	void localInsert(int n, char newValue) {
		// Ensure the insertion position is within valid bounds
		if (n < 0 || n > characters.size()) {
			throw new IllegalArgumentException("Invalid insertion position: " + n);
		}

		// Find the characters at positions n and n + 1
		PositionIdentifier positionN = getPositionAtIndex(n);
		PositionIdentifier positionNPlus1 = getPositionAtIndex(n + 1);

		// Generate a new position identifier between positionN and positionNPlus1
		PositionIdentifier newPosition = generatePositionBetween(positionN, positionNPlus1);

		// Insert the character at the calculated index
		characters.add(n, new Character(newPosition, newValue));

		// Notify other clients about the local insertion (this can involve network
		// communication)
		sendRemoteChange("add", newPosition, newValue);
	}

	// Helper method to get the position identifier at a specific index in the
	// document
	private PositionIdentifier getPositionAtIndex(int index) {
		if (index >= 0 && index < characters.size()) {
			return characters.get(index).position;
		}
		// Handle the case where the index is out of bounds
		throw new IndexOutOfBoundsException("Invalid index: " + index);
	}

	// Helper method to send remote changes to other clients (placeholder
	// implementation)
	private void sendRemoteChange(String type, PositionIdentifier position, char newValue) {
		// Placeholder implementation for sending remote changes to other clients
		System.out.println("Sending remote change: " + type + " " + position + " " + newValue);
	}

	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	// Local Change: Deletion at Position n
	void localDelete(int n) {
		// Ensure the deletion position is within valid bounds
		if (n < 0 || n >= characters.size()) {
			throw new IllegalArgumentException("Invalid deletion position: " + n);
		}

		// Get the character at the specified index
		Character deletedCharacter = characters.get(n);

		// Delete the character at the specified index
		characters.remove(n);

		// Notify other clients about the local deletion (this can involve network
		// communication)
		sendRemoteChange("remove", deletedCharacter.position);
	}

	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	

	

	

}
