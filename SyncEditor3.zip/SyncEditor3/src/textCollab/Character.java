package textCollab;

class Character {
	PositionIdentifier position; // Unique identifier for the character's position
	char value; // The character itself

	// Constructor
	Character(PositionIdentifier position, char value) {
		this.position = position;
		this.value = value;
	}
}