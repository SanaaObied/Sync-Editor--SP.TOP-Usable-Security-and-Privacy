package textCollab;

// Represents a single digit in a position identifier
class IdentifierDigit implements Comparable<IdentifierDigit> {
	int digit; // Value of the digit
	int siteId; // Unique identifier for the site

	// Constructor
	IdentifierDigit(int digit, int siteId) {
		this.digit = digit;
		this.siteId = siteId;
	}

	@Override
	public int compareTo(IdentifierDigit other) {
		// Compare digits first
		int digitComparison = Integer.compare(this.digit, other.digit);

		// If digits are equal, compare site IDs
		if (digitComparison == 0) {
			return Integer.compare(this.siteId, other.siteId);
		}

		return digitComparison;
	}

}
