package textCollab;

import java.util.List;


//Represents a character in the document
// Represents a unique identifier for a position in the document
class PositionIdentifier implements Comparable<PositionIdentifier> {
	List<IdentifierDigit> digits; // List of digits forming the identifier

	// Constructor
	PositionIdentifier(List<IdentifierDigit> digits) {
		this.digits = digits;
	}

	@Override
	public int compareTo(PositionIdentifier other) {
		// Compare each digit in the position identifier
		for (int i = 0; i < Math.min(digits.size(), other.digits.size()); i++) {
			int digitComparison = digits.get(i).compareTo(other.digits.get(i));
			if (digitComparison != 0) {
				return digitComparison;
			}
		}

		// If the common digits are equal, check the length of the identifier
		return Integer.compare(digits.size(), other.digits.size());
	}
}